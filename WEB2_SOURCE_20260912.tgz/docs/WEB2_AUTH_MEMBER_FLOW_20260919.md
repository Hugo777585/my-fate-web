# 天命智庫 2.0｜會員登入／驗信／忘記密碼驗收

正式站：`https://hugo-tianming-web2.vercel.app`

## 本版功能

1. 登入後自動保留 session，會員沒有主動登出時，不需要每次重新登入。
2. 新會員註冊支援 Email 驗證後回站。
3. 登入頁新增「忘記密碼？」。
4. 忘記密碼寄信後可回到 `/auth/update-password` 設定新密碼。
5. 重設成功後保持登入並回到會員工作台。
6. 主動登出才會清除目前 session。

## Supabase 後台必須確認

### Authentication → Providers → Email

- Email provider：Enabled
- Confirm email：**Enabled**
- Minimum password length：至少 6

只有程式碼無法強制 Supabase 寄出註冊驗證信；`Confirm email` 必須在 Supabase 專案後台開啟。

### Authentication → URL Configuration

Site URL：

`https://hugo-tianming-web2.vercel.app`

Redirect URLs 至少加入：

- `https://hugo-tianming-web2.vercel.app/auth/callback`
- `https://hugo-tianming-web2.vercel.app/auth/callback?next=/dashboard`
- `https://hugo-tianming-web2.vercel.app/auth/callback?next=/auth/update-password`

### Authentication → Email Templates

目前程式同時支援兩種流程：

- Supabase 標準 redirect + PKCE：走 `/auth/callback`
- 自訂 token_hash template：走 `/auth/confirm`

若要採用較穩定、可跨裝置開信的 token_hash 方式，建議把模板改成：

#### Confirm signup

```html
<h2>驗證你的天命智庫會員 Email</h2>
<p>請點擊以下連結完成會員驗證：</p>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard">完成 Email 驗證</a></p>
```

#### Reset password

```html
<h2>重新設定天命智庫登入密碼</h2>
<p>我們收到重設密碼申請，請點擊以下連結：</p>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/auth/update-password">設定新密碼</a></p>
<p>如果不是你提出申請，可以忽略這封信。</p>
```

## 真實驗收流程

### A. 新會員

1. 用從未註冊過的 Email 建立帳號。
2. 畫面顯示「請到 Email 完成驗證」。
3. 收到驗證信。
4. 點信件後回到網站。
5. 可正常進入 Dashboard。
6. 關閉瀏覽器後重新開站，仍保持登入。

### B. 忘記密碼

1. 登入頁點「忘記密碼？」。
2. 輸入已註冊 Email。
3. 收到重設密碼信。
4. 點信件後進入「設定新密碼」。
5. 設定新密碼成功。
6. 直接回 Dashboard，並保持登入。
7. 主動登出後，舊密碼不可登入，新密碼可以登入。

### C. 保持登入

1. 登入成功。
2. 關閉分頁／瀏覽器。
3. 再開正式站並進會員區。
4. 不應要求再次登入。
5. 按「登出」後才應回到未登入狀態。

> 瀏覽器若使用無痕模式、手動清 Cookie、換裝置／換瀏覽器，仍需要重新登入，這是正常安全行為。
