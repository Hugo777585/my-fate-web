# WEB2 綠界正式金流整合

來源：`天命智庫2.0_綠界正式金流移植包_20260915(1).zip`。

本版已將目前 WEB2 的金流骨架升級為：
- MerchantID 固定 3502227
- production + Credit + test mode false
- TM2 訂單編號
- CustomField2=production / CustomField3=TM2
- 原始 POST body 驗簽，拒絕重複欄位
- RtnCode=1 且 SimulatePaid=0 才允許入帳
- 建單先從後端方案表取得金額與幣量
- callback 再核對原始訂單金額與環境
- 前端改成正常 form POST 到 WEB2 建單端點，由後端產生綠界自動提交 HTML

## 尚未完成
1. Vercel Production secrets 必須填入真實 `ECPAY_HASH_KEY` / `ECPAY_HASH_IV` 與 Supabase service role。
2. `.env.production.example` 的公開 URL 已指向 `https://hugo-tianming-web2.vercel.app`，若之後換正式網域需同步修改。
3. `supabase/reference/WEB2_ECPAY_PRODUCTION_HARDENING_20260915.sql` 尚未自動套用，需先備份並審核現行 RPC 再 migration。
4. 必須完成一次真實小額付款，確認 ECPay callback、payment_orders、wallet_transactions、wallet_accounts 全部一致，才能宣告端到端驗收。

本包不含 HashKey、HashIV、Service Role Key。
