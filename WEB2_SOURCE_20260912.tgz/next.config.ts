import type { NextConfig } from "next";

const nextConfig: NextConfig = {
    allowedDevOrigins: ["127.0.0.1"],
    typedRoutes: false,
    typescript: {
        ignoreBuildErrors: true,
    },
};

export default nextConfig;
