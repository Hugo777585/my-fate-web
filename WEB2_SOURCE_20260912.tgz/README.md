# HUGO 天命智庫 WEB2

這份版本以 2026-09-11 的 `WEB2-review.zip` 為基底，保留原有深黑／深咖啡／金色視覺，已完成第一輪正式營運功能整合。

## 開發啟動

```bash
cp .env.example .env.local
npm ci
npm run dev
```

正式驗收：

```bash
npm run check
npm run build
```

功能與安全變更請看 `docs/WEB2_STAGE2_COMPLETE.md`。

> 不要把 `.env.local`、service role key 或綠界正式金鑰提交進版本庫或交付 ZIP。
