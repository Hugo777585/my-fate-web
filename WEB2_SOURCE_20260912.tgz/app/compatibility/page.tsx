import Link from "next/link";
import { HeartHandshake, ShieldCheck, Sparkles, UsersRound } from "lucide-react";

import { PageShell } from "@/components/page-shell";
import { ReadingDepthGuide } from "@/components/reading-depth-guide";
import { requireUser } from "@/lib/auth";
import { buildBasicCompatibility } from "@/lib/compatibility";
import { getProfileById, listProfiles } from "@/lib/profiles";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function single(value: string | string[] | undefined) {
    return Array.isArray(value) ? value[0] : value;
}

export default async function CompatibilityPage({ searchParams }: { searchParams: SearchParams }) {
    const user = await requireUser();
    const query = await searchParams;
    const profiles = await listProfiles(user.id);
    const preselected = single(query.profile);
    const aId = single(query.a) ?? preselected ?? "";
    const bId = single(query.b) ?? "";
    const relationship = single(query.relationship) ?? "伴侶／感情";

    const [profileA, profileB] = await Promise.all([
        aId ? getProfileById(user.id, aId) : Promise.resolve(null),
        bId ? getProfileById(user.id, bId) : Promise.resolve(null),
    ]);
    const result = profileA && profileB && profileA.id !== profileB.id
        ? await buildBasicCompatibility(profileA, profileB)
        : null;

    return (
        <PageShell
            eyebrow="兩人合盤"
            title="先把兩個人的基本盤放在一起看。"
            description="免費基本合盤先比較日主五行、日支與強弱差異，提供可以看懂的互動線索；NT$1,200 深度合盤再加入雙方八字大運、流年、紫微十二宮與 HUGO 綜合解讀。"
        >
            <ReadingDepthGuide
                eyebrow="雙人合盤閱讀路徑"
                title="先看兩個人怎麼互動，再決定要不要把關係看深。"
                description="合盤不先用一個分數決定好壞，而是先看彼此吸引、情緒互動與相處節奏，再往價值觀、衝突點、長期穩定度與時間變化深入。"
                stages={[
                    {
                        label: "免費｜基本比較",
                        title: "先看兩人的基本互動",
                        description: "把兩筆命主資料放在同一個畫面，先看最直觀的相處訊號。",
                        bullets: ["雙方日主與五行", "吸引與互補訊號", "容易碰撞的相處點"],
                    },
                    {
                        label: "免費｜關係初見",
                        title: "從互動走進關係模式",
                        description: "先讀彼此需求、溝通方式與情緒節奏，讓關係不只剩下一個分數。",
                        bullets: ["情緒互動", "溝通模式", "價值觀與衝突摘要"],
                    },
                    {
                        label: "深度｜八字＋紫微",
                        title: "雙人深度合盤",
                        description: "八字與紫微斗數交叉閱讀，再把兩人的時間節奏與現實問題一起整理。",
                        bullets: ["吸引力與核心需求", "衝突來源與調整方向", "長期發展與近期關係節奏"],
                        price: "NT$1,200",
                        tone: "paid",
                    },
                ]}
                serviceHref="/services?plan=compatibility_1200"
                serviceLabel="查看 NT$1,200 雙人深度合盤"
            />

            <section className="rounded-[30px] border border-white/10 bg-white/[0.03] p-6 lg:p-8">
                <form className="grid gap-4 lg:grid-cols-[1fr_1fr_0.8fr_auto] lg:items-end" method="get">
                    <label className="grid gap-2 text-sm text-stone-300">
                        第一位命主
                        <select name="a" defaultValue={aId} className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                            <option value="">請選擇</option>
                            {profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.name} · {profile.tag}</option>)}
                        </select>
                    </label>
                    <label className="grid gap-2 text-sm text-stone-300">
                        第二位命主
                        <select name="b" defaultValue={bId} className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                            <option value="">請選擇</option>
                            {profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.name} · {profile.tag}</option>)}
                        </select>
                    </label>
                    <label className="grid gap-2 text-sm text-stone-300">
                        關係類型
                        <select name="relationship" defaultValue={relationship} className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                            {['伴侶／感情','曖昧／觀察中','婚姻','家人','合作／事業','朋友'].map((item) => <option key={item}>{item}</option>)}
                        </select>
                    </label>
                    <button type="submit" className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-6 py-3 text-sm font-medium text-stone-950">開始基本合盤</button>
                </form>
                {profiles.length < 2 ? (
                    <p className="mt-5 rounded-2xl border border-amber-200/12 bg-amber-50/[0.035] px-4 py-3 text-sm leading-7 text-amber-50/80">
                        合盤需要至少兩筆完整命主資料。<Link href="/profiles/new" className="ml-2 underline underline-offset-4">先新增資料</Link>
                    </p>
                ) : null}
                {aId && bId && aId === bId ? <p className="mt-5 text-sm text-rose-300">兩位命主不能選同一筆資料。</p> : null}
            </section>

            {profileA && profileB && !result ? (
                <section className="rounded-[28px] border border-rose-300/15 bg-rose-500/[0.05] p-6 text-sm leading-7 text-rose-100/85">
                    其中一筆資料缺少性別、生日、時辰或出生地，請先回命主資料補齊後再合盤。
                </section>
            ) : null}

            {result ? (
                <>
                    <section className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
                        <article className="rounded-[30px] border border-amber-300/20 bg-[radial-gradient(circle_at_top,rgba(245,158,11,0.12),transparent_55%),#140d0b] p-7 text-center">
                            <HeartHandshake className="mx-auto h-7 w-7 text-amber-200" />
                            <p className="mt-5 text-xs uppercase tracking-[0.32em] text-amber-200/55">基本互補指標</p>
                            <p className="mt-3 text-7xl font-semibold text-amber-100">{result.score}</p>
                            <p className="mt-2 text-xl tracking-[0.08em] text-stone-50">{result.label}</p>
                            <p className="mt-5 text-sm leading-7 text-stone-400">{result.summary}</p>
                        </article>
                        <article className="rounded-[30px] border border-white/10 bg-white/[0.03] p-7">
                            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">{relationship}</p>
                            <div className="mt-5 grid gap-4 sm:grid-cols-2">
                                {[result.personA, result.personB].map((person) => (
                                    <div key={person.name} className="rounded-[22px] border border-white/8 bg-[#120d0b] p-5">
                                        <p className="text-xl text-stone-50">{person.name}</p>
                                        <p className="mt-3 text-sm text-stone-400">日主 {person.dayMaster} · {person.element} · 日支 {person.dayBranch}</p>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-5 flex flex-wrap gap-2">
                                {result.signals.map((signal) => <span key={signal} className="rounded-full border border-amber-200/15 bg-amber-50/[0.04] px-3 py-1.5 text-xs text-amber-100/80">{signal}</span>)}
                            </div>
                        </article>
                    </section>
                    <section className="grid gap-5 lg:grid-cols-2">
                        <article className="rounded-[28px] border border-emerald-300/12 bg-emerald-500/[0.035] p-7">
                            <div className="flex items-center gap-3"><Sparkles className="h-5 w-5 text-emerald-200" /><h2 className="text-2xl text-stone-50">可以利用的優勢</h2></div>
                            <div className="mt-5 space-y-3">{result.strengths.map((item) => <p key={item} className="rounded-2xl border border-white/7 bg-black/10 px-4 py-3 text-sm leading-7 text-stone-300">{item}</p>)}</div>
                        </article>
                        <article className="rounded-[28px] border border-amber-300/12 bg-amber-500/[0.03] p-7">
                            <div className="flex items-center gap-3"><ShieldCheck className="h-5 w-5 text-amber-200" /><h2 className="text-2xl text-stone-50">相處時要注意</h2></div>
                            <div className="mt-5 space-y-3">{result.cautions.map((item) => <p key={item} className="rounded-2xl border border-white/7 bg-black/10 px-4 py-3 text-sm leading-7 text-stone-300">{item}</p>)}</div>
                        </article>
                    </section>
                    <section className="rounded-[30px] border border-amber-300/18 bg-[#140d0b] p-7 lg:flex lg:items-center lg:justify-between lg:gap-8">
                        <div>
                            <div className="flex items-center gap-3"><UsersRound className="h-5 w-5 text-amber-200" /><p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">雙人深度合盤</p></div>
                            <h2 className="mt-4 text-3xl tracking-[0.05em] text-stone-50">八字＋紫微斗數交叉解讀 · NT$1,200</h2>
                            <p className="mt-3 max-w-3xl text-sm leading-7 text-stone-400">免費分數只是入口。深度版會看雙方命盤結構、大運流年、紫微宮位互動與關係中的現實問題，由 HUGO 整理成可執行的判斷重點。</p>
                        </div>
                        <Link href="/about" className="mt-6 inline-flex shrink-0 rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-6 py-3 text-sm font-medium text-stone-950 lg:mt-0">了解 HUGO 深度解讀</Link>
                    </section>
                </>
            ) : (
                <section className="rounded-[30px] border border-dashed border-white/10 p-8 text-center text-sm leading-7 text-stone-400">
                    選好兩位命主後，這裡會直接顯示免費基本合盤結果。
                </section>
            )}
        </PageShell>
    );
}
