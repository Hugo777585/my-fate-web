import Link from "next/link";

import { PageShell } from "@/components/page-shell";
import { ReadingDepthGuide } from "@/components/reading-depth-guide";
import { requireUser } from "@/lib/auth";
import type { ZiweiPalace } from "@/lib/ziwei-iztro-adapter";
import {
    loadZiweiPageData,
    type ZiweiPageSearchParams,
    type ZiweiWorkspaceMode,
} from "@/lib/ziwei-provider";

type ZiweiPageProps = {
    searchParams: Promise<ZiweiPageSearchParams>;
};

function buildZiweiHref(profileId: string | undefined, mode: ZiweiWorkspaceMode) {
    return {
        pathname: "/ziwei",
        query: {
            ...(profileId ? { profile: profileId } : {}),
            mode,
        },
    };
}

const modeTabs = [
    { key: "natal", title: "本命盤", description: "命盤骨架與十二宮定位" },
    { key: "decade", title: "大限", description: "十年大限與宮位流轉" },
    { key: "annual", title: "流年", description: "年度四化與事件觸發" },
    { key: "monthly", title: "流月", description: "月度節奏與宮位引動" },
    { key: "daily", title: "流日", description: "日內起伏與細節落點" },
    { key: "hourly", title: "流時", description: "即時刻度與動態連線" },
] as const;

const palaceSlots = [
    { index: 0, label: "父母" },
    { index: 1, label: "福德" },
    { index: 2, label: "田宅" },
    { index: 3, label: "官祿" },
    { index: 4, label: "命宮" },
    { index: 7, label: "僕役" },
    { index: 8, label: "兄弟" },
    { index: 11, label: "遷移" },
    { index: 12, label: "夫妻" },
    { index: 13, label: "子女" },
    { index: 14, label: "財帛" },
    { index: 15, label: "疾厄" },
] as const;

function getPalaceByLabel(palaces: ZiweiPalace[] | undefined, label: string) {
    return palaces?.find((palace) => palace.label === label) ?? null;
}

function formatStarNames(stars: Array<{ name: string }> | undefined, fallback: string, limit = 3) {
    if (!stars || stars.length === 0) {
        return fallback;
    }

    return stars
        .slice(0, limit)
        .map((star) => star.name)
        .join("、");
}

function formatTransforms(palace: ZiweiPalace | null) {
    if (!palace || palace.transforms.length === 0) {
        return "四化未見";
    }

    return palace.transforms
        .slice(0, 3)
        .map((item) => `${item.starName}${item.kind}`)
        .join("、");
}

function formatTransformMap(transformMap: { 祿: string; 權: string; 科: string; 忌: string } | undefined) {
    if (!transformMap) {
        return "四化未見";
    }

    const items = [
        transformMap.祿 ? `祿:${transformMap.祿}` : "",
        transformMap.權 ? `權:${transformMap.權}` : "",
        transformMap.科 ? `科:${transformMap.科}` : "",
        transformMap.忌 ? `忌:${transformMap.忌}` : "",
    ].filter(Boolean);

    return items.length > 0 ? items.join(" / ") : "四化未見";
}

export default async function ZiweiPage({ searchParams }: ZiweiPageProps) {
    const user = await requireUser();
    const resolvedSearchParams = await searchParams;
    const { selectedProfile, activeMode, availableProfiles, chart, hasChartInput } = await loadZiweiPageData(
        user.id,
        resolvedSearchParams,
    );
    const hasChart = Boolean(chart && chart.status === "ready");
    const palaceCount = chart?.palaces.length ?? 0;
    const starCount = chart?.stars.length ?? 0;
    const activeModeTitle = modeTabs.find((tab) => tab.key === activeMode)?.title ?? "本命盤";
    const fourPillars = chart?.meta.fourPillars;
    const fourPillarsText = fourPillars
        ? `${fourPillars.year} / ${fourPillars.month} / ${fourPillars.day} / ${fourPillars.hour}`
        : "四柱未載入";
    const zodiacText = chart?.meta.zodiac ?? "未定";
    const constellationText = chart?.meta.constellation ?? "未定";
    const transformSourceStem = chart?.transforms.source.heavenlyStem;
    const transformSourceText = hasChart
        ? transformSourceStem
            ? `${transformSourceStem}干起四化`
            : "四化來源待補"
        : hasChartInput
          ? "排盤未完成"
          : "資料不足";
    const transformMapText = hasChart ? formatTransformMap(chart?.transforms.map) : "四化未見";

    return (
        <PageShell
            eyebrow="Zi Wei Entry"
            title={selectedProfile ? `${selectedProfile.name} 的紫微閱讀` : "紫微斗數｜從命宮一路讀到人生節奏"}
            description={
                selectedProfile
                    ? "先免費看命宮、主星與十二宮，再依需要往夫妻、官祿、財帛、大限與流年逐步深入。"
                    : "先選定一筆命主資料。紫微資訊很多，所以我們用由淺入深的方式，讓你先看懂，再決定要不要進入 NT$299 深度解讀。"
            }
            actions={
                <div className="flex flex-wrap gap-3">
                    <Link
                        href="/profiles"
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        回親友資料庫選擇命主
                    </Link>
                    {selectedProfile ? (
                        <Link
                            href={`/profiles/${selectedProfile.id}`}
                            className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950"
                        >
                            回這筆資料詳情
                        </Link>
                    ) : null}
                </div>
            }
        >
            <ReadingDepthGuide
                eyebrow="紫微閱讀路徑"
                title="先從命宮與主星認識自己，再慢慢走進十二宮。"
                description="紫微斗數資訊很多，所以閱讀順序比資訊量更重要。先看命宮、身宮與主星，再延伸到夫妻、官祿、財帛、福德與流年，讓每一步都知道自己正在看什麼。"
                stages={[
                    {
                        label: "免費｜基本命盤",
                        title: "先定位命宮與十二宮",
                        description: "建立整張紫微盤的骨架，先知道主星與重要宮位落在哪裡。",
                        bullets: ["命宮／身宮", "十二宮定位", "主星、輔星與四化"],
                    },
                    {
                        label: "免費｜初見閱讀",
                        title: "先讀最貼近生活的宮位",
                        description: "先從最常被問到的感情、工作與財務切入，不需要一次讀完整張盤。",
                        bullets: ["命宮與個性核心", "夫妻宮與關係模式", "官祿／財帛／福德摘要"],
                    },
                    {
                        label: "深度｜完整解讀",
                        title: "紫微深度解讀",
                        description: "把本命與大限、流年放在一起，整理出真正值得注意的時間與主題。",
                        bullets: ["重要宮位交叉判讀", "大限與流年節奏", "HUGO 白話整理與實際建議"],
                        price: "NT$299",
                        tone: "paid",
                    },
                ]}
                serviceHref="/services?plan=personal_299"
                serviceLabel="查看 NT$299 深度解讀"
            />

            <section className="grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
                <section className="rounded-[30px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.9)_0%,rgba(10,14,23,0.98)_100%)] p-6 shadow-[0_0_90px_rgba(217,119,6,0.06)] lg:p-7">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                        <div className="max-w-3xl">
                            <p className="text-xs uppercase tracking-[0.32em] text-amber-400/65">紫微命盤</p>
                            <h2 className="mt-3 text-[1.8rem] leading-tight tracking-[0.05em] text-stone-50 lg:text-[2.05rem]">
                                選定命主，即時排出紫微十二宮
                            </h2>
                            <p className="mt-4 text-[0.92rem] leading-7 text-stone-300">
                                命盤以 iztro 排盤資料呈現十二宮、星曜與四化；切換命主後會依出生資料重新計算。
                            </p>
                        </div>
                        <div className="min-w-[220px] rounded-[24px] border border-white/10 bg-[rgba(18,24,38,0.72)] px-5 py-4 text-sm leading-7 text-stone-300 backdrop-blur-md">
                            <p>視角：{modeTabs.find((tab) => tab.key === activeMode)?.title ?? "本命盤"}</p>
                            <p>命主：{selectedProfile ? selectedProfile.name : "尚未選定"}</p>
                            <p>盤面：{hasChart ? `已接 ${chart?.engine.name ?? "iztro"}` : hasChartInput ? "排盤失敗" : "資料不足"}</p>
                            <p>資料源：{hasChart ? "iztro 即時排盤" : "等待完整命主資料"}</p>
                        </div>
                    </div>

                    <div className="mt-7 rounded-[22px] border border-white/8 bg-white/[0.02] p-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] lg:p-6">
                        <p className="text-xs uppercase tracking-[0.24em] text-stone-400">時間視角</p>
                        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                            {modeTabs.map((tab) => (
                                <Link
                                    key={tab.key}
                                    href={buildZiweiHref(selectedProfile?.id, tab.key)}
                                    className={`rounded-[18px] border p-4 transition ${
                                        activeMode === tab.key
                                            ? "border-amber-300/26 bg-amber-50/[0.06] text-amber-50 shadow-[0_0_18px_rgba(251,191,36,0.08)]"
                                            : "border-white/10 bg-white/[0.02] text-stone-200 hover:border-amber-300/22 hover:bg-amber-50/[0.035] hover:text-amber-100"
                                    }`}
                                >
                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-400">模式</p>
                                    <p className="mt-2 text-sm font-medium tracking-[0.04em]">{tab.title}</p>
                                    <p className="mt-2 text-[0.85rem] leading-6 text-stone-300">{tab.description}</p>
                                </Link>
                            ))}
                        </div>
                    </div>

                    <div className="mt-6 rounded-[22px] border border-white/8 bg-[#0b0f18] p-5 shadow-[0_0_60px_rgba(124,58,237,0.06)] lg:p-6">
                        <p className="text-xs uppercase tracking-[0.24em] text-violet-200/70">排盤資料</p>
                        <p className="mt-3 text-sm leading-7 text-stone-300">
                            命主資料會直接交給紫微排盤引擎，再整理成十二宮、主星、輔星與四化資料。
                        </p>
                        <p className="mt-3 text-xs leading-6 text-stone-400">
                            目前盤面使用真實排盤資料；若命主資料不完整，系統會明確標示並停止推算。
                        </p>
                    </div>

                    <div className="mt-6 rounded-[22px] border border-white/8 bg-[#0b0f18] p-5 shadow-[0_0_80px_rgba(217,119,6,0.05)] lg:p-6">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                                <p className="text-xs uppercase tracking-[0.24em] text-amber-200/70">十二宮</p>
                                <h3 className="mt-2 text-[1.05rem] tracking-[0.05em] text-stone-50 lg:text-xl">
                                    紫微十二宮盤面
                                </h3>
                            </div>
                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.18em] text-stone-300">
                                {hasChart ? `已取得 ${palaceCount} 宮 / ${starCount} 星` : selectedProfile ? "命主已鎖定" : "尚未選定命主"}
                            </span>
                        </div>

                        <p className="mt-4 text-[0.92rem] leading-7 text-stone-300">
                            {hasChart
                                ? "十二宮已接入真實排盤資料，可直接查看各宮主星、輔星與四化。"
                                : "請先選擇一筆生日、時辰完整的命主資料，系統會排出十二宮。"}
                        </p>

                        <div className="relative mt-5 overflow-hidden rounded-[22px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.72)_0%,rgba(10,14,23,0.98)_100%)] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.03),0_0_40px_rgba(124,58,237,0.04)] backdrop-blur-md lg:p-5">
                            <div className="pointer-events-none absolute inset-[1px] rounded-[21px] border border-white/5" />
                            <div className="pointer-events-none absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-amber-200/40 to-transparent" />
                            <div className="pointer-events-none absolute inset-x-10 top-0 h-24 bg-[radial-gradient(circle_at_top,rgba(124,58,237,0.08)_0%,rgba(217,119,6,0.05)_24%,transparent_72%)]" />
                            <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_40px_rgba(0,0,0,0.22)]" />
                            <div className="grid grid-cols-4 gap-2 lg:gap-3">
                                {Array.from({ length: 16 }, (_, index) => {
                                    if (index === 6 || index === 9 || index === 10) {
                                        return null;
                                    }

                                    if (index === 5) {
                                        return (
                                            <div
                                                key="center"
                                                className="col-span-2 row-span-2 flex flex-col justify-between rounded-[20px] border border-amber-300/14 bg-[radial-gradient(circle_at_top,rgba(217,119,6,0.18)_0%,rgba(10,14,23,0.96)_58%)] p-5 shadow-[0_0_60px_rgba(217,119,6,0.10)]"
                                            >
                                                <div>
                                                    <div className="flex items-start justify-between gap-3">
                                                        <div>
                                                            <p className="text-[11px] uppercase tracking-[0.28em] text-amber-200/72">中央命主區</p>
                                                            <p className="mt-2 text-[0.8rem] tracking-[0.18em] text-amber-100/55">
                                                                Zi Wei Control Core
                                                            </p>
                                                        </div>
                                                        <span className="rounded-full border border-amber-200/16 bg-amber-100/[0.05] px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-amber-100/72">
                                                            {activeModeTitle}
                                                        </span>
                                                    </div>

                                                    <p className="mt-5 text-[2rem] font-medium tracking-[0.08em] text-stone-50 lg:text-[2.4rem]">
                                                        {selectedProfile ? selectedProfile.name : "尚未選定"}
                                                    </p>
                                                    <p className="mt-2 text-xs uppercase tracking-[0.24em] text-stone-500">
                                                        {selectedProfile ? "命主已綁定" : "等待命主"}
                                                    </p>
                                                    <p className="mt-4 text-sm leading-7 text-stone-300">
                                                        {selectedProfile
                                                            ? hasChart
                                                                ? `${zodiacText} / ${constellationText} / ${selectedProfile.birthPlace}`
                                                                : `${selectedProfile.birthDate} / ${selectedProfile.birthTime} / ${selectedProfile.birthPlace}`
                                                            : "先從右側選定命主，紫微盤面才會綁定同一筆資料。"}
                                                    </p>
                                                </div>
                                                <div className="mt-6 grid gap-2">
                                                    <div className="grid gap-2 sm:grid-cols-2">
                                                        <div className="rounded-[14px] border border-white/8 bg-white/[0.03] px-3 py-3">
                                                            <p className="text-[10px] uppercase tracking-[0.24em] text-stone-500">四柱</p>
                                                            <p className="mt-2 text-xs leading-5 text-stone-200">
                                                                {hasChart ? fourPillarsText : hasChartInput ? "排盤未完成" : "資料不足"}
                                                            </p>
                                                        </div>
                                                        <div className="rounded-[14px] border border-white/8 bg-white/[0.03] px-3 py-3">
                                                            <p className="text-[10px] uppercase tracking-[0.24em] text-stone-500">四化來源</p>
                                                            <p className="mt-2 text-xs leading-5 text-stone-200">{transformSourceText}</p>
                                                        </div>
                                                    </div>
                                                    <div className="rounded-[14px] border border-amber-200/10 bg-amber-50/[0.04] px-3 py-3">
                                                        <p className="text-[10px] uppercase tracking-[0.24em] text-amber-100/65">四化摘要</p>
                                                        <p className="mt-2 text-xs leading-5 text-amber-50/88">
                                                            {hasChart ? transformMapText : hasChartInput ? "排盤未完成" : "資料不足"}
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    }

                                    const label = palaceSlots.find((slot) => slot.index === index)?.label ?? "宮位";
                                    const isMainPalace = label === "命宮";
                                    const showData = Boolean(selectedProfile);
                                    const palace = hasChart ? getPalaceByLabel(chart?.palaces, label) : null;
                                    const mainStarText = palace
                                        ? formatStarNames(palace.mainStars, palace.isEmpty ? "空宮" : "主星未見", 2)
                                        : "宮位未對應";
                                    const minorStarText = palace
                                        ? formatStarNames(palace.minorStars, "輔星未見")
                                        : "等待宮位資料";
                                    const transformText = formatTransforms(palace);
                                    const palaceStatusText = showData
                                        ? hasChart
                                            ? "已接真盤"
                                            : hasChartInput
                                              ? "排盤中"
                                              : "資料不足"
                                        : "等待命主";

                                    return (
                                        <div
                                            key={index}
                                            className={`relative flex min-h-[104px] flex-col justify-between overflow-hidden rounded-[18px] border p-4 shadow-[0_0_30px_rgba(0,0,0,0.2)] ${
                                                isMainPalace
                                                    ? "border-amber-300/30 bg-[radial-gradient(circle_at_top,rgba(245,158,11,0.14)_0%,rgba(217,119,6,0.08)_18%,rgba(255,251,235,0.03)_38%,rgba(255,251,235,0.01)_100%)] shadow-[0_0_34px_rgba(217,119,6,0.16)]"
                                                    : "border-white/7 bg-[rgba(255,255,255,0.012)] shadow-[0_0_22px_rgba(0,0,0,0.18)]"
                                            }`}
                                        >
                                            {isMainPalace ? (
                                                <>
                                                    <div className="pointer-events-none absolute inset-x-3 top-0 h-px bg-gradient-to-r from-transparent via-amber-200/55 to-transparent" />
                                                    <div className="pointer-events-none absolute right-0 top-0 h-14 w-14 bg-[linear-gradient(135deg,rgba(251,191,36,0.28)_0%,rgba(251,191,36,0.10)_42%,transparent_72%)]" />
                                                    <div className="pointer-events-none absolute right-2 top-2 rounded-full border border-amber-200/18 bg-[rgba(255,248,220,0.08)] px-2 py-1 text-[9px] uppercase tracking-[0.24em] text-amber-100/75 shadow-[0_0_20px_rgba(217,119,6,0.10)]">
                                                        主宮
                                                    </div>
                                                </>
                                            ) : null}
                                            <div>
                                                <div className="flex items-center justify-between gap-2">
                                                    <p
                                                        className={`text-xs uppercase tracking-[0.22em] ${
                                                            isMainPalace ? "text-amber-100/90" : "text-stone-400"
                                                        }`}
                                                    >
                                                        {label}
                                                    </p>
                                                    <span
                                                        className={`rounded-full px-2 py-1 text-[10px] tracking-[0.18em] ${
                                                            isMainPalace
                                                                ? "border border-amber-200/18 bg-amber-100/[0.06] text-amber-100/80"
                                                                : "text-stone-600"
                                                        }`}
                                                    >
                                                        {palaceStatusText}
                                                    </span>
                                                </div>
                                                <p
                                                    className={`mt-2 text-sm font-medium tracking-[0.04em] ${
                                                        isMainPalace ? "text-amber-50" : "text-stone-100"
                                                    }`}
                                                >
                                                    {showData
                                                        ? hasChart
                                                            ? mainStarText
                                                            : hasChartInput
                                                              ? "排盤處理中"
                                                              : "資料不足"
                                                        : "等待命主"}
                                                </p>
                                            </div>
                                            <div className="mt-3 space-y-2">
                                                <div
                                                    className={`rounded-[12px] border px-3 py-2 ${
                                                        isMainPalace
                                                            ? "border-amber-200/12 bg-amber-50/[0.045] shadow-[inset_0_1px_0_rgba(255,248,220,0.06)]"
                                                            : "border-white/5 bg-[rgba(255,255,255,0.015)]"
                                                    }`}
                                                >
                                                    <p
                                                        className={`text-[10px] uppercase tracking-[0.2em] ${
                                                            isMainPalace ? "text-amber-100/70" : "text-stone-500"
                                                        }`}
                                                    >
                                                        主星
                                                    </p>
                                                    <p className={`mt-1 text-xs leading-5 ${isMainPalace ? "text-amber-50" : "text-stone-200"}`}>
                                                        {showData
                                                            ? hasChart
                                                                ? mainStarText
                                                                : hasChartInput
                                                                  ? "排盤處理中"
                                                                  : "資料不足"
                                                            : "等待命主"}
                                                    </p>
                                                </div>
                                                <div
                                                    className={`rounded-[12px] border px-3 py-2 ${
                                                        isMainPalace
                                                            ? "border-amber-200/10 bg-amber-50/[0.035]"
                                                            : "border-white/5 bg-[rgba(255,255,255,0.012)]"
                                                    }`}
                                                >
                                                    <p
                                                        className={`text-[10px] uppercase tracking-[0.2em] ${
                                                            isMainPalace ? "text-amber-100/65" : "text-stone-500"
                                                        }`}
                                                    >
                                                        輔星
                                                    </p>
                                                    <p className={`mt-1 text-xs leading-5 ${isMainPalace ? "text-amber-50/88" : "text-stone-300"}`}>
                                                        {showData
                                                            ? hasChart
                                                                ? minorStarText
                                                                : hasChartInput
                                                                  ? "命盤引擎已啟動"
                                                                  : "需先補齊生日 / 時辰 / 性別"
                                                            : "選定命主後展開"}
                                                    </p>
                                                </div>
                                                <div
                                                    className={`rounded-[12px] border px-3 py-2 ${
                                                        isMainPalace
                                                            ? "border-amber-200/10 bg-gradient-to-r from-amber-50/[0.04] to-transparent"
                                                            : "border-white/5 bg-[rgba(255,255,255,0.012)]"
                                                    }`}
                                                >
                                                    <p
                                                        className={`text-[10px] uppercase tracking-[0.2em] ${
                                                            isMainPalace ? "text-amber-100/65" : "text-stone-500"
                                                        }`}
                                                    >
                                                        四化
                                                    </p>
                                                    <p className={`mt-1 text-xs leading-5 ${isMainPalace ? "text-amber-50/88" : "text-stone-300"}`}>
                                                        {showData
                                                            ? hasChart
                                                                ? transformText
                                                                : hasChartInput
                                                                  ? "排盤未完成"
                                                                  : "資料不足"
                                                            : "選定命主後展開"}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </section>

                <aside className="rounded-[30px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.9)_0%,rgba(10,14,23,0.98)_100%)] p-6 shadow-[0_0_90px_rgba(124,58,237,0.06)] lg:sticky lg:top-8 lg:p-7">
                    <p className="text-xs uppercase tracking-[0.32em] text-violet-200/70">命主切換</p>
                    <h2 className="mt-3 text-[1.65rem] leading-tight tracking-[0.05em] text-stone-50 lg:text-[2.05rem]">
                        選定命主
                    </h2>
                    <p className="mt-4 text-[0.92rem] leading-7 text-stone-300">
                        紫微盤面會跟著同一筆命主資料切換。本頁先提供快速入口，後續宮位與星曜會綁定同一份排盤結果。
                    </p>

                    <div className="mt-6 space-y-3">
                        {availableProfiles.length > 0 ? (
                            availableProfiles.map((profile) => (
                                <Link
                                    key={profile.id}
                                    href={buildZiweiHref(profile.id, activeMode)}
                                    className={`block rounded-[22px] border px-5 py-4 transition ${
                                        selectedProfile?.id === profile.id
                                            ? "border-violet-300/22 bg-violet-50/[0.06] shadow-[0_0_24px_rgba(124,58,237,0.10)]"
                                            : "border-white/10 bg-white/[0.02] hover:border-violet-300/18 hover:bg-violet-50/[0.04]"
                                    }`}
                                >
                                    <p className="text-sm font-medium tracking-[0.04em] text-stone-100">{profile.name}</p>
                                    <p className="mt-2 text-xs leading-6 text-stone-400">
                                        {profile.birthDate} / {profile.birthTime} / {profile.birthPlace}
                                    </p>
                                </Link>
                            ))
                        ) : (
                            <div className="rounded-[22px] border border-white/10 bg-white/[0.02] p-5 text-sm leading-7 text-stone-300">
                                目前尚無命主資料。請先到親友資料庫建立一筆命主，再回到紫微頁鎖定命主。
                            </div>
                        )}
                    </div>
                </aside>
            </section>
        </PageShell>
    );
}
