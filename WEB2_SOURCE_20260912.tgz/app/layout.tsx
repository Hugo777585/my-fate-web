import type { Metadata } from "next";
import { Cormorant_Garamond, Noto_Sans_TC } from "next/font/google";

import { MobileBottomNav } from "@/components/mobile-bottom-nav";
import { SiteHeader } from "@/components/site-header";

import "./globals.css";

const displayFont = Cormorant_Garamond({
    variable: "--font-display",
    subsets: ["latin"],
    weight: ["400", "500", "600", "700"],
});

const bodyFont = Noto_Sans_TC({
    variable: "--font-body",
    subsets: ["latin"],
    weight: ["400", "500", "700"],
});

export const metadata: Metadata = {
    title: "天命智庫｜HUGO 命理分析",
    description: "八字、紫微斗數、雙人合盤與 HUGO 深度解讀。免費建立基本命盤，重要決定再進一步分析。",
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="zh-Hant" className={`${displayFont.variable} ${bodyFont.variable}`}>
            <body className="min-h-screen bg-[#090706] text-stone-100">
                <div className="min-h-screen bg-[radial-gradient(circle_at_top,#44220f_0%,#110b09_34%,#090706_78%)] pb-20 lg:pb-0">
                    <div className="fixed inset-0 -z-10 opacity-50 [background-image:radial-gradient(circle_at_center,rgba(251,191,36,0.12)_0,transparent_42%),linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] [background-size:100%_100%,120px_120px,120px_120px]" />
                    <SiteHeader />
                    {children}
                    <MobileBottomNav />
                </div>
            </body>
        </html>
    );
}
