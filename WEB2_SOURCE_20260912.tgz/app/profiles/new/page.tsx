import Link from "next/link";

import { createProfileAction } from "@/app/profiles/actions";
import { ProfileForm } from "@/components/profile-form";
import { PageShell } from "@/components/page-shell";
import { requireUser } from "@/lib/auth";

export default async function NewProfilePage() {
    await requireUser();

    return (
        <PageShell
            eyebrow="Create Profile"
            title="新增資料現在會直接寫進會員自己的資料庫。"
            description="新增後會直接存入會員自己的資料庫，八字、紫微與合盤都能沿用這筆資料。"
        >
            <section className="rounded-[28px] border border-white/10 bg-white/[0.03] p-8">
                <ProfileForm action={createProfileAction} submitLabel="建立這筆親友資料" />
                <div className="mt-6 flex flex-wrap gap-3">
                    <Link
                        href="/profiles"
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        回列表
                    </Link>
                </div>
            </section>
        </PageShell>
    );
}
