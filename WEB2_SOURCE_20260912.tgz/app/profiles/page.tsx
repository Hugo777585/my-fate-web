import Link from "next/link";

import { PageShell } from "@/components/page-shell";
import { ProfileList } from "@/components/profile-list";
import { requireUser } from "@/lib/auth";
import { listProfiles } from "@/lib/profiles";

export default async function ProfilesPage() {
    const user = await requireUser();
    const profiles = await listProfiles(user.id);

    return (
        <PageShell
            eyebrow="Profiles"
            title="親友資料庫是整個產品的資料中心。"
            description="所有八字、紫微與合盤都從同一筆命主資料出發，不必重複輸入生日與時辰。"
            actions={
                <Link
                    href="/profiles/new"
                    className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950"
                >
                    新增一筆資料
                </Link>
            }
        >
            <ProfileList items={profiles} />
        </PageShell>
    );
}
