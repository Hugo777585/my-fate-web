import Link from "next/link";
import { notFound } from "next/navigation";

import { updateProfileAction } from "@/app/profiles/actions";
import { ProfileForm } from "@/components/profile-form";
import { PageShell } from "@/components/page-shell";
import { requireUser } from "@/lib/auth";
import { getProfileById } from "@/lib/profiles";

export default async function EditProfilePage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    const user = await requireUser();
    const { id } = await params;
    const profile = await getProfileById(user.id, id);

    if (!profile) {
        notFound();
    }

    const updateAction = updateProfileAction.bind(null, profile.id);

    return (
        <PageShell
            eyebrow="Edit Profile"
            title={`調整 ${profile.name} 的會員資料。`}
            description="這裡會直接更新 Supabase 裡的親友資料，後面八字、紫微、合盤都會同步吃到同一筆最新內容。"
        >
            <section className="rounded-[28px] border border-white/10 bg-white/[0.03] p-8">
                <ProfileForm
                    action={updateAction}
                    initialProfile={profile}
                    submitLabel="儲存這次修改"
                />
                <div className="mt-6 flex flex-wrap gap-3">
                    <Link
                        href={`/profiles/${profile.id}`}
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        回到詳情
                    </Link>
                </div>
            </section>
        </PageShell>
    );
}
