import Link from "next/link";
import { notFound } from "next/navigation";

import { deleteProfileAction } from "@/app/profiles/actions";
import { ProfileDeleteButton } from "@/components/profile-delete-button";
import { PageShell } from "@/components/page-shell";
import { requireUser } from "@/lib/auth";
import { getProfileById } from "@/lib/profiles";

export default async function ProfileDetailPage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    const user = await requireUser();

    const { id } = await params;
    const profile = await getProfileById(user.id, id);

    if (!profile) {
        notFound();
    }

    const deleteAction = deleteProfileAction.bind(null, profile.id);

    return (
        <PageShell
            eyebrow="Profile Detail"
            title={`${profile.name} 的資料已經進入會員資料庫。`}
            description="這筆命主資料可直接帶入八字、紫微與兩人合盤，也可隨時編輯或刪除。"
            actions={
                <>
                    <Link
                        href={`/profiles/${profile.id}/edit`}
                        className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950"
                    >
                        編輯這筆資料
                    </Link>
                    <Link
                        href="/profiles"
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        回到列表
                    </Link>
                    <ProfileDeleteButton action={deleteAction} />
                </>
            }
        >
            <section className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
                <article className="rounded-[28px] border border-white/10 bg-white/[0.03] p-8">
                    <dl className="space-y-4 text-sm leading-7 text-stone-300">
                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                            <dt>類型</dt>
                            <dd>{profile.tag}</dd>
                        </div>
                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                            <dt>性別</dt>
                            <dd>{profile.gender}</dd>
                        </div>
                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                            <dt>生日</dt>
                            <dd>{profile.birthDate}</dd>
                        </div>
                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                            <dt>時辰</dt>
                            <dd>{profile.birthTime}</dd>
                        </div>
                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                            <dt>出生地</dt>
                            <dd>{profile.birthPlace}</dd>
                        </div>
                    </dl>
                    <p className="mt-5 text-sm leading-7 text-stone-400">{profile.notes}</p>
                </article>

                <article className="rounded-[28px] border border-amber-300/15 bg-[#140d0b] p-8">
                    <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">快捷入口</p>
                    <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">從同一筆資料進入不同模組</h2>
                    <p className="mt-4 text-sm leading-7 text-stone-300">
                        八字、紫微與合盤會直接讀取這筆資料，避免重複填寫。
                    </p>
                    <div className="mt-8 grid gap-3 sm:grid-cols-3">
                        <Link
                            href={`/bazi?profile=${profile.id}`}
                            className="rounded-2xl border border-white/8 bg-[#120d0b] px-4 py-4 text-sm text-stone-200 hover:border-amber-300/30 hover:text-amber-50"
                        >
                            從這筆資料進入八字
                        </Link>
                        <Link
                            href={`/ziwei?profile=${profile.id}`}
                            className="rounded-2xl border border-white/8 bg-[#120d0b] px-4 py-4 text-sm text-stone-200 hover:border-amber-300/30 hover:text-amber-50"
                        >
                            從這筆資料進入紫微
                        </Link>
                        <Link
                            href={`/compatibility?profile=${profile.id}`}
                            className="rounded-2xl border border-white/8 bg-[#120d0b] px-4 py-4 text-sm text-stone-200 hover:border-amber-300/30 hover:text-amber-50"
                        >
                            從這筆資料進入合盤
                        </Link>
                    </div>
                </article>
            </section>
        </PageShell>
    );
}
