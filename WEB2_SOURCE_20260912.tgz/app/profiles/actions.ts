"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { requireUser } from "@/lib/auth";
import type { ProfileType } from "@/lib/profiles";
import { createClient } from "@/lib/supabase/server";

const profileTypes = new Set<ProfileType>(["self", "family", "client"]);

export type ProfileActionState = {
    error?: string;
};

type ProfilePayload = {
    name: string;
    profileType: ProfileType;
    gender: string | null;
    birthDate: string | null;
    birthTimeLabel: string;
    birthPlace: string;
    notes: string;
};

type ProfileFormResult =
    | { ok: false; error: string }
    | { ok: true; value: ProfilePayload };

function normalizeText(value: FormDataEntryValue | null) {
    return String(value ?? "").trim();
}

function parseProfileForm(formData: FormData): ProfileFormResult {
    const name = normalizeText(formData.get("name"));
    const profileType = normalizeText(formData.get("profileType")) as ProfileType;
    const gender = normalizeText(formData.get("gender"));
    const birthDate = normalizeText(formData.get("birthDate"));
    const birthTimeLabel = normalizeText(formData.get("birthTimeLabel"));
    const birthPlace = normalizeText(formData.get("birthPlace"));
    const notes = normalizeText(formData.get("notes"));

    if (!name) {
        return { ok: false, error: "請先填寫姓名 / 暱稱。" };
    }

    if (!profileTypes.has(profileType)) {
        return { ok: false, error: "資料類型不合法，請重新選擇。" };
    }

    if (birthDate && !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) {
        return { ok: false, error: "生日請使用 YYYY-MM-DD 格式。" };
    }

    return {
        ok: true,
        value: {
            name,
            profileType,
            gender: gender || null,
            birthDate: birthDate || null,
            birthTimeLabel,
            birthPlace,
            notes,
        },
    };
}

export async function createProfileAction(
    _prevState: ProfileActionState,
    formData: FormData,
): Promise<ProfileActionState> {
    const user = await requireUser();
    const payload = parseProfileForm(formData);

    if (!payload.ok) {
        return { error: payload.error };
    }

    const supabase = await createClient();
    const { data, error } = await supabase
        .from("clients")
        .insert({
            owner_id: user.id,
            name: payload.value.name,
            profile_type: payload.value.profileType,
            gender: payload.value.gender,
            birth_date: payload.value.birthDate,
            birth_time_label: payload.value.birthTimeLabel,
            birth_place: payload.value.birthPlace,
            notes: payload.value.notes,
        })
        .select("id")
        .single();

    if (error) {
        return { error: `新增資料失敗：${error.message}` };
    }

    revalidatePath("/profiles");
    redirect(`/profiles/${data.id}`);
}

export async function updateProfileAction(
    profileId: string,
    _prevState: ProfileActionState,
    formData: FormData,
): Promise<ProfileActionState> {
    const user = await requireUser();
    const payload = parseProfileForm(formData);

    if (!payload.ok) {
        return { error: payload.error };
    }

    const supabase = await createClient();
    const { error } = await supabase
        .from("clients")
        .update({
            name: payload.value.name,
            profile_type: payload.value.profileType,
            gender: payload.value.gender,
            birth_date: payload.value.birthDate,
            birth_time_label: payload.value.birthTimeLabel,
            birth_place: payload.value.birthPlace,
            notes: payload.value.notes,
        })
        .eq("id", profileId)
        .eq("owner_id", user.id);

    if (error) {
        return { error: `更新資料失敗：${error.message}` };
    }

    revalidatePath("/profiles");
    revalidatePath(`/profiles/${profileId}`);
    redirect(`/profiles/${profileId}`);
}

export async function deleteProfileAction(profileId: string) {
    const user = await requireUser();
    const supabase = await createClient();
    const { error } = await supabase
        .from("clients")
        .delete()
        .eq("id", profileId)
        .eq("owner_id", user.id);

    if (error) {
        throw new Error(`刪除資料失敗：${error.message}`);
    }

    revalidatePath("/profiles");
    redirect("/profiles");
}
