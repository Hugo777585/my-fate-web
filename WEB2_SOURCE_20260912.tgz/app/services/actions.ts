"use server";

import { revalidatePath } from "next/cache";

import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

export type ConsultationActionState = { error?: string; success?: string };

const plans = {
    personal_299: { amount: 299, needsSecond: false },
    compatibility_1200: { amount: 1200, needsSecond: true },
} as const;

type PlanCode = keyof typeof plans;

function text(value: FormDataEntryValue | null) {
    return String(value ?? "").trim();
}

export async function createConsultationRequestAction(
    _prev: ConsultationActionState,
    formData: FormData,
): Promise<ConsultationActionState> {
    const user = await requireUser();
    const serviceCode = text(formData.get("serviceCode")) as PlanCode;
    const profileId = text(formData.get("profileId"));
    const secondProfileId = text(formData.get("secondProfileId"));
    const question = text(formData.get("question"));
    const contactNote = text(formData.get("contactNote"));
    const plan = plans[serviceCode];

    if (!plan) return { error: "服務方案不正確。" };
    if (!profileId) return { error: "請先選擇主要命主。" };
    if (plan.needsSecond && !secondProfileId) return { error: "雙人合盤需要選擇第二位命主。" };
    if (plan.needsSecond && secondProfileId === profileId) return { error: "兩位命主不能是同一筆資料。" };
    if (contactNote.length < 3) return { error: "請留下至少一種可聯絡方式（LINE、電話或 Email）。" };
    if (contactNote.length > 300) return { error: "聯絡方式內容請控制在 300 字以內。" };
    if (question.length < 5) return { error: "請至少簡單寫下你最想處理的問題。" };
    if (question.length > 2000) return { error: "問題內容請控制在 2,000 字以內。" };

    const supabase = await createClient();
    const ids = [profileId, ...(plan.needsSecond ? [secondProfileId] : [])];
    const { data: ownedProfiles, error: profileError } = await supabase
        .from("clients")
        .select("id")
        .eq("owner_id", user.id)
        .in("id", ids);

    if (profileError || (ownedProfiles?.length ?? 0) !== ids.length) {
        return { error: "命主資料不存在或不屬於目前帳號。" };
    }

    const { error } = await supabase.from("consultation_requests").insert({
        user_id: user.id,
        profile_id: profileId,
        second_profile_id: plan.needsSecond ? secondProfileId : null,
        service_code: serviceCode,
        amount_twd: plan.amount,
        question,
        contact_note: contactNote,
        status: "submitted",
    });

    if (error) return { error: `送出需求失敗：${error.message}` };

    revalidatePath("/services");
    revalidatePath("/workspace");
    return { success: "需求已送出。HUGO 工作台已收到這筆資料。" };
}
