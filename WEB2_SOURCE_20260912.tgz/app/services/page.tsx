import Link from "next/link";
import { CheckCircle2 } from "lucide-react";

import { ConsultationRequestForm } from "@/components/consultation-request-form";
import { PageShell } from "@/components/page-shell";
import { requireUser } from "@/lib/auth";
import { listProfiles } from "@/lib/profiles";
import { createClient } from "@/lib/supabase/server";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function single(v: string | string[] | undefined) { return Array.isArray(v) ? v[0] : v; }

export default async function ServicesPage({ searchParams }: { searchParams: SearchParams }) {
    const user = await requireUser();
    const query = await searchParams;
    const profiles = await listProfiles(user.id);
    const plan = single(query.plan) === "compatibility_1200" ? "compatibility_1200" : "personal_299";
    const supabase = await createClient();
    const { data: requests } = await supabase
        .from("consultation_requests")
        .select("id, service_code, amount_twd, status, question, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(8);

    return (
        <PageShell
            eyebrow="HUGO 深度解讀"
            title="把你現在真正卡住的問題送進來。"
            description="NT$299 適合單一命主深度整理；NT$1,200 適合雙人八字＋紫微交叉合盤。先送出問題與命主資料，HUGO 工作台會直接收到，不必再重複填寫出生資料。"
        >
            {profiles.length ? <ConsultationRequestForm profiles={profiles} defaultPlan={plan} /> : (
                <section className="rounded-[28px] border border-amber-300/15 bg-amber-50/[0.04] p-7 text-sm leading-7 text-stone-300">
                    你還沒有命主資料。<Link href="/profiles/new" className="ml-2 text-amber-100 underline underline-offset-4">先建立一筆命主資料</Link>。
                </section>
            )}
            <section className="grid gap-4 md:grid-cols-2">
                {[{name:"個人深度解讀",price:"NT$299",items:["命局重點整理","大運／流年時間節點","白話判斷與實際做法"]},{name:"雙人深度合盤",price:"NT$1,200",items:["雙方八字互動","紫微十二宮交叉","關係風險、節奏與調整方向"]}].map((card) => <article key={card.name} className="rounded-[28px] border border-white/10 bg-white/[0.03] p-7"><p className="text-xs uppercase tracking-[0.26em] text-amber-200/55">{card.name}</p><p className="mt-3 text-3xl text-stone-50">{card.price}</p><div className="mt-5 space-y-3">{card.items.map((item)=><p key={item} className="flex items-center gap-3 text-sm text-stone-300"><CheckCircle2 className="h-4 w-4 text-amber-200"/>{item}</p>)}</div></article>)}
            </section>
            <section className="rounded-[30px] border border-white/10 bg-white/[0.025] p-7">
                <h2 className="text-2xl text-stone-50">我的需求紀錄</h2>
                <div className="mt-5 grid gap-3">
                    {(requests ?? []).length ? (requests ?? []).map((item) => <div key={item.id} className="rounded-[20px] border border-white/8 bg-[#120d0b] px-5 py-4"><div className="flex flex-wrap items-center justify-between gap-3"><p className="text-sm text-stone-100">{item.service_code === "compatibility_1200" ? "雙人深度合盤" : "個人深度解讀"} · NT${Number(item.amount_twd).toLocaleString("zh-TW")}</p><span className="rounded-full border border-amber-200/15 px-3 py-1 text-xs text-amber-100">{({submitted:"已送出",in_review:"處理中",contacted:"已聯繫",completed:"已完成",cancelled:"已取消"} as Record<string,string>)[item.status] ?? item.status}</span></div><p className="mt-3 line-clamp-2 text-sm leading-7 text-stone-400">{item.question}</p></div>) : <p className="text-sm text-stone-500">目前還沒有送出的深度解讀需求。</p>}
                </div>
            </section>
        </PageShell>
    );
}
