import Link from "next/link";
import { ArrowRight, BookUser, Coins, FileText, HeartHandshake, Sparkles, Stars, UserRoundCog } from "lucide-react";

import { PageShell } from "@/components/page-shell";
import { getCurrentRole, requireUser } from "@/lib/auth";
import { getMemberDashboardData } from "@/lib/member-data";

const quickLinks = [
    { href: "/profiles" as const, label: "命主資料", icon: BookUser, description: "管理自己、親友與客戶資料" },
    { href: "/bazi" as const, label: "八字排盤", icon: Sparkles, description: "四柱、五行、大運與流年" },
    { href: "/ziwei" as const, label: "紫微斗數", icon: Stars, description: "十二宮、星曜與四化" },
    { href: "/compatibility" as const, label: "兩人合盤", icon: HeartHandshake, description: "選兩筆資料進行基本比較" },
    { href: "/wallet" as const, label: "錢包", icon: Coins, description: "餘額、效期與交易紀錄" },
    { href: "/services" as const, label: "HUGO 深度服務", icon: UserRoundCog, description: "送出 NT$299／NT$1,200 解讀需求" },
    { href: "/workspace" as const, label: "HUGO 工作台", icon: UserRoundCog, description: "集中處理線上客戶" },
] as const;

function formatDate(value: string) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("zh-TW", { dateStyle: "medium" }).format(date);
}

export default async function DashboardPage() {
    const user = await requireUser();
    const [data, role] = await Promise.all([getMemberDashboardData(user.id), getCurrentRole()]);
    const visibleQuickLinks = quickLinks.filter((item) => item.href !== "/workspace" || role === "owner" || role === "admin");

    return (
        <PageShell
            eyebrow="會員中心"
            title="命主、命盤、合盤與錢包都從這裡進。"
            description={`目前登入帳號：${user.email ?? "會員"}。這裡直接顯示真實會員資料，不再使用開發階段的示意數字。`}
        >
            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                    { label: "命主資料", value: data.profileCount, sub: `其中 ${data.clientCount} 筆客戶`, icon: BookUser },
                    { label: "天命幣餘額", value: data.walletBalance, sub: `${data.walletReserved} 枚暫時保留`, icon: Coins },
                    { label: "解讀紀錄", value: data.readingCount, sub: "歷史閱讀與問事", icon: FileText },
                    { label: "付款紀錄", value: data.paymentCount, sub: "已建立的付款訂單", icon: Sparkles },
                ].map((card) => {
                    const Icon = card.icon;
                    return (
                        <article key={card.label} className="rounded-[26px] border border-white/10 bg-white/[0.03] p-6">
                            <Icon className="h-5 w-5 text-amber-200" />
                            <p className="mt-5 text-xs uppercase tracking-[0.26em] text-stone-500">{card.label}</p>
                            <p className="mt-2 text-4xl font-medium tracking-[0.03em] text-stone-50">{card.value}</p>
                            <p className="mt-2 text-xs text-stone-400">{card.sub}</p>
                        </article>
                    );
                })}
            </section>

            <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {visibleQuickLinks.map((item) => {
                    const Icon = item.icon;
                    return (
                        <Link key={item.href} href={item.href} className="group rounded-[28px] border border-white/10 bg-white/[0.03] p-6 transition hover:-translate-y-1 hover:border-amber-300/28 hover:bg-amber-50/[0.04]">
                            <div className="flex items-start justify-between gap-4">
                                <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-amber-200/18 bg-amber-200/[0.08]">
                                    <Icon className="h-5 w-5 text-amber-100" />
                                </span>
                                <ArrowRight className="h-4 w-4 text-stone-600 transition group-hover:translate-x-1 group-hover:text-amber-100" />
                            </div>
                            <h2 className="mt-5 text-2xl tracking-[0.05em] text-stone-50">{item.label}</h2>
                            <p className="mt-3 text-sm leading-7 text-stone-400">{item.description}</p>
                        </Link>
                    );
                })}
            </section>

            <section className="rounded-[30px] border border-white/10 bg-white/[0.025] p-7 lg:p-8">
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">最近紀錄</p>
                        <h2 className="mt-3 text-2xl tracking-[0.05em] text-stone-50">最近的解讀與問事</h2>
                    </div>
                </div>
                {data.recentReadings.length > 0 ? (
                    <div className="mt-6 grid gap-3">
                        {data.recentReadings.map((reading) => (
                            <div key={reading.id} className="grid gap-2 rounded-[20px] border border-white/8 bg-[#120d0b] px-5 py-4 sm:grid-cols-[1fr_auto] sm:items-center">
                                <div>
                                    <p className="text-sm text-stone-100">{reading.answerTitle || reading.topic || "命理解讀"}</p>
                                    <p className="mt-1 text-xs text-stone-500">{reading.system} · {formatDate(reading.createdAt)}</p>
                                </div>
                                <span className="w-fit rounded-full border border-amber-200/15 bg-amber-50/[0.04] px-3 py-1 text-xs text-amber-100/80">{reading.status}</span>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="mt-6 rounded-[20px] border border-dashed border-white/10 p-6 text-sm leading-7 text-stone-400">
                        目前還沒有解讀紀錄。先建立命主資料，從八字、紫微或合盤開始。
                    </div>
                )}
            </section>
        </PageShell>
    );
}
