import { getEcpayConfig, parseNotification, validatePaidNotification } from "@/lib/ecpay";
import { createAdminClient } from "@/lib/supabase/admin";

function ok() {
    return new Response("1|OK", { status: 200, headers: { "Content-Type": "text/plain; charset=utf-8" } });
}

export async function POST(request: Request) {
    if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
        return new Response("0|Server not configured", { status: 500 });
    }

    let config;
    try {
        config = getEcpayConfig();
    } catch {
        return new Response("0|Server not configured", { status: 500 });
    }

    let fields;
    try {
        fields = parseNotification(await request.text());
    } catch {
        return new Response("0|Invalid form body", { status: 400 });
    }

    const merchantTradeNo = fields.MerchantTradeNo ?? "";
    if (!/^TM2[A-Za-z0-9]{1,17}$/.test(merchantTradeNo)) {
        return new Response("0|Invalid order", { status: 400 });
    }

    const admin = createAdminClient();
    const { data: order, error: orderError } = await admin
        .from("payment_orders")
        .select("id, merchant_trade_no, amount, payment_environment, status")
        .eq("merchant_trade_no", merchantTradeNo)
        .maybeSingle();

    if (orderError || !order) return new Response("0|Order not found", { status: 404 });

    let receipt;
    try {
        receipt = validatePaidNotification(
            fields,
            {
                merchantTradeNo: order.merchant_trade_no,
                environment: order.payment_environment === "production" ? "production" : "production",
                amount: order.amount,
            },
            config,
        );
    } catch {
        return new Response("0|Payment validation failed", { status: 400 });
    }

    if (!receipt.paid) {
        const isFailed = fields.RtnCode !== "1";
        const { error } = await admin
            .from("payment_orders")
            .update({
                status: isFailed ? "failed" : order.status,
                ecpay_trade_no: fields.TradeNo || null,
                payment_method: fields.PaymentType || null,
                payment_date: fields.PaymentDate || null,
                rtn_code: fields.RtnCode || null,
                rtn_msg: (fields.RtnMsg || receipt.reason).slice(0, 240),
                callback_payload: fields,
            })
            .eq("id", order.id);

        if (error) return new Response("0|Store callback failed", { status: 500 });
        return ok();
    }

    const { error } = await admin.rpc("apply_paid_order", {
        p_merchant_trade_no: merchantTradeNo,
        p_total_amount: receipt.amount,
        p_ecpay_trade_no: receipt.ecpayTradeNo,
        p_payment_method: fields.PaymentType ?? "Credit_CreditCard",
        p_payment_date: fields.PaymentDate ?? "",
        p_rtn_code: fields.RtnCode ?? "1",
        p_rtn_msg: fields.RtnMsg ?? "",
        p_callback_payload: fields,
    });

    if (error) return new Response("0|Apply payment failed", { status: 500 });
    return ok();
}
