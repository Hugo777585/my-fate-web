import { createAdminClient } from "@/lib/supabase/admin";
import { verifyCheckMacValue, type EcpayFields } from "@/lib/ecpay";

export async function POST(request: Request) {
    const hashKey = process.env.ECPAY_HASH_KEY;
    const hashIv = process.env.ECPAY_HASH_IV;
    if (!hashKey || !hashIv || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
        return new Response("0|Server not configured", { status: 500 });
    }

    const formData = await request.formData();
    const fields: EcpayFields = {};
    formData.forEach((value, key) => {
        fields[key] = String(value);
    });

    if (!verifyCheckMacValue(fields, hashKey, hashIv)) {
        return new Response("0|CheckMacValue Error", { status: 400 });
    }

    if (fields.MerchantID && process.env.ECPAY_MERCHANT_ID && fields.MerchantID !== process.env.ECPAY_MERCHANT_ID) {
        return new Response("0|Merchant mismatch", { status: 400 });
    }

    // 綠界官方模擬付款只用來驗證 ReturnURL，不可把 SimulatePaid=1 當真實付款入帳。
    if (fields.SimulatePaid === "1") {
        return new Response("1|OK");
    }

    const totalAmount = Number(fields.TradeAmt ?? fields.TotalAmount ?? 0);
    if (!Number.isInteger(totalAmount) || totalAmount <= 0 || !fields.MerchantTradeNo) {
        return new Response("0|Invalid payment data", { status: 400 });
    }

    const supabase = createAdminClient();
    const { error } = await supabase.rpc("apply_paid_order", {
        p_merchant_trade_no: fields.MerchantTradeNo,
        p_total_amount: totalAmount,
        p_ecpay_trade_no: fields.TradeNo ?? "",
        p_payment_method: fields.PaymentType ?? "",
        p_payment_date: fields.PaymentDate ?? "",
        p_rtn_code: fields.RtnCode ?? "",
        p_rtn_msg: fields.RtnMsg ?? "",
        p_callback_payload: fields,
    });

    if (error) {
        return new Response("0|Apply payment failed", { status: 500 });
    }

    return new Response("1|OK");
}
