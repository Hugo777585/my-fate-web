import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth";
import {
    buildAutoSubmitPaymentPage,
    buildCheckoutParameters,
    createMerchantTradeNo,
    getEcpayConfig,
} from "@/lib/ecpay";
import { createAdminClient } from "@/lib/supabase/admin";

const allowedPackages = new Set(["starter", "entry", "advanced", "professional"]);

export async function POST(request: Request) {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "請先登入。" }, { status: 401 });

    let config;
    try {
        config = getEcpayConfig();
    } catch (cause) {
        const message = cause instanceof Error ? cause.message : "ECPay is not configured";
        return NextResponse.json({ error: `正式金流尚未完成環境設定：${message}` }, { status: 503 });
    }

    if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
        return NextResponse.json({ error: "Supabase server credential is missing." }, { status: 503 });
    }

    const contentType = request.headers.get("content-type") ?? "";
    let packageCode = "";
    if (contentType.includes("application/json")) {
        const body = (await request.json().catch(() => null)) as { packageCode?: string } | null;
        packageCode = body?.packageCode ?? "";
    } else {
        const form = await request.formData();
        packageCode = String(form.get("packageCode") ?? "");
    }

    if (!allowedPackages.has(packageCode)) {
        return NextResponse.json({ error: "儲值方案不正確。" }, { status: 400 });
    }

    const admin = createAdminClient();
    const { data: pkg, error: packageError } = await admin
        .from("commerce_point_packages")
        .select("code, name, amount_twd, base_points, included_bonus_points")
        .eq("code", packageCode)
        .eq("is_active", true)
        .single();

    if (packageError || !pkg) {
        return NextResponse.json({ error: "找不到可用的儲值方案。" }, { status: 400 });
    }

    const merchantTradeNo = createMerchantTradeNo();
    const totalPoints = pkg.base_points + pkg.included_bonus_points;
    const { error: orderError } = await admin.from("payment_orders").insert({
        user_id: user.id,
        merchant_trade_no: merchantTradeNo,
        package_code: pkg.code,
        amount: pkg.amount_twd,
        base_points: pkg.base_points,
        bonus_points: pkg.included_bonus_points,
        total_points: totalPoints,
        status: "created",
        callback_payload: {},
        payment_environment: "production",
    });

    if (orderError) {
        return NextResponse.json({ error: orderError.message || "付款訂單建立失敗。" }, { status: 500 });
    }

    const parameters = buildCheckoutParameters(
        {
            merchantTradeNo,
            environment: "production",
            amount: pkg.amount_twd,
            itemName: `${totalPoints}枚天命幣`,
            packageCode: pkg.code,
        },
        config,
    );

    return new Response(buildAutoSubmitPaymentPage(parameters), {
        status: 200,
        headers: {
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
    });
}
