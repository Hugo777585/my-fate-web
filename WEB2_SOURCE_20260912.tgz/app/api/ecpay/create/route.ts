import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth";
import { createCheckMacValue, formatTaipeiTradeDate, getEcpayAction, type EcpayFields } from "@/lib/ecpay";
import { createAdminClient } from "@/lib/supabase/admin";

const allowedPackages = new Set(["starter", "entry", "advanced", "professional"]);

function buildMerchantTradeNo(date = new Date()) {
    const dateDigits = formatTaipeiTradeDate(date).replace(/\D/g, "").slice(2);
    const suffix = randomUUID().replace(/-/g, "").slice(0, 6).toUpperCase();
    return `TM${dateDigits}${suffix}`;
}

export async function POST(request: Request) {
    const user = await getCurrentUser();
    if (!user) {
        return NextResponse.json({ error: "請先登入。" }, { status: 401 });
    }

    const merchantId = process.env.ECPAY_MERCHANT_ID;
    const hashKey = process.env.ECPAY_HASH_KEY;
    const hashIv = process.env.ECPAY_HASH_IV;
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
    if (!merchantId || !hashKey || !hashIv || !siteUrl || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
        return NextResponse.json({ error: "正式金流尚未完成環境設定。" }, { status: 503 });
    }

    const body = (await request.json().catch(() => null)) as { packageCode?: string } | null;
    const packageCode = body?.packageCode ?? "";
    if (!allowedPackages.has(packageCode)) {
        return NextResponse.json({ error: "儲值方案不正確。" }, { status: 400 });
    }

    const ecpayEnvironment: "test" | "production" = process.env.ECPAY_ENVIRONMENT === "test" ? "test" : "production";
    const paymentEnvironment = ecpayEnvironment === "test" ? "stage" : "production";
    const admin = createAdminClient();
    const { data: pkg, error: packageError } = await admin
        .from("commerce_point_packages")
        .select("code, name, amount_twd, base_points, included_bonus_points")
        .eq("code", packageCode)
        .eq("is_active", true)
        .single();

    if (packageError || !pkg) {
        return NextResponse.json({ error: "找不到可用的儲值方案。" }, { status: 400 });
    }

    const merchantTradeNo = buildMerchantTradeNo();
    const totalPoints = pkg.base_points + pkg.included_bonus_points;
    const { data: order, error: orderError } = await admin
        .from("payment_orders")
        .insert({
            user_id: user.id,
            merchant_trade_no: merchantTradeNo,
            package_code: pkg.code,
            amount: pkg.amount_twd,
            base_points: pkg.base_points,
            bonus_points: pkg.included_bonus_points,
            total_points: totalPoints,
            status: "created",
            callback_payload: {},
            payment_environment: paymentEnvironment,
        })
        .select("id")
        .single();

    if (orderError || !order) {
        return NextResponse.json({ error: orderError?.message ?? "付款訂單建立失敗。" }, { status: 500 });
    }

    const baseUrl = siteUrl.replace(/\/$/, "");
    const fields: EcpayFields = {
        MerchantID: merchantId,
        MerchantTradeNo: merchantTradeNo,
        MerchantTradeDate: formatTaipeiTradeDate(),
        PaymentType: "aio",
        TotalAmount: String(pkg.amount_twd),
        TradeDesc: "天命智庫天命幣儲值",
        ItemName: `${totalPoints}枚天命幣`,
        ReturnURL: `${baseUrl}/api/ecpay/callback`,
        ClientBackURL: `${baseUrl}/wallet?payment=return`,
        ChoosePayment: "ALL",
        EncryptType: "1",
        CustomField1: order.id,
        CustomField2: paymentEnvironment,
    };
    fields.CheckMacValue = createCheckMacValue(fields, hashKey, hashIv);

    return NextResponse.json({
        action: getEcpayAction(ecpayEnvironment),
        fields,
    });
}
