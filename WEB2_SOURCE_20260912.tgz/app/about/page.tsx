import Link from "next/link";
import { ArrowRight, Award, ChefHat, Compass, Layers3 } from "lucide-react";

import { PageShell } from "@/components/page-shell";

const experience = [
    {
        icon: ChefHat,
        title: "近三十年烘焙與餐飲實務",
        text: "曾任五星級飯店西點主廚，也做過商品設計、活動甜點與實際現場管理。長年工作經驗讓我看事情更重視細節、節奏與可落地性。",
    },
    {
        icon: Award,
        title: "把職人標準帶進命理服務",
        text: "排盤只是開始。資料是否正確、脈絡有沒有說清楚、客戶最後能不能知道下一步怎麼做，這些才是我在意的地方。",
    },
    {
        icon: Layers3,
        title: "八字與紫微交叉閱讀",
        text: "個人深度解讀與雙人合盤會依問題選擇不同視角，不把所有人套進同一段制式答案。",
    },
] as const;

export default function AboutPage() {
    return (
        <PageShell
            eyebrow="ABOUT HUGO"
            title="命理是參考，也是把複雜事情整理清楚的方法。"
            description="天命智庫由 HUGO 建立。我把多年職人工作養成的細節要求，用在排盤、資料核對與實際解讀上。網站負責把資料整理好；真正重要的判斷，仍要回到每一個人的現況。"
            actions={
                <>
                    <Link href="/auth" className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950">
                        免費建立命盤
                    </Link>
                    <Link href="/compatibility" className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]">
                        查看兩人合盤
                    </Link>
                </>
            }
        >
            <section className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
                <article className="rounded-[30px] border border-amber-300/16 bg-[linear-gradient(180deg,rgba(53,29,17,0.9),rgba(18,12,10,0.98))] p-8">
                    <p className="text-xs uppercase tracking-[0.36em] text-amber-200/55">Founder</p>
                    <p className="mt-5 text-4xl tracking-[0.08em] text-stone-50">HUGO</p>
                    <p className="mt-3 text-sm tracking-[0.18em] text-amber-100/65">天命智庫創辦人</p>
                    <div className="mt-7 rounded-[22px] border border-white/9 bg-white/[0.03] p-5">
                        <Compass className="h-5 w-5 text-amber-200" />
                        <p className="mt-4 text-sm leading-8 text-stone-300">
                            我比較在意的不是把話講得玄，而是把一張盤裡真正和眼前生活有關的部分抓出來。能看懂，才有辦法拿來做決定。
                        </p>
                    </div>
                </article>
                <div className="grid gap-4">
                    {experience.map((item) => {
                        const Icon = item.icon;
                        return (
                            <article key={item.title} className="rounded-[28px] border border-white/10 bg-white/[0.03] p-7">
                                <Icon className="h-5 w-5 text-amber-200" />
                                <h2 className="mt-4 text-2xl tracking-[0.05em] text-stone-50">{item.title}</h2>
                                <p className="mt-3 text-sm leading-8 text-stone-300">{item.text}</p>
                            </article>
                        );
                    })}
                </div>
            </section>

            <section className="rounded-[30px] border border-white/10 bg-white/[0.025] p-8 lg:p-10">
                <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">服務原則</p>
                <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">先把資料與脈絡弄對，再談結論。</h2>
                <p className="mt-5 max-w-4xl text-sm leading-8 text-stone-300">
                    免費基本盤負責讓你先看到自己的命盤結構；個人深度解讀再處理命局與歲運；兩人合盤則把雙方資料放到同一個脈絡中比較。網站不需要把每件事講得很滿，真正需要深入的地方，再由 HUGO 接手。
                </p>
                <Link href="/auth" className="mt-7 inline-flex items-center gap-2 text-sm text-amber-100 hover:text-amber-50">
                    從免費基本盤開始 <ArrowRight className="h-4 w-4" />
                </Link>
            </section>
        </PageShell>
    );
}
