import Image from "next/image";
import Link from "next/link";
import { ArrowDownToLine, ArrowRight, Award, ChefHat, Compass, GraduationCap, Layers3, Sparkles } from "lucide-react";

import { PageShell } from "@/components/page-shell";
import { XuanjingBridge } from "@/components/xuanjing-bridge";

const experience = [
    {
        icon: ChefHat,
        title: "三十年甜點與餐飲實務",
        text: "從高中開始學烘焙，後來進入五星級飯店與餐飲體系，累積商品研發、現場執行與甜點設計經驗。長期做的是把一個抽象概念，變成真正能被看見、被品嚐的作品。",
    },
    {
        icon: GraduationCap,
        title: "技術教學與團隊帶領",
        text: "除了第一線製作，也做過甜點技術教學、現場示範、學員指導與團隊帶領。教學讓我更在意：一件複雜的事，能不能被拆成別人真正聽得懂、做得到的步驟。",
    },
    {
        icon: Award,
        title: "品牌活動與商品設計",
        text: "曾參與 Dior、BMW X5 等品牌活動甜點，也為 Lamborghini VIP 發表會設計甜點；該場活動限量招待 33 位 VIP。不同品牌、場合與客群，都需要不同的設計語言。",
    },
    {
        icon: Layers3,
        title: "從甜點設計到命理系統",
        text: "現在做天命智庫與玄境，做事的方法沒有變：把大量資訊、規則與細節整理成清楚的層次，讓使用者先看懂，再決定要不要深入。",
    },
] as const;

const gallery = [
    { src: "/hugo/teaching-demo.jpg", title: "現場示範", text: "技術教學與操作示範" },
    { src: "/hugo/teaching-class.jpg", title: "教學現場", text: "把製程拆成學員能跟上的步驟" },
    { src: "/hugo/teaching-coach.jpg", title: "實作指導", text: "從手法、節奏到成品逐項調整" },
    { src: "/hugo/lamborghini-vip.jpg", title: "Lamborghini VIP 發表會", text: "33 位 VIP 專屬活動甜點設計" },
    { src: "/hugo/dior-production.jpg", title: "Dior 品牌活動", text: "品牌識別與甜點工藝結合" },
    { src: "/hugo/mother-heart.jpg", title: "母親之心", text: "日月千禧酒店母親節限定作品" },
    { src: "/hugo/white-rose.jpg", title: "白巧克力玫瑰", text: "花瓣逐片塑形、手工組裝" },
    { src: "/hugo/afternoon-tea.jpg", title: "餐飲體驗設計", text: "從甜點單品延伸到整體呈現" },
] as const;

export default function AboutPage() {
    return (
        <PageShell
            eyebrow="ABOUT HUGO"
            title="HUGO 黃士恩｜把複雜的事，整理成看得懂的作品。"
            description="以前，我用食材、巧克力、蛋糕與餐桌，把客戶的需求做成甜點；現在，我把八字、紫微與關係資料整理成更直觀的人生閱讀。工具變了，但對細節、結構與使用者感受的要求沒有變。"
            actions={
                <>
                    <Link href="/auth" className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950">
                        免費建立命盤
                    </Link>
                    <a
                        href="/hugo/HUGO_pastry_portfolio_2026.pdf"
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        <ArrowDownToLine className="h-4 w-4" />
                        查看 HUGO 作品集
                    </a>
                </>
            }
        >
            <section className="grid gap-5 lg:grid-cols-[0.92fr_1.08fr]">
                <article className="relative min-h-[520px] overflow-hidden rounded-[32px] border border-amber-300/16 bg-[#120d0b]">
                    <Image src="/hugo/teaching-demo.jpg" alt="HUGO 黃士恩甜點技術教學現場" fill priority className="object-cover object-center" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-7 lg:p-8">
                        <p className="text-xs uppercase tracking-[0.34em] text-amber-200/65">HUGO 黃士恩</p>
                        <h2 className="mt-3 text-3xl tracking-[0.06em] text-white">甜點設計 · 技術教學 · 天命智庫</h2>
                        <p className="mt-3 max-w-xl text-sm leading-7 text-stone-200/90">三十年甜點與餐飲實務，從第一線製作、商品設計、品牌活動到教學與團隊帶領。</p>
                    </div>
                </article>

                <div className="grid gap-4 sm:grid-cols-2">
                    {experience.map((item) => {
                        const Icon = item.icon;
                        return (
                            <article key={item.title} className="rounded-[28px] border border-white/10 bg-white/[0.03] p-6 lg:p-7">
                                <Icon className="h-5 w-5 text-amber-200" />
                                <h2 className="mt-4 text-2xl tracking-[0.05em] text-stone-50">{item.title}</h2>
                                <p className="mt-3 text-sm leading-8 text-stone-300">{item.text}</p>
                            </article>
                        );
                    })}
                </div>
            </section>

            <section className="rounded-[32px] border border-amber-300/14 bg-[linear-gradient(135deg,rgba(48,27,16,0.78),rgba(14,10,9,0.98))] p-7 lg:p-9">
                <div className="grid gap-7 lg:grid-cols-[0.7fr_1.3fr] lg:items-center">
                    <div>
                        <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">DESIGN MINDSET</p>
                        <h2 className="mt-4 text-3xl leading-tight tracking-[0.06em] text-stone-50">以前做甜點，現在做天命智庫。</h2>
                    </div>
                    <div className="space-y-4 text-sm leading-8 text-stone-300">
                        <p>以前是用天然食材、巧克力、蛋糕和餐桌，將客戶的需求量身打造，設計成一個可以被感受到的甜點作品。</p>
                        <p>現在做天命智庫與玄境，方法仍然一樣：把抽象繁複的命理邏輯，轉化為直觀、清晰、具啟發性的閱讀，讓人看清自己的優勢、盲點與下一步。</p>
                        <p className="text-amber-100">命理是工具，而非定數。真正握方向盤的人，仍然是自己。</p>
                    </div>
                </div>
            </section>

            <section>
                <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
                    <div>
                        <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">PASTRY WORKS & TEACHING</p>
                        <h2 className="mt-3 text-3xl tracking-[0.06em] text-stone-50">作品不是履歷裝飾，而是做事方式的證據。</h2>
                    </div>
                    <p className="max-w-xl text-sm leading-7 text-stone-400">從教學、品牌活動到商品作品，這些照片保留的是「如何把概念做成成果」的過程。</p>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    {gallery.map((item, index) => (
                        <article key={item.src} className={`group overflow-hidden rounded-[26px] border border-white/9 bg-white/[0.025] ${index === 3 ? "sm:col-span-2 xl:col-span-2" : ""}`}>
                            <div className={`relative ${index === 3 ? "aspect-[16/8.5]" : "aspect-[4/3]"}`}>
                                <Image src={item.src} alt={item.title} fill className="object-cover transition duration-500 group-hover:scale-[1.025]" />
                            </div>
                            <div className="p-5">
                                <p className="text-lg tracking-[0.04em] text-stone-50">{item.title}</p>
                                <p className="mt-2 text-sm leading-6 text-stone-400">{item.text}</p>
                            </div>
                        </article>
                    ))}
                </div>
            </section>

            <section className="grid gap-4 md:grid-cols-3">
                <article className="rounded-[28px] border border-white/9 bg-white/[0.025] p-6">
                    <Sparkles className="h-5 w-5 text-amber-200" />
                    <h3 className="mt-4 text-xl tracking-[0.05em] text-stone-50">Dior / BMW X5</h3>
                    <p className="mt-3 text-sm leading-7 text-stone-400">把品牌識別、活動情境與甜點工藝放在一起，不只是做一份好吃的甜點，而是做完整的體驗。</p>
                </article>
                <article className="rounded-[28px] border border-white/9 bg-white/[0.025] p-6">
                    <Award className="h-5 w-5 text-amber-200" />
                    <h3 className="mt-4 text-xl tracking-[0.05em] text-stone-50">Lamborghini VIP 發表會</h3>
                    <p className="mt-3 text-sm leading-7 text-stone-400">限量招待 33 位 VIP 的私人發表會，由 HUGO 負責甜點設計，讓甜點成為品牌活動氛圍的一部分。</p>
                </article>
                <article className="rounded-[28px] border border-white/9 bg-white/[0.025] p-6">
                    <Compass className="h-5 w-5 text-amber-200" />
                    <h3 className="mt-4 text-xl tracking-[0.05em] text-stone-50">日月千禧「母親之心」</h3>
                    <p className="mt-3 text-sm leading-7 text-stone-400">從造型、色彩、金箔與愛心符號，把「謝謝妳，妳辛苦了」轉化為一個可以被分享的母親節作品。</p>
                </article>
            </section>

            <section className="rounded-[30px] border border-white/10 bg-white/[0.025] p-8 lg:p-10">
                <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">天命智庫的服務原則</p>
                <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">先把資料與脈絡弄對，再談結論。</h2>
                <p className="mt-5 max-w-4xl text-sm leading-8 text-stone-300">免費基本盤先讓你看到命盤結構；八字、紫微與雙人合盤都採由淺入深的閱讀方式。當你真的需要處理感情、工作、財運、關係或時間節點，再進入完整深度解讀。</p>
                <Link href="/auth" className="mt-7 inline-flex items-center gap-2 text-sm text-amber-100 hover:text-amber-50">
                    從免費基本盤開始 <ArrowRight className="h-4 w-4" />
                </Link>
            </section>

            <XuanjingBridge />
        </PageShell>
    );
}
