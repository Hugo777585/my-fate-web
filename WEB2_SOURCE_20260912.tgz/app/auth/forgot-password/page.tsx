import { ForgotPasswordForm } from "@/components/forgot-password-form";
import { PageShell } from "@/components/page-shell";

export default function ForgotPasswordPage() {
    return (
        <PageShell
            eyebrow="Member Access"
            title="找回你的會員帳號"
            description="使用註冊 Email 收取重設密碼信，完成後即可繼續使用原本的命主資料、命盤與會員紀錄。"
        >
            <ForgotPasswordForm />
        </PageShell>
    );
}
