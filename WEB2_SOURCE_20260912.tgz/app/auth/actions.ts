"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { createClient } from "@/lib/supabase/server";

export type AuthActionState = {
    error?: string;
    success?: string;
    fieldErrors?: {
        email?: string;
        password?: string;
    };
};

function isValidEmail(email: string) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function formatSupabaseAuthError(context: "login" | "signup", rawMessage: string) {
    const message = rawMessage.toLowerCase();

    if (message.includes("invalid login credentials")) {
        return "Email 或密碼不正確。";
    }

    if (message.includes("email not confirmed") || message.includes("email_not_confirmed")) {
        return "此帳號尚未完成 Email 驗證，請先到信箱完成驗證。";
    }

    if (message.includes("user already registered") || message.includes("already registered")) {
        return "這個 Email 已註冊，請直接登入或改用其他 Email。";
    }

    if (message.includes("password") && message.includes("at least")) {
        return "密碼至少需要 6 碼。";
    }

    if (message.includes("invalid email")) {
        return "Email 格式不正確。";
    }

    if (message.includes("rate limit") || message.includes("too many")) {
        return "操作太頻繁，請稍後再試。";
    }

    if (context === "signup") {
        return "註冊失敗，請稍後再試或更換 Email。";
    }

    return "登入失敗，請確認帳號密碼或稍後再試。";
}

function getCredentials(formData: FormData, options?: { requireStrongPassword?: boolean }) {
    const email = String(formData.get("email") ?? "").trim();
    const password = String(formData.get("password") ?? "");
    const fieldErrors: NonNullable<AuthActionState["fieldErrors"]> = {};

    if (!email) {
        fieldErrors.email = "請輸入 Email。";
    } else if (!isValidEmail(email)) {
        fieldErrors.email = "Email 格式不正確。";
    }

    if (!password) {
        fieldErrors.password = "請輸入密碼。";
    } else if (options?.requireStrongPassword && password.length < 6) {
        fieldErrors.password = "密碼至少需要 6 碼。";
    }

    if (fieldErrors.email || fieldErrors.password) {
        return {
            error: "請先修正欄位後再送出。",
            fieldErrors,
        } satisfies AuthActionState;
    }

    return { email, password };
}

export async function loginAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const credentials = getCredentials(formData);
    if ("error" in credentials) {
        return credentials;
    }

    const supabase = await createClient();
    const { error } = await supabase.auth.signInWithPassword(credentials);

    if (error) {
        return {
            error: formatSupabaseAuthError("login", error.message),
        };
    }

    revalidatePath("/", "layout");
    redirect("/dashboard");
}

export async function signupAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const credentials = getCredentials(formData, { requireStrongPassword: true });
    if ("error" in credentials) {
        return credentials;
    }

    const supabase = await createClient();
    const { data, error } = await supabase.auth.signUp({
        email: credentials.email,
        password: credentials.password,
    });

    if (error) {
        return {
            error: formatSupabaseAuthError("signup", error.message),
        };
    }

    revalidatePath("/", "layout");

    if (data.session) {
        redirect("/dashboard");
    }

    return {
        success: "註冊成功，若你的 Supabase 啟用了 Email 驗證，請先到信箱完成確認。",
    };
}

export async function logoutAction() {
    const supabase = await createClient();
    await supabase.auth.signOut();
    revalidatePath("/", "layout");
    redirect("/auth");
}
