"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { createClient } from "@/lib/supabase/server";

export type AuthActionState = {
    error?: string;
    success?: string;
    fieldErrors?: {
        email?: string;
        password?: string;
        confirmPassword?: string;
    };
};

function isValidEmail(email: string) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getSiteUrl() {
    const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
    return (configured || "https://hugo-tianming-web2.vercel.app").replace(/\/$/, "");
}

function formatSupabaseAuthError(context: "login" | "signup" | "reset" | "update", rawMessage: string) {
    const message = rawMessage.toLowerCase();

    if (message.includes("invalid login credentials")) {
        return "Email 或密碼不正確。";
    }

    if (message.includes("email not confirmed") || message.includes("email_not_confirmed")) {
        return "此帳號尚未完成 Email 驗證，請先到信箱完成驗證。";
    }

    if (message.includes("user already registered") || message.includes("already registered")) {
        return "此 Email 已註冊，請直接登入或使用「忘記密碼」。";
    }

    if (message.includes("password") && message.includes("at least")) {
        return "密碼至少需要 6 碼。";
    }

    if (message.includes("invalid email")) {
        return "Email 格式不正確。";
    }

    if (message.includes("rate limit") || message.includes("too many") || message.includes("over_email_send_rate_limit")) {
        return "操作太頻繁，請稍後再試。";
    }

    if (context === "signup") {
        return "註冊失敗，請稍後再試。";
    }

    if (context === "reset") {
        return "目前無法寄出重設密碼信，請稍後再試。";
    }

    if (context === "update") {
        return "密碼更新失敗，請重新開啟重設密碼信後再試。";
    }

    return "登入失敗，請確認帳號密碼或稍後再試。";
}

function getCredentials(formData: FormData, options?: { requireStrongPassword?: boolean }) {
    const email = String(formData.get("email") ?? "").trim();
    const password = String(formData.get("password") ?? "");
    const fieldErrors: NonNullable<AuthActionState["fieldErrors"]> = {};

    if (!email) {
        fieldErrors.email = "請輸入 Email。";
    } else if (!isValidEmail(email)) {
        fieldErrors.email = "Email 格式不正確。";
    }

    if (!password) {
        fieldErrors.password = "請輸入密碼。";
    } else if (options?.requireStrongPassword && password.length < 6) {
        fieldErrors.password = "密碼至少需要 6 碼。";
    }

    if (fieldErrors.email || fieldErrors.password) {
        return {
            error: "請先修正欄位後再送出。",
            fieldErrors,
        } satisfies AuthActionState;
    }

    return { email, password };
}

export async function loginAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const credentials = getCredentials(formData);
    if ("error" in credentials) {
        return credentials;
    }

    const supabase = await createClient();
    const { error } = await supabase.auth.signInWithPassword(credentials);

    if (error) {
        return {
            error: formatSupabaseAuthError("login", error.message),
        };
    }

    revalidatePath("/", "layout");
    redirect("/dashboard");
}

export async function signupAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const credentials = getCredentials(formData, { requireStrongPassword: true });
    if ("error" in credentials) {
        return credentials;
    }

    const supabase = await createClient();
    const siteUrl = getSiteUrl();
    const { data, error } = await supabase.auth.signUp({
        email: credentials.email,
        password: credentials.password,
        options: {
            emailRedirectTo: `${siteUrl}/auth/callback?next=/dashboard`,
        },
    });

    if (error) {
        return {
            error: formatSupabaseAuthError("signup", error.message),
        };
    }

    revalidatePath("/", "layout");

    if (data.session) {
        // Supabase 若未開啟「Confirm email」，註冊後會直接取得 session。
        // 保持相容，讓會員可以直接使用；正式環境仍應在 Supabase 開啟 Email 驗證。
        redirect("/dashboard");
    }

    return {
        success: "註冊申請已送出。請到 Email 信箱完成驗證，驗證後即可登入；若沒有看到信件，也請檢查垃圾郵件。",
    };
}

export async function forgotPasswordAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const email = String(formData.get("email") ?? "").trim();
    const fieldErrors: NonNullable<AuthActionState["fieldErrors"]> = {};

    if (!email) {
        fieldErrors.email = "請輸入註冊時使用的 Email。";
    } else if (!isValidEmail(email)) {
        fieldErrors.email = "Email 格式不正確。";
    }

    if (fieldErrors.email) {
        return {
            error: "請先修正 Email 後再送出。",
            fieldErrors,
        };
    }

    const supabase = await createClient();
    const siteUrl = getSiteUrl();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${siteUrl}/auth/callback?next=/auth/update-password`,
    });

    if (error) {
        return {
            error: formatSupabaseAuthError("reset", error.message),
        };
    }

    // 不透露 Email 是否存在，避免被用來枚舉會員帳號。
    return {
        success: "如果這個 Email 已註冊，重設密碼信已寄出。請到信箱點擊連結；若沒有看到，也請檢查垃圾郵件。",
    };
}

export async function updatePasswordAction(
    _prevState: AuthActionState,
    formData: FormData,
): Promise<AuthActionState> {
    const password = String(formData.get("password") ?? "");
    const confirmPassword = String(formData.get("confirmPassword") ?? "");
    const fieldErrors: NonNullable<AuthActionState["fieldErrors"]> = {};

    if (!password) {
        fieldErrors.password = "請輸入新密碼。";
    } else if (password.length < 6) {
        fieldErrors.password = "新密碼至少需要 6 碼。";
    }

    if (!confirmPassword) {
        fieldErrors.confirmPassword = "請再次輸入新密碼。";
    } else if (password && confirmPassword !== password) {
        fieldErrors.confirmPassword = "兩次輸入的密碼不一致。";
    }

    if (fieldErrors.password || fieldErrors.confirmPassword) {
        return {
            error: "請先修正欄位後再送出。",
            fieldErrors,
        };
    }

    const supabase = await createClient();
    const { data: userData, error: userError } = await supabase.auth.getUser();

    if (userError || !userData.user) {
        return {
            error: "重設連結已失效或登入狀態不存在，請重新申請忘記密碼。",
        };
    }

    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
        return {
            error: formatSupabaseAuthError("update", error.message),
        };
    }

    revalidatePath("/", "layout");
    redirect("/dashboard?password=updated");
}

export async function logoutAction() {
    const supabase = await createClient();
    await supabase.auth.signOut();
    revalidatePath("/", "layout");
    redirect("/auth");
}
