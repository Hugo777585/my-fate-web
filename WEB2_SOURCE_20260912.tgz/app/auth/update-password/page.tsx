import { redirect } from "next/navigation";

import { PageShell } from "@/components/page-shell";
import { UpdatePasswordForm } from "@/components/update-password-form";
import { getCurrentUser } from "@/lib/auth";

export default async function UpdatePasswordPage() {
    const user = await getCurrentUser();

    if (!user) {
        redirect("/auth/forgot-password");
    }

    return (
        <PageShell
            eyebrow="Member Access"
            title="重新設定登入密碼"
            description="重設成功後仍會保留目前會員登入狀態，不需要再次輸入帳號。"
        >
            <UpdatePasswordForm />
        </PageShell>
    );
}
