import { PageShell } from "@/components/page-shell";
import { AuthForms } from "@/components/auth-forms";
import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function AuthPage() {
    const user = await getCurrentUser();

    if (user) {
        redirect("/dashboard");
    }

    return (
        <PageShell
            eyebrow="Member Access"
            title="登入天命智庫，回到你的命盤與會員資料。"
            description="會員可登入或註冊帳號，命主資料、命盤與錢包紀錄只在自己的會員區顯示。"
        >
            <AuthForms />
        </PageShell>
    );
}
