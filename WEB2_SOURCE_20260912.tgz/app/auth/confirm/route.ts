import { type EmailOtpType } from "@supabase/supabase-js";
import { NextResponse, type NextRequest } from "next/server";

import { createClient } from "@/lib/supabase/server";

function safeNextPath(value: string | null, fallback = "/dashboard") {
    if (!value || !value.startsWith("/") || value.startsWith("//")) return fallback;
    return value;
}

export async function GET(request: NextRequest) {
    const requestUrl = new URL(request.url);
    const tokenHash = requestUrl.searchParams.get("token_hash");
    const type = requestUrl.searchParams.get("type") as EmailOtpType | null;
    const next = safeNextPath(
        requestUrl.searchParams.get("next"),
        type === "recovery" ? "/auth/update-password" : "/dashboard",
    );

    if (tokenHash && type) {
        const supabase = await createClient();
        const { error } = await supabase.auth.verifyOtp({
            type,
            token_hash: tokenHash,
        });

        if (!error) {
            return NextResponse.redirect(new URL(next, requestUrl.origin));
        }
    }

    return NextResponse.redirect(new URL("/auth?auth_error=link", requestUrl.origin));
}
