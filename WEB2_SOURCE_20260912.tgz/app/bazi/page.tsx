import Link from "next/link";

import { BaziModeTabs } from "@/components/bazi-mode-tabs";
import { PageShell } from "@/components/page-shell";
import { requireUser } from "@/lib/auth";
import {
    type BaziChart,
} from "@/lib/bazi-fixture";
import {
    loadBaziPageData,
    type BaziPageSearchParams,
    type BaziWorkspaceMode,
} from "@/lib/bazi-provider";
import { getBaziClassicsForTiming } from "@/lib/bazi-classics";

type BaziPageProps = {
    searchParams: Promise<BaziPageSearchParams>;
};

const buildChecklist = [
    "日主摘要卡與五行強弱條",
    "四柱主表與藏干 / 十神資訊",
    "大運、流年與深度解讀入口",
] as const;

const elementLabels = [
    { key: "wood", label: "木" },
    { key: "fire", label: "火" },
    { key: "earth", label: "土" },
    { key: "metal", label: "金" },
    { key: "water", label: "水" },
] as const;
const pillarColumns = [
    { key: "year", label: "年柱", highlight: false },
    { key: "month", label: "月柱", highlight: false },
    { key: "day", label: "日柱", highlight: true },
    { key: "hour", label: "時柱", highlight: false },
] as const;
const pillarRows = [
    { key: "stemTenGod", label: "十神" },
    { key: "stem", label: "天干" },
    { key: "branch", label: "地支" },
    { key: "hiddenStems", label: "藏干" },
    { key: "hiddenStemTenGods", label: "藏干十神" },
    { key: "growthStage", label: "十二長生" },
    { key: "nayin", label: "納音" },
    { key: "shensha", label: "神煞" },
    { key: "voidBranches", label: "空亡" },
] as const;
const luckPillarSlots = Array.from({ length: 8 }, (_, index) => ({
    order: index + 1,
    label: `第 ${index + 1} 柱`,
}));
const aiTopics = ["事業", "情感", "財局", "康健", "時運"] as const;
const modeTabs = [
    {
        key: "natal",
        title: "本命盤",
        description: "聚焦日主、四柱與五行結構",
    },
    {
        key: "timing",
        title: "大運流年",
        description: "聚焦時間軸、起運與年份切換",
    },
    {
        key: "reading",
        title: "解讀記錄",
        description: "聚焦 LOT 提問與 Reading 狀態",
    },
] as const;
const modeFocusCards = [
    {
        key: "natal",
        eyebrow: "本命焦點",
        title: "本命盤模式",
        description: "主看日主、四柱主表、五行強弱與命局骨架。",
        accent: "gold",
        checkpoints: ["日主摘要", "四柱主表", "五行強弱條"],
    },
    {
        key: "timing",
        eyebrow: "時序焦點",
        title: "大運流年模式",
        description: "主看起運點、大運時間軸、流年入口與年度切換。",
        accent: "gold",
        checkpoints: ["起運點", "大運時間軸", "流年入口"],
    },
    {
        key: "reading",
        eyebrow: "解讀焦點",
        title: "解讀記錄模式",
        description: "主看 LOT 建議題、提問輸入區與已解鎖 Reading。",
        accent: "cyan",
        checkpoints: ["LOT 建議題", "提問輸入區", "Reading 狀態"],
    },
] as const;
const aiLotCards = [
    {
        id: "lot-1",
        label: "LOT 1",
        title: "目前這個命主最值得先看的主題是什麼？",
    },
    {
        id: "lot-2",
        label: "LOT 2",
        title: "如果只先看一個流年切面，哪個方向最關鍵？",
    },
] as const;
const timingChecklist = [
    "起運點依三日一歲、一日四個月、一小時五天折算",
    "順逆排固定採陽男陰女順、陰男陽女逆",
    "起運前先確認命主性別、生日、時辰、出生地都齊備",
] as const;
const readingChecklist = [
    "AI 提問前必須先綁定命主，避免上下文漂移",
    "命主資料未齊時，只保留版位，不開放正式提問",
    "只有成功產生可保存 Reading 才扣點，已解鎖內容可續讀",
] as const;
const readingTopicLabels = {
    career: "事業",
    relationship: "情感",
    wealth: "財局",
    health: "康健",
    timing: "時運",
} as const;
const missingFieldLabels = {
    gender: "性別",
    birthDate: "生日",
    birthTimeLabel: "時辰",
    birthPlace: "出生地",
} as const;

function buildBaziHref(profileId: string | undefined, mode: BaziWorkspaceMode, annual?: number) {
    return {
        pathname: "/bazi",
        query: {
            ...(profileId ? { profile: profileId } : {}),
            mode,
            ...(annual ? { annual } : {}),
        },
    };
}

function getPillarHeaderValue(chart: BaziChart | null, pillarKey: (typeof pillarColumns)[number]["key"]) {
    const pillar = chart?.status === "ready" ? chart.fourPillars?.[pillarKey] : undefined;

    if (!pillar) {
        return null;
    }

    return `${pillar.stem}${pillar.branch}`;
}

function getPillarCellValue(
    chart: BaziChart | null,
    pillarKey: (typeof pillarColumns)[number]["key"],
    rowKey: (typeof pillarRows)[number]["key"],
    hasCompleteProfileData: boolean,
) {
    const pillar = chart?.status === "ready" ? chart.fourPillars?.[pillarKey] : undefined;

    if (!pillar) {
        return hasCompleteProfileData ? "待計算" : "資料不足";
    }

    switch (rowKey) {
        case "stemTenGod":
            return pillar.stemTenGod;
        case "stem":
            return pillar.stem;
        case "branch":
            return pillar.branch;
        case "hiddenStems":
            return pillar.hiddenStems.map((item) => item.stem).join(" / ");
        case "hiddenStemTenGods":
            return pillar.hiddenStemTenGods.join(" / ");
        case "growthStage":
            return pillar.growthStage;
        case "nayin":
            return pillar.nayin;
        case "shensha":
            return pillar.shensha.join(" / ");
        case "voidBranches":
            return pillar.voidBranches.join(" / ");
        default:
            return "待計算";
    }
}

function getSectionStateLabel(hasProfile: boolean, hasCompleteProfileData: boolean) {
    if (!hasProfile) {
        return "尚未選定";
    }

    return hasCompleteProfileData ? "預覽資料已載入" : "前置資料待補齊";
}

function getSectionStateClasses(hasProfile: boolean, hasCompleteProfileData: boolean, accent: "gold" | "cyan") {
    if (!hasProfile) {
        return "border-white/10 bg-white/[0.03] text-stone-400";
    }

    if (!hasCompleteProfileData) {
        return accent === "cyan"
            ? "border-cyan-300/14 bg-cyan-50/[0.03] text-cyan-100/80"
            : "border-amber-300/14 bg-amber-50/[0.03] text-amber-100/80";
    }

    return accent === "cyan"
        ? "border-cyan-300/26 bg-cyan-50/[0.08] text-cyan-50 shadow-[0_0_18px_rgba(34,211,238,0.08)]"
        : "border-amber-300/26 bg-amber-50/[0.08] text-amber-50 shadow-[0_0_18px_rgba(251,191,36,0.08)]";
}

function getReadingStatusLabel(status: "locked" | "available" | "generating" | "failed") {
    switch (status) {
        case "available":
            return "可續讀";
        case "generating":
            return "生成中";
        case "failed":
            return "生成失敗";
        case "locked":
        default:
            return "尚未解鎖";
    }
}

function getReadingTopicLabel(topic: keyof typeof readingTopicLabels | undefined) {
    return topic ? readingTopicLabels[topic] : "未定主題";
}

function getStrongestElementLabel(balance: NonNullable<BaziChart["elementBalance"]> | undefined) {
    if (!balance) {
        return null;
    }

    const strongest = Object.entries(balance).sort(([, left], [, right]) => right.percentage - left.percentage)[0];

    if (!strongest) {
        return null;
    }

    const [key, value] = strongest;
    const label = elementLabels.find((item) => item.key === key)?.label ?? key;
    return `${label} ${value.label}`;
}

export default async function BaziPage({ searchParams }: BaziPageProps) {
    const user = await requireUser();
    const resolvedSearchParams = await searchParams;
    const {
        selectedProfile,
        activeMode,
        workspaceData,
        chart,
        chartInput,
        hasChartInput,
        missingFieldKeys,
        readingBundle,
    } = await loadBaziPageData(user.id, resolvedSearchParams);
    const missingFields = missingFieldKeys.map((field) => missingFieldLabels[field]);
    const hasCompleteProfileData = Boolean(selectedProfile) && hasChartInput;
    const requiredFieldCount = 4;
    const readyFieldCount = selectedProfile ? requiredFieldCount - missingFields.length : 0;
    const activeChart = selectedProfile ? chart : null;
    const dayMasterSummary = activeChart?.status === "ready" ? activeChart.dayMasterSummary : undefined;
    const elementBalance = activeChart?.status === "ready" ? activeChart.elementBalance : undefined;
    const luckCycle = activeChart?.status === "ready" ? activeChart.luckCycle : undefined;
    const annuals = activeChart?.status === "ready" ? activeChart.annuals : undefined;
    const selectedAnnual = annuals?.find((annual) => annual.isSelected) ?? annuals?.[0];
    const currentLuckPillar = luckCycle?.pillars.find((pillar) => pillar.isCurrent) ?? luckCycle?.pillars[0];
    const readingContext = activeChart?.status === "ready"
        ? {
              ...readingBundle?.context,
              profileId: selectedProfile?.id ?? readingBundle?.context.profileId,
              chartId: activeChart.id,
              chartVersion: activeChart.chartVersion,
              selectedAnnualYear: selectedAnnual?.year ?? readingBundle?.context.selectedAnnualYear,
          }
        : null;
    const readingRecord = activeChart?.status === "ready"
        ? {
              ...readingBundle?.record,
              profileId: selectedProfile?.id ?? readingBundle?.record.profileId,
          }
        : null;
    const isNatalMode = activeMode === "natal";
    const isTimingMode = activeMode === "timing";
    const isReadingMode = activeMode === "reading";
    const topContextTitle = isNatalMode
        ? "命局焦點"
        : isTimingMode
          ? "起運焦點"
          : "解讀焦點";
    const topContextDescription = selectedProfile
        ? isNatalMode
            ? `${selectedProfile.birthDate} / ${selectedProfile.birthTime} / ${selectedProfile.birthPlace}`
            : isTimingMode
              ? `${selectedProfile.birthDate} / ${selectedProfile.birthTime}，目前用來判定起運點與大運時間軸的前置資料。`
              : `${selectedProfile.name} 已綁定為解讀命主，目前以這筆命盤建立解讀上下文與扣點邊界。`
        : isNatalMode
          ? "先從右側快捷選單或親友資料詳情頁選定一筆命主，八字工作區才會綁定同一筆資料。"
          : isTimingMode
            ? "大運流年模式需要先鎖定命主，才能確認起運折算與時間軸入口。"
            : "深度解讀模式需要先鎖定命主，才能建立解讀上下文與提問前置條件。";
    const workspacePrimaryState = isNatalMode
        ? hasCompleteProfileData
            ? "命局骨架已定位"
            : "命局資料整理中"
        : isTimingMode
          ? hasCompleteProfileData
              ? "歲運節奏可展開"
              : "歲運資料整理中"
          : hasCompleteProfileData
            ? "解讀脈絡可展開"
            : "解讀資料整理中";
    const workspaceFocusState = isNatalMode
        ? "日主 / 四柱 / 五行"
        : isTimingMode
          ? "起運 / 大運 / 流年"
          : "LOT / 提問 / Reading";
    const workspaceSecondaryNote = isNatalMode
        ? "本命盤模式下，主畫面會先聚焦命局骨架、四柱與五行層次。"
        : isTimingMode
          ? "大運流年模式下，主畫面會先聚焦起運點、時間軸與年度切換。"
          : "AI 模式下，主畫面會先聚焦提問脈絡、題卡與解讀紀錄。";
    const hasDayMasterPreview = Boolean(dayMasterSummary);
    const hasTimingPreview = Boolean(luckCycle && annuals);
    const strongestElementLabel = getStrongestElementLabel(elementBalance);
    const timingClassics = getBaziClassicsForTiming();

    return (
        <PageShell
            eyebrow="Bazi Entry"
            title={selectedProfile ? `${selectedProfile.name} 的八字主頁` : "八字工作台"}
            description={
                selectedProfile
                    ? "八字頁目前已圍繞單一命主建立本命盤、大運流年與 深度解讀三個工作模式。"
                    : "先選定一筆命主資料，再進入本命盤、大運流年與 深度解讀的完整工作區。"
            }
            actions={
                <>
                    <Link
                        href="/profiles"
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        回親友資料庫選擇命主
                    </Link>
                    {selectedProfile ? (
                        <Link
                            href={`/profiles/${selectedProfile.id}`}
                            className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950"
                        >
                            回這筆資料詳情
                        </Link>
                    ) : null}
                </>
            }
        >
            <section className="overflow-hidden rounded-[28px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.84)_0%,rgba(10,14,23,0.97)_100%)] p-5 shadow-[0_0_80px_rgba(217,119,6,0.08)] lg:rounded-[30px] lg:p-7">
                <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="max-w-3xl">
                        <p className="text-xs uppercase tracking-[0.32em] text-amber-400/65">規則說明</p>
                        <h2 className="mt-3 text-[1.8rem] leading-tight tracking-[0.04em] text-stone-50 lg:text-[2.05rem] lg:tracking-[0.05em]">第一版採標準時，不含真太陽時修正</h2>
                        <p className="mt-3 text-[0.95rem] leading-7 text-stone-300">
                            目前八字頁的規則基線已固定為 `Asia/Taipei` 標準時間，並採用子初換日、節氣換月、立春換年。真太陽時與經度修正會留到後續版本擴充，不會在這一版默默套用。
                        </p>
                    </div>
                    <div className="min-w-full rounded-[22px] border border-white/10 bg-[rgba(18,24,38,0.72)] px-4 py-4 text-[0.9rem] leading-7 text-stone-300 backdrop-blur-md sm:min-w-[220px] sm:px-5">
                        <p>時區：Asia/Taipei</p>
                        <p>換日：23:00 子初</p>
                        <p>年柱：立春</p>
                        <p>月柱：節氣</p>
                    </div>
                </div>
            </section>

            <section className="rounded-[28px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.9)_0%,rgba(10,14,23,0.98)_100%)] p-5 shadow-[0_0_110px_rgba(124,58,237,0.08)] lg:rounded-[32px] lg:p-8">
                <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
                    <article
                        className={`rounded-[24px] border p-5 transition lg:min-h-[240px] lg:rounded-[26px] lg:p-6 ${
                            isReadingMode
                                ? "border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.14)_0%,rgba(18,24,38,0.72)_100%)] shadow-[0_0_34px_rgba(124,58,237,0.12)] backdrop-blur-md"
                                : isTimingMode
                                  ? "border-amber-400/18 bg-[linear-gradient(180deg,rgba(217,119,6,0.12)_0%,rgba(18,24,38,0.72)_100%)] shadow-[0_0_34px_rgba(217,119,6,0.1)] backdrop-blur-md"
                                  : "border-white/8 bg-[linear-gradient(180deg,rgba(255,255,255,0.035)_0%,rgba(18,24,38,0.7)_100%)] backdrop-blur-md"
                        }`}
                    >
                        <p className="text-xs uppercase tracking-[0.28em] text-amber-300/70">工作區總覽</p>
                        <div className="mt-4 flex flex-wrap items-start justify-between gap-4">
                            <div>
                                <h2 className="text-[1.85rem] leading-tight tracking-[0.04em] text-stone-50 lg:text-[2.1rem] lg:tracking-[0.05em]">
                                    {selectedProfile ? selectedProfile.name : "尚未選定命主"}
                                </h2>
                                <p className="mt-3 max-w-2xl text-[0.95rem] leading-7 text-stone-200">
                                    {topContextDescription}
                                </p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                <span className="rounded-full border border-amber-400/20 bg-amber-500/10 px-4 py-2 text-xs tracking-[0.18em] text-amber-100">
                                    標準時 Asia/Taipei
                                </span>
                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs tracking-[0.18em] text-stone-200">
                                    性別：{selectedProfile?.gender ?? "未選擇"}
                                </span>
                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs tracking-[0.18em] text-stone-200">
                                    規則：子初 / 立春 / 節氣
                                </span>
                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs tracking-[0.18em] text-stone-200">
                                    順逆排：陽男陰女順 / 陰男陽女逆
                                </span>
                            </div>
                        </div>
                        <div className="mt-5 rounded-[18px] border border-white/8 bg-[rgba(18,24,38,0.76)] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.03)] backdrop-blur-md lg:mt-6 lg:rounded-[20px] lg:p-5">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                                <p className="text-xs uppercase tracking-[0.22em] text-stone-400">{topContextTitle}</p>
                                <span
                                    className={`rounded-full border px-3 py-1 text-[11px] tracking-[0.16em] ${
                                        isReadingMode
                                            ? "border-violet-300/18 bg-violet-500/10 text-violet-100"
                                            : "border-amber-400/18 bg-amber-500/10 text-amber-100"
                                    }`}
                                >
                                    {isNatalMode ? "本命盤主視角" : isTimingMode ? "時間軸主視角" : "解讀主視角"}
                                </span>
                            </div>
                            <p className="mt-3 text-[0.88rem] leading-6 text-stone-300">{workspaceSecondaryNote}</p>
                        </div>
                    </article>

                    <article
                        className={`rounded-[24px] border p-5 transition lg:min-h-[240px] lg:rounded-[26px] lg:p-6 ${
                            isReadingMode
                                ? "border-violet-300/16 bg-[rgba(18,24,38,0.8)] shadow-[0_0_28px_rgba(124,58,237,0.08)] backdrop-blur-md"
                                : isTimingMode
                                  ? "border-amber-400/16 bg-[rgba(18,24,38,0.78)] shadow-[0_0_28px_rgba(217,119,6,0.07)] backdrop-blur-md"
                                  : "border-white/8 bg-[rgba(18,24,38,0.76)] backdrop-blur-md"
                        }`}
                    >
                        <p className="text-xs uppercase tracking-[0.28em] text-amber-300/70">目前工作狀態</p>
                        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-1 lg:gap-4">
                            <div className="rounded-[18px] border border-white/8 bg-white/[0.025] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.025)] lg:p-5">
                                <p className="text-xs uppercase tracking-[0.2em] text-stone-400">排盤狀態</p>
                                <p className="mt-3 text-[1.15rem] font-medium text-stone-100">{workspacePrimaryState}</p>
                                <p className="mt-2 text-[0.92rem] leading-7 text-stone-300">
                                    {missingFields.length > 0 ? `缺少：${missingFields.join("、")}` : "前置必要欄位已齊備"}
                                </p>
                                <div className="mt-4 rounded-[16px] border border-white/8 bg-[rgba(12,16,26,0.82)] px-4 py-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.025)] lg:mt-5 lg:px-5">
                                    <p className="text-[11px] uppercase tracking-[0.18em] text-stone-400">正式排盤輸入</p>
                                    <p className="mt-2 text-[0.95rem] font-medium text-stone-100">
                                        {chartInput ? "已就緒" : selectedProfile ? "整理中" : "等待命主"}
                                    </p>
                                    <p className="mt-2 text-[0.78rem] leading-6 text-stone-400">
                                        {chartInput
                                            ? `${selectedProfile?.name ?? chartInput.profileId} / ${chartInput.birthDate} / ${chartInput.birthTimeLabel}`
                                            : selectedProfile
                                              ? "命主資料符合排盤條件後，這裡會整理成本次排盤輸入。"
                                              : "選定命主後，這裡會接續整理排盤所需輸入。"}
                                    </p>
                                </div>
                            </div>
                            <div className="rounded-[18px] border border-white/8 bg-white/[0.025] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.025)] lg:p-5">
                                <p className="text-xs uppercase tracking-[0.2em] text-stone-400">工作區焦點</p>
                                <p className="mt-3 text-[1.15rem] font-medium text-stone-100">{workspaceFocusState}</p>
                                <p className="mt-2 text-[0.92rem] leading-7 text-stone-300">
                                    {isNatalMode
                                        ? "此刻可優先閱讀命局骨架、四柱與五行強弱。"
                                        : isTimingMode
                                          ? "此刻可優先閱讀起運點、大運時間軸與流年切換。"
                                          : "此刻可優先閱讀 LOT 題卡、提問脈絡與解讀記錄。"}
                                </p>
                            </div>
                        </div>
                    </article>
                </div>

                <BaziModeTabs tabs={modeTabs} activeMode={activeMode} selectedProfileId={selectedProfile?.id} />

                <div className="mt-5 grid gap-3 lg:grid-cols-3 lg:gap-4">
                    {modeFocusCards.map((card) => (
                        <article
                            key={card.key}
                            className={`rounded-[22px] border p-5 lg:min-h-[228px] lg:rounded-[24px] lg:p-6 ${
                                card.key === activeMode
                                    ? card.accent === "cyan"
                                        ? "border-violet-300/24 bg-[linear-gradient(180deg,rgba(124,58,237,0.16)_0%,rgba(18,24,38,0.96)_100%)] shadow-[0_0_42px_rgba(124,58,237,0.16)]"
                                        : "border-amber-400/22 bg-[linear-gradient(180deg,rgba(217,119,6,0.14)_0%,rgba(18,24,38,0.96)_100%)] shadow-[0_0_42px_rgba(217,119,6,0.12)]"
                                    : card.accent === "cyan"
                                      ? "border-violet-300/10 bg-[linear-gradient(180deg,rgba(124,58,237,0.05)_0%,rgba(18,24,38,0.88)_100%)] opacity-82"
                                      : "border-amber-400/10 bg-[linear-gradient(180deg,rgba(217,119,6,0.04)_0%,rgba(18,24,38,0.88)_100%)] opacity-82"
                            }`}
                        >
                            <p
                                className={`text-xs uppercase tracking-[0.24em] ${
                                    card.accent === "cyan" ? "text-violet-200/85" : "text-amber-300/75"
                                }`}
                            >
                                {card.eyebrow}
                            </p>
                            <h3
                                className={`mt-3 text-[1.05rem] tracking-[0.04em] lg:text-xl lg:tracking-[0.05em] ${   
                                    card.accent === "cyan" ? "text-violet-50" : "text-stone-50"
                                }`}
                            >
                                {card.title}
                            </h3>
                            <p className="mt-3 text-[0.92rem] leading-7 text-stone-300">{card.description}</p>
                            <div className="mt-5 flex flex-wrap gap-2">
                                {card.checkpoints.map((checkpoint) => (
                                    <span
                                        key={checkpoint}
                                        className={`rounded-full border px-3 py-2 text-xs tracking-[0.16em] ${
                                            card.accent === "cyan"
                                                ? "border-violet-300/16 bg-violet-500/10 text-violet-100"
                                                : "border-white/10 bg-white/[0.03] text-stone-200"
                                        }`}
                                    >
                                        {checkpoint}
                                    </span>
                                ))}
                            </div>
                        </article>
                    ))}
                </div>
            </section>

            <section className="grid gap-6 lg:grid-cols-[0.92fr_1.08fr] lg:gap-7">
                <article
                    className={`rounded-[28px] border p-6 transition lg:min-h-[420px] lg:rounded-[30px] lg:p-9 ${
                        isNatalMode
                            ? "border-amber-400/18 bg-[linear-gradient(180deg,rgba(217,119,6,0.12)_0%,rgba(18,24,38,0.74)_100%)] shadow-[0_0_60px_rgba(217,119,6,0.1)]"
                            : isTimingMode
                              ? "border-white/10 bg-[rgba(18,24,38,0.7)] shadow-[0_0_36px_rgba(255,255,255,0.03)] backdrop-blur-md"
                              : "border-violet-300/14 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.76)_100%)] shadow-[0_0_42px_rgba(124,58,237,0.1)] backdrop-blur-md"
                    }`}
                >
                    <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">命主資料</p>
                    {selectedProfile ? (
                        <>
                            <h2 className="mt-4 text-[1.8rem] leading-tight tracking-[0.04em] text-stone-50 lg:mt-5 lg:text-[2.05rem] lg:tracking-[0.05em]">
                                {selectedProfile.name}
                            </h2>

                            {isNatalMode ? (
                                <>
                                    <dl className="mt-6 space-y-4 text-[0.95rem] leading-7 text-stone-300">
                                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                                            <dt>資料類型</dt>
                                            <dd>{selectedProfile.tag}</dd>
                                        </div>
                                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                                            <dt>性別</dt>
                                            <dd>{selectedProfile.gender}</dd>
                                        </div>
                                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                                            <dt>生日</dt>
                                            <dd>{selectedProfile.birthDate}</dd>
                                        </div>
                                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                                            <dt>時辰</dt>
                                            <dd>{selectedProfile.birthTime}</dd>
                                        </div>
                                        <div className="flex justify-between gap-4 border-b border-white/8 pb-4">
                                            <dt>出生地</dt>
                                            <dd>{selectedProfile.birthPlace}</dd>
                                        </div>
                                    </dl>
                                    <p className="mt-5 text-[0.9rem] leading-7 text-stone-400">{selectedProfile.notes}</p>
                                </>
                            ) : isTimingMode ? (
                                <>
                                    <div className="mt-6 grid gap-4 sm:grid-cols-3">
                                        <div className="rounded-[20px] border border-white/8 bg-[#120d0b] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">命主</p>
                                            <p className="mt-3 text-lg text-stone-100">{selectedProfile.gender}</p>
                                        </div>
                                        <div className="rounded-[20px] border border-white/8 bg-[#120d0b] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">出生時間</p>
                                            <p className="mt-3 text-lg text-stone-100">{selectedProfile.birthDate}</p>
                                            <p className="mt-2 text-sm text-stone-400">{selectedProfile.birthTime}</p>
                                        </div>
                                        <div className="rounded-[20px] border border-white/8 bg-[#120d0b] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">起運基準</p>
                                            <p className="mt-3 text-lg text-stone-100">標準時 / 子初 / 節氣</p>
                                        </div>
                                    </div>
                                    <div className="mt-4 rounded-[20px] border border-amber-300/12 bg-amber-50/[0.04] p-5">
                                        <p className="text-sm text-amber-100">起運前提醒</p>
                                        <p className="mt-3 text-[0.92rem] leading-7 text-stone-300">
                                            目前焦點在大運流年，所以這裡優先呈現起運前置提醒。真正的大運啟動歲數會依標準時、子初換日、節氣與順逆排規則折算。
                                        </p>
                                        <p className="mt-4 text-[0.9rem] leading-7 text-stone-400">
                                            {missingFields.length > 0
                                                ? `目前仍缺：${missingFields.join("、")}，先補齊才能進入正式起運折算。`
                                                : "命主四項必要資料已齊備，可進入後續起運與大運計算。"}
                                        </p>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="mt-6 grid gap-4 sm:grid-cols-3">
                                        <div className="rounded-[20px] border border-cyan-300/10 bg-[#101a20] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">提問命主</p>
                                            <p className="mt-3 text-lg text-stone-100">{selectedProfile.name}</p>
                                        </div>
                                        <div className="rounded-[20px] border border-cyan-300/10 bg-[#101a20] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">上下文狀態</p>
                                            <p className="mt-3 text-lg text-stone-100">
                                                {hasCompleteProfileData ? "可建立解讀上下文" : "前置資料待補齊"}
                                            </p>
                                        </div>
                                        <div className="rounded-[20px] border border-cyan-300/10 bg-[#101a20] p-4">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">扣點邊界</p>
                                            <p className="mt-3 text-lg text-stone-100">成功產生 Reading 才扣點</p>
                                        </div>
                                    </div>
                                    <div className="mt-4 rounded-[20px] border border-cyan-300/12 bg-cyan-50/[0.04] p-5">
                                        <p className="text-sm text-cyan-100">AI 提問前置條件</p>
                                        <p className="mt-3 text-[0.92rem] leading-7 text-stone-300">
                                            AI 模式下，命主資料不只是展示用，而是會直接成為提問上下文。若資料不足，系統只保留入口與題卡，不應產生正式解讀。
                                        </p>
                                        <p className="mt-4 text-[0.9rem] leading-7 text-stone-400">
                                            {missingFields.length > 0
                                                ? `目前仍缺：${missingFields.join("、")}，先補齊後再開放正式提問。`
                                                : "命主資料齊備，之後可直接帶入 AI Reading 工作流。"}
                                        </p>
                                    </div>
                                </>
                            )}
                        </>
                    ) : (
                        <>
                            <h2 className="mt-4 text-[1.8rem] leading-tight tracking-[0.04em] text-stone-50 lg:text-[2.05rem] lg:tracking-[0.05em]">先選一筆命主資料</h2>
                            <p className="mt-4 text-[0.95rem] leading-7 text-stone-300">
                                {isNatalMode
                                    ? "本命盤模式會展開完整命主資料、日主摘要與四柱主表，所以要先鎖定一筆命主。"
                                    : isTimingMode
                                      ? "大運流年模式會依命主資料決定是否可進入起運折算與時間軸視圖，所以也要先選命主。"
                                      : "深度解讀模式會把命主資料變成提問上下文，沒有命主就不能進入正式 Reading 工作流。"}
                            </p>
                            <p className="mt-5 text-[0.9rem] leading-7 text-amber-100/75">
                                你可以從親友資料詳情頁點「從這筆資料進入八字」，或直接點右側命主切換器。
                            </p>
                        </>
                    )}
                </article>

                <article
                    className={`rounded-[28px] border p-6 transition lg:min-h-[420px] lg:rounded-[30px] lg:p-9 ${
                        isReadingMode
                            ? "border-cyan-300/14 bg-[linear-gradient(180deg,rgba(34,211,238,0.07)_0%,rgba(20,13,11,0.96)_100%)] shadow-[0_0_40px_rgba(34,211,238,0.08)]"
                            : "border-amber-300/15 bg-[#140d0b]/95 shadow-[0_0_34px_rgba(217,119,6,0.06)]"
                    }`}
                >
                        <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">
                        {isNatalMode ? "工作節點" : isTimingMode ? "起運規則" : "解讀規則"}
                    </p>
                    <h2 className="mt-4 text-[1.8rem] leading-tight tracking-[0.04em] text-stone-50 lg:mt-5 lg:text-[2.05rem] lg:tracking-[0.05em]">
                        {isNatalMode ? "八字模組施工順序" : isTimingMode ? "起運與大運規則提醒" : "AI 提問前置與扣點邊界"}
                    </h2>
                    <div className="mt-8 grid gap-4">
                        {(isNatalMode ? buildChecklist : isTimingMode ? timingChecklist : readingChecklist).map(
                            (item, index) => (
                                <div
                                    key={item}
                                    className={`rounded-2xl border px-4 py-4 text-sm ${
                                        isReadingMode
                                            ? "border-cyan-300/10 bg-[#101a20] text-stone-200"
                                            : "border-white/8 bg-[#120d0b] text-stone-200"
                                    }`}
                                >
                                    <p
                                        className={`text-xs uppercase tracking-[0.28em] ${
                                            isReadingMode ? "text-cyan-200/45" : "text-amber-200/45"
                                        }`}
                                    >
                                        Step 0{index + 1}
                                    </p>
                                    <p className="mt-2">{item}</p>
                                </div>
                            ),
                        )}
                    </div>
                </article>
            </section>

            <section className="grid items-start gap-6 xl:grid-cols-[1.28fr_0.72fr] xl:gap-8">
                <article
                            className={`rounded-[28px] border bg-[linear-gradient(180deg,rgba(18,24,38,0.88)_0%,rgba(10,14,23,0.98)_100%)] p-6 transition lg:rounded-[32px] lg:p-9 ${    
                        activeMode === "reading"
                            ? "border-white/6 opacity-72"
                            : "border-amber-400/16 shadow-[0_0_104px_rgba(217,119,6,0.1)]"
                    }`}
                >
                            <div className="rounded-[20px] border border-amber-400/14 bg-[linear-gradient(180deg,rgba(217,119,6,0.08)_0%,rgba(255,255,255,0.02)_100%)] px-4 py-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.025)] backdrop-blur-md lg:rounded-[24px] lg:px-5">
                        <p className="text-xs uppercase tracking-[0.28em] text-amber-300/75">客觀排盤區</p>
                        <p className="mt-2 text-[0.92rem] leading-7 text-stone-300">
                            這一區集中呈現客觀排盤資料骨架，包含日主、四柱、大運與流年。視覺上維持暗金、羊皮紙與深棕黑材質，避免和深度解讀區混在一起。
                        </p>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3">
                        <p className="mt-6 text-xs uppercase tracking-[0.38em] text-amber-200/70">日主摘要</p>
                                <span className="rounded-full border border-amber-400/16 bg-amber-500/8 px-4 py-2 text-xs tracking-[0.2em] text-amber-100/90">
                            本命盤模式焦點區
                        </span>
                    </div>
                        <div className="mt-6 grid gap-4 lg:mt-7 lg:gap-5">
                            <div
                                className={`rounded-[22px] border bg-[linear-gradient(180deg,rgba(217,119,6,0.06)_0%,rgba(255,255,255,0.02)_100%)] p-5 transition lg:rounded-[26px] lg:p-7 ${
                                    isNatalMode
                                        ? "border-amber-400/18 shadow-[0_0_48px_rgba(217,119,6,0.1)]"
                                        : "border-white/8 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] backdrop-blur-sm"
                                }`}
                            >
                            <div className="flex flex-wrap items-center justify-between gap-3">
                                <div>
                                    <p className="text-xs uppercase tracking-[0.28em] text-amber-200/60">
                                        日主摘要
                                    </p>
                                    <h2 className="mt-3 text-[1.8rem] leading-tight tracking-[0.04em] text-stone-50 lg:text-[2.05rem] lg:tracking-[0.05em]">
                                        {selectedProfile ? `${selectedProfile.name} 的日主摘要卡` : "先選命主再進入八字"}
                                    </h2>
                                </div>
                                <span
                                    className={`rounded-full border px-4 py-2 text-xs tracking-[0.22em] ${getSectionStateClasses(
                                        Boolean(selectedProfile),
                                        hasCompleteProfileData,
                                        "gold",
                                    )}`}
                                >
                                    {getSectionStateLabel(Boolean(selectedProfile), hasCompleteProfileData)}
                                </span>
                            </div>

                            {selectedProfile ? (
                                <>
                                    {isNatalMode ? (
                                        <>
                                            <div className="mt-6 grid gap-4 md:grid-cols-[0.72fr_1.28fr] lg:mt-7 lg:gap-5">
                                                <div
                                                    className={`rounded-[18px] border p-4 lg:rounded-[20px] lg:p-5 ${
                                                        hasDayMasterPreview
                                                            ? "border-amber-400/16 bg-[linear-gradient(180deg,rgba(217,119,6,0.1)_0%,rgba(18,24,38,0.74)_100%)] shadow-[0_0_24px_rgba(217,119,6,0.08)]"
                                                            : "border-white/8 bg-[rgba(18,24,38,0.7)]"
                                                    }`}
                                                >
                                                    <p className="text-xs uppercase tracking-[0.28em] text-stone-400">
                                                        日主天干
                                                    </p>
                                                    <p className="mt-4 text-[3.2rem] leading-none font-medium tracking-[0.12em] text-amber-100 lg:text-[4.25rem] lg:tracking-[0.16em]">
                                                        {dayMasterSummary?.stem ?? "--"}
                                                    </p>
                                                    <p className="mt-4 text-[0.78rem] leading-6 text-stone-500">
                                                        {dayMasterSummary
                                                            ? `${dayMasterSummary.title}，可在此直接對照日主、陰陽與五行屬性。`
                                                            : "日主、陰陽與五行屬性會在命盤結果整理完成後顯示於此。"}
                                                    </p>
                                                </div>

                                                <div className="grid gap-4">
                                                    <div className="grid gap-3 sm:grid-cols-3 lg:gap-4">
                                                        <div
                                                            className={`rounded-[16px] border p-4 lg:rounded-[20px] ${
                                                                hasDayMasterPreview
                                                                    ? "border-amber-300/14 bg-amber-50/[0.05]"
                                                                    : "border-white/8 bg-[#120d0b]"
                                                            }`}
                                                        >
                                                            <p className="text-xs uppercase tracking-[0.22em] text-stone-400">
                                                                命局強弱
                                                            </p>
                                                            <p className="mt-3 text-[1.35rem] font-medium text-stone-100">
                                                                {dayMasterSummary?.strengthLabel ?? (hasCompleteProfileData ? "整理中" : "命主資料未齊")}
                                                            </p>
                                                        </div>
                                                        <div
                                                            className={`rounded-[16px] border p-4 lg:rounded-[20px] ${
                                                                hasDayMasterPreview
                                                                    ? "border-amber-300/14 bg-amber-50/[0.05]"
                                                                    : "border-white/8 bg-[#120d0b]"
                                                            }`}
                                                        >
                                                            <p className="text-xs uppercase tracking-[0.22em] text-stone-400">
                                                                格局 / 喜用
                                                            </p>
                                                            <p className="mt-3 text-[1.28rem] font-medium text-stone-100">
                                                                {dayMasterSummary
                                                                    ? `${dayMasterSummary.pattern} / ${dayMasterSummary.usefulGods.join("、")}`
                                                                    : "格局整理中"}
                                                            </p>
                                                        </div>
                                                        <div className="rounded-[16px] border border-white/8 bg-[#120d0b] p-4 lg:rounded-[20px]">
                                                            <p className="text-xs uppercase tracking-[0.22em] text-stone-400">
                                                                資料完整度
                                                            </p>
                                                            <p className="mt-3 text-[1.2rem] font-medium text-stone-100">
                                                                {readyFieldCount} / {requiredFieldCount}
                                                            </p>
                                                        </div>
                                                    </div>

                                                        <div className="rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:rounded-[20px] lg:p-6">
                                                        <div className="flex items-center justify-between gap-3 text-sm text-stone-300">
                                                            <span>排盤前置檢查</span>
                                                            <span>{hasCompleteProfileData ? "可進入正式排盤" : "尚未可排盤"}</span>
                                                        </div>
                                                        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/8">
                                                            <div
                                                                className="h-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300"
                                                                style={{ width: `${(readyFieldCount / requiredFieldCount) * 100}%` }}
                                                            />
                                                        </div>
                                                        {missingFields.length > 0 ? (
                                                            <p className="mt-4 text-[0.92rem] leading-7 text-amber-100/80">
                                                                目前缺少：{missingFields.join("、")}。正式排盤現在要求性別、生日、時辰、出生地四項都齊備，補齊後才能接正式的日主、強弱與五行結果。
                                                            </p>
                                                        ) : (
                                                            <p className="mt-4 text-[0.95rem] leading-7 text-stone-200">
                                                                {dayMasterSummary
                                                                    ? dayMasterSummary.summary
                                                                    : "命主資料已齊備，命盤結果整理完成後會在此顯示。"}
                                                            </p>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-6 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:mt-7 lg:rounded-[20px] lg:p-6">
                                                <div className="flex items-center justify-between gap-3">
                                                    <p className="text-[1rem] font-medium text-amber-100">五行強弱條</p>
                                                    <p className="text-xs tracking-[0.18em] text-stone-500">
                                                        {elementBalance ? "五行分佈已載入" : "五行結果整理中"}
                                                    </p>
                                                </div>
                                                <div className="mt-4 grid gap-3 lg:mt-5">
                                                    {elementLabels.map((element) => (
                                                        <div key={element.key} className="grid grid-cols-[48px_1fr_64px] items-center gap-3">
                                                            <span className={`text-sm ${elementBalance ? "font-medium text-stone-200" : "text-stone-300"}`}>
                                                                {element.label}
                                                            </span>
                                                            <div className="h-2 overflow-hidden rounded-full bg-white/8">
                                                                <div
                                                                    className={`h-full rounded-full ${
                                                                        elementBalance
                                                                            ? "bg-gradient-to-r from-amber-200 to-orange-300"
                                                                            : "w-[14%] bg-white/12"
                                                                    }`}
                                                                    style={elementBalance ? { width: `${elementBalance[element.key].percentage}%` } : undefined}
                                                                />
                                                            </div>
                                                            <span
                                                                className={`text-right text-xs tracking-[0.18em] ${
                                                                    elementBalance ? "text-amber-100/85" : "text-stone-500"
                                                                }`}
                                                            >
                                                                {elementBalance ? elementBalance[element.key].label : "整理中"}
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </>
                                    ) : (
                                        <div className="mt-6 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:mt-7 lg:rounded-[20px] lg:p-6">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <p className="text-sm text-amber-100">本命盤速覽</p>
                                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] tracking-[0.16em] text-stone-300">
                                                    目前以摘要模式顯示
                                                </span>
                                            </div>
                                            <p className="mt-3 text-[0.92rem] leading-7 text-stone-300">
                                                目前工作焦點已切到其他模式，這裡保留本命盤的核心判讀值，方便快速回看命局狀態。
                                            </p>
                                            <div className="mt-4 grid gap-3 sm:grid-cols-3">
                                                <div className="rounded-[16px] border border-amber-300/12 bg-amber-50/[0.04] p-4 lg:rounded-[18px]">
                                                    <p className="text-xs uppercase tracking-[0.2em] text-stone-500">日主狀態</p>
                                                    <p className="mt-3 text-[1.15rem] font-medium text-stone-100">
                                                        {dayMasterSummary?.title ?? "日主結果整理中"}
                                                    </p>
                                                    <p className="mt-2 text-[0.78rem] leading-6 text-stone-500">
                                                        {dayMasterSummary ? `${dayMasterSummary.pattern} / ${dayMasterSummary.strengthLabel}` : "命盤結果整理完成後顯示"}
                                                    </p>
                                                </div>
                                                <div className="rounded-[16px] border border-white/8 bg-white/[0.03] p-4 lg:rounded-[18px]">
                                                    <p className="text-xs uppercase tracking-[0.2em] text-stone-500">五行焦點</p>
                                                    <p className="mt-3 text-[1.15rem] font-medium text-stone-100">
                                                        {strongestElementLabel ?? (hasCompleteProfileData ? "整理中" : "命主資料未齊")}
                                                    </p>
                                                    <p className="mt-2 text-[0.78rem] leading-6 text-stone-500">
                                                        {elementBalance ? "目前最強元素與分佈已定位" : "五行分佈整理完成後顯示"}
                                                    </p>
                                                </div>
                                                <div className="rounded-[18px] border border-white/8 bg-white/[0.03] p-4">
                                                    <p className="text-xs uppercase tracking-[0.2em] text-stone-500">前置資料</p>
                                                    <p className="mt-3 text-[1.15rem] font-medium text-stone-100">
                                                        {readyFieldCount} / {requiredFieldCount}
                                                    </p>
                                                    <p className="mt-2 text-[0.78rem] leading-6 text-stone-500">
                                                        {missingFields.length > 0 ? `待補：${missingFields.join("、")}` : "四項必要欄位已齊備"}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="mt-4 flex flex-wrap gap-2">
                                                <span className="rounded-full border border-amber-300/14 bg-amber-50/[0.04] px-3 py-2 text-xs tracking-[0.16em] text-amber-50/80">
                                                    切回本命盤可查看完整四柱
                                                </span>
                                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-300">
                                                    目前模式：{isTimingMode ? "大運流年" : "深度解讀"}
                                                </span>
                                            </div>
                                        </div>
                                    )}
                                </>
                            ) : (
                                <p className="mt-6 text-[0.92rem] leading-7 text-stone-300">
                                    先從右側快捷選單選一筆親友資料，日主摘要卡才會知道要為誰準備八字內容。
                                </p>
                            )}
                        </div>

                        <div
                            className={`grid gap-4 ${
                                isNatalMode
                                    ? "xl:grid-cols-[1.2fr_0.8fr]"
                                    : isTimingMode
                                      ? "xl:grid-cols-[0.8fr_1.2fr]"
                                      : "md:grid-cols-2"
                            }`}
                        >
                            <div
                                className={`rounded-[22px] border bg-white/[0.03] p-4 transition lg:rounded-[26px] lg:p-5 ${
                                    isNatalMode
                                        ? "border-amber-300/18 shadow-[0_0_40px_rgba(251,191,36,0.05)]"
                                        : "border-white/8 opacity-80 backdrop-blur-sm"
                                }`}
                            >
                                <div className="flex flex-wrap items-center justify-between gap-3">
                                    <div>
                                        <p className="text-sm text-amber-100">四柱主表</p>
                                        <p className="mt-2 text-[0.9rem] leading-7 text-stone-500">
                                            此區集中呈現年柱、月柱、日柱、時柱與藏干層級，方便在同一張主表快速閱讀命局骨架。
                                        </p>
                                    </div>
                                    <span
                                        className={`rounded-full border px-3 py-1 text-xs tracking-[0.18em] ${getSectionStateClasses(
                                            Boolean(selectedProfile),
                                            hasCompleteProfileData,
                                            "gold",
                                        )}`}
                                    >
                                        {getSectionStateLabel(Boolean(selectedProfile), hasCompleteProfileData)}
                                    </span>
                                </div>

                                {isNatalMode ? (
                                    <>
                                        <div className="mt-4 overflow-x-auto lg:mt-5">
                                            <div className="min-w-[680px] rounded-[18px] border border-white/8 bg-[#120d0b] p-3 lg:min-w-[700px] lg:rounded-[20px]">
                                                <div className="grid grid-cols-[112px_repeat(4,minmax(0,1fr))] gap-3">
                                                    <div className="rounded-2xl border border-transparent px-3 py-4 text-xs uppercase tracking-[0.24em] text-stone-500">
                                                        命盤結構
                                                    </div>
                                                    {pillarColumns.map((column) => (
                                                        <div
                                                            key={column.key}
                                                            className={`rounded-2xl border px-3 py-4 text-center ${
                                                                column.highlight
                                                                    ? "border-amber-300/25 bg-amber-50/[0.05]"
                                                                    : "border-white/8 bg-white/[0.02]"
                                                            }`}
                                                        >
                                                            <p className="text-xs uppercase tracking-[0.22em] text-stone-500">
                                                                {column.highlight ? "核心柱位" : "柱位"}
                                                            </p>
                                                            <p
                                                                className={`mt-2 text-lg tracking-[0.08em] ${
                                                                    column.highlight ? "text-amber-50" : "text-stone-100"
                                                                }`}
                                                            >
                                                                {column.label}
                                                            </p>
                                                            <p
                                                                className={`mt-2 tracking-[0.18em] ${
                                                                    getPillarHeaderValue(activeChart, column.key)
                                                                        ? "text-base font-medium text-stone-100"
                                                                        : "text-sm text-stone-500"
                                                                }`}
                                                            >
                                                                {getPillarHeaderValue(activeChart, column.key) ?? "--"}
                                                            </p>
                                                        </div>
                                                    ))}

                                                    {pillarRows.map((row) => (
                                                        <div key={row.key} className="contents">
                                                            <div className="flex items-center rounded-2xl border border-white/8 bg-white/[0.02] px-3 py-4 text-sm text-stone-300">
                                                                {row.label}
                                                            </div>
                                                            {pillarColumns.map((column) => (
                                                                <div
                                                                    key={`${row.key}-${column.key}`}
                                                                    className={`rounded-2xl border px-3 py-4 text-center text-sm ${
                                                                        column.highlight
                                                                            ? "border-amber-300/18 bg-amber-50/[0.04] text-amber-50"
                                                                            : getPillarCellValue(activeChart, column.key, row.key, hasCompleteProfileData) !== "待計算" &&
                                                                                getPillarCellValue(activeChart, column.key, row.key, hasCompleteProfileData) !== "資料不足"
                                                                              ? "border-white/10 bg-[#17110f] text-stone-100"
                                                                              : "border-white/8 bg-[#17110f] text-stone-400"
                                                                    }`}
                                                                >
                                                                    {getPillarCellValue(activeChart, column.key, row.key, hasCompleteProfileData)}
                                                                </div>
                                                            ))}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>

                                        <p className="mt-4 text-xs leading-6 text-stone-500">
                                            {activeChart?.status === "ready"
                                                ? "四柱主表已依命局結構排布，可直接對照柱位、十神、藏干與十二長生。"
                                                : "命主資料補齊後，這張表會展開完整四柱內容與對應欄位。"}
                                        </p>
                                    </>
                                ) : (
                                    <div className="mt-5 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:rounded-[20px] lg:p-5">
                                        <div className="flex flex-wrap items-center justify-between gap-3">
                                                    <p className="text-[1rem] font-medium text-stone-200">四柱速覽</p>
                                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] tracking-[0.16em] text-stone-300">
                                                摘要模式
                                            </span>
                                        </div>
                                        <div className="mt-4 grid gap-3 sm:grid-cols-4">
                                            {pillarColumns.map((column) => (
                                                <div
                                                    key={column.key}
                                                    className={`rounded-[16px] border px-4 py-4 text-center lg:rounded-[18px] ${
                                                        column.highlight
                                                            ? "border-amber-300/20 bg-amber-50/[0.05]"
                                                            : "border-white/8 bg-white/[0.03]"
                                                    }`}
                                                >
                                                    <p className="text-xs uppercase tracking-[0.2em] text-stone-500">{column.label}</p>
                                                    <p className="mt-3 text-sm text-stone-300">
                                                        {getPillarHeaderValue(activeChart, column.key) ?? (hasCompleteProfileData ? "干支整理中" : "命主資料未齊")}
                                                    </p>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="mt-4 flex flex-wrap gap-2">
                                            <span className="rounded-full border border-amber-300/14 bg-amber-50/[0.04] px-3 py-2 text-xs tracking-[0.16em] text-amber-50/80">
                                                切回本命盤可展開高密度四柱表
                                            </span>
                                            {dayMasterSummary ? (
                                                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-300">
                                                    日主：{dayMasterSummary.stem} / {dayMasterSummary.strengthLabel}
                                                </span>
                                            ) : null}
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div
                                className={`rounded-[26px] border bg-white/[0.03] p-5 transition ${
                                    isTimingMode
                                        ? "border-amber-300/18 shadow-[0_0_40px_rgba(251,191,36,0.05)]"
                                        : "border-white/8 opacity-80 backdrop-blur-sm"
                                }`}
                            >
                                <div className="flex flex-wrap items-center justify-between gap-3">
                                    <div>
                                        <p className="text-sm text-amber-100">大運 / 流年</p>
                                        <p className="mt-2 text-[0.9rem] leading-7 text-stone-500">
                                            此區整合起運點、大運時間軸與流年切換，讓命主的歲運節奏可在同一工作區連續閱讀。
                                        </p>
                                    </div>
                                    <span
                                        className={`rounded-full border px-3 py-1 text-xs tracking-[0.18em] ${getSectionStateClasses(
                                            Boolean(selectedProfile),
                                            hasCompleteProfileData,
                                            "gold",
                                        )}`}
                                    >
                                        {getSectionStateLabel(Boolean(selectedProfile), hasCompleteProfileData)}
                                    </span>
                                </div>

                                <div className="mt-4">
                                    <span className="rounded-full border border-amber-300/14 bg-amber-50/[0.04] px-4 py-2 text-xs tracking-[0.2em] text-amber-50/80">
                                        大運流年模式焦點區
                                    </span>
                                </div>

                                {isTimingMode ? (
                                    <>
                                        <div className="mt-5 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:mt-6 lg:rounded-[20px] lg:p-6">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <div>
                                                    <p className="text-xs uppercase tracking-[0.24em] text-amber-200/45">
                                                        大運時間軸
                                                    </p>
                                                    <h3 className="mt-2 text-[1.05rem] tracking-[0.04em] text-stone-50 lg:text-xl lg:tracking-[0.06em]">大運時間軸</h3>
                                                </div>
                                                <p className={`text-xs tracking-[0.18em] ${hasTimingPreview ? "text-amber-100/80" : "text-stone-500"}`}>
                                                    {luckCycle
                                                        ? `${luckCycle.direction === "forward" ? "順排" : "逆排"} / ${luckCycle.startAge} 歲起運 / ${luckCycle.startOffsetLabel}`
                                                        : hasCompleteProfileData
                                                          ? "起運資訊整理中"
                                                          : "命主資料未齊，暫不展開大運"}
                                                </p>
                                            </div>

                                            <div className="mt-4 overflow-x-auto lg:mt-5">
                                                <div className="flex min-w-[680px] items-stretch gap-3 lg:min-w-[760px]">
                                                    <div className="flex w-24 shrink-0 flex-col justify-between rounded-[18px] border border-amber-300/18 bg-amber-50/[0.04] p-4 lg:w-28 lg:rounded-[20px]">
                                                        <div>
                                                            <p className="text-xs uppercase tracking-[0.22em] text-amber-200/45">起點</p>
                                                            <p className="mt-3 text-lg text-amber-50">起運點</p>
                                                        </div>
                                                        <p className="mt-6 text-xs leading-6 text-stone-400">
                                                            {luckCycle
                                                                ? `${luckCycle.startAge} 歲 / ${luckCycle.startYear}`
                                                                : hasCompleteProfileData
                                                                  ? "起運整理中"
                                                                  : "命主資料未齊"}
                                                        </p>
                                                        <p className="mt-3 text-sm leading-7 text-stone-300">
                                                            {luckCycle?.startDateTimeLabel ?? "起運時間待計算"}
                                                        </p>
                                                        <p className="mt-3 text-[11px] leading-5 text-stone-500">
                                                            {luckCycle
                                                                ? `${luckCycle.startOffsetLabel} / ${luckCycle.calculationBasis}`
                                                                : "三日一歲折算規則待顯示"}
                                                        </p>
                                                    </div>

                                                    {luckCycle
                                                        ? luckCycle.pillars.map((pillar) => (
                                                              <div
                                                                  key={pillar.id}
                                                              className={`flex min-h-36 min-w-32 flex-1 flex-col justify-between rounded-[18px] border p-4 lg:min-h-40 lg:min-w-40 lg:rounded-[20px] ${
                                                                      pillar.isCurrent
                                                                          ? "border-amber-300/22 bg-amber-50/[0.05] shadow-[0_0_24px_rgba(251,191,36,0.06)]"
                                                                          : "border-white/8 bg-[#17110f]"
                                                                  }`}
                                                              >
                                                                  <div>
                                                                      <div className="flex items-center justify-between gap-3">
                                                                          <p className="text-xs uppercase tracking-[0.22em] text-stone-500">
                                                                              大運 0{pillar.order}
                                                                          </p>
                                                                          <span className="text-[11px] tracking-[0.16em] text-stone-500">
                                                                              {pillar.isCurrent ? "目前所在" : "時段定位"}
                                                                          </span>
                                                                      </div>
                                                                      <p className="mt-3 text-3xl font-medium tracking-[0.08em] text-stone-100">
                                                                          {pillar.stem}
                                                                          {pillar.branch}
                                                                      </p>
                                                                      <p className="mt-2 text-xs tracking-[0.16em] text-stone-500">
                                                                          {pillar.stemTenGod} / {pillar.branchTenGod}
                                                                      </p>
                                                                  </div>
                                                                  <div className="mt-4 space-y-2 text-sm leading-6 text-stone-400">
                                                                      <p>
                                                                          起止歲數：{pillar.startAge} - {pillar.endAge}
                                                                      </p>
                                                                      <p>
                                                                          對應年份：{pillar.startYear} - {pillar.endYear}
                                                                      </p>
                                                                      <p>十二長生：{pillar.growthStage}</p>
                                                                      <p>Reading：{getReadingStatusLabel(pillar.readingStatus)}</p>
                                                                  </div>
                                                              </div>
                                                          ))
                                                        : luckPillarSlots.map((pillar) => (
                                                              <div
                                                                  key={pillar.order}
                                                                  className="flex min-h-36 min-w-32 flex-1 flex-col justify-between rounded-[18px] border border-white/8 bg-[#17110f] p-4 lg:min-h-40 lg:min-w-36 lg:rounded-[20px]"
                                                              >
                                                                  <div>
                                                                      <p className="text-xs uppercase tracking-[0.22em] text-stone-500">
                                                                          大運 0{pillar.order}
                                                                      </p>
                                                                      <p className="mt-3 text-lg tracking-[0.06em] text-stone-100">
                                                                          {pillar.label}
                                                                      </p>
                                                                  </div>
                                                                  <div className="mt-4 space-y-2 text-sm leading-6 text-stone-400">
                                                                      <p>{hasCompleteProfileData ? "起止歲數：起運後顯示" : "起止歲數：命主資料未齊"}</p>
                                                                      <p>{hasCompleteProfileData ? "大運干支：起運後顯示" : "大運干支：命主資料未齊"}</p>
                                                                      <p>解讀席位：後續開放</p>
                                                                  </div>
                                                              </div>
                                                          ))}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="mt-5 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 shadow-[0_0_28px_rgba(0,0,0,0.18)] lg:rounded-[20px] lg:p-6">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <div>
                                                    <p className="text-xs uppercase tracking-[0.24em] text-amber-200/60">
                                                        流年面板
                                                    </p>
                                                    <h3 className="mt-2 text-[1.05rem] tracking-[0.04em] text-stone-50 lg:text-xl lg:tracking-[0.06em]">流年切換</h3>
                                                </div>
                                                <p className="text-xs tracking-[0.18em] text-stone-400">
                                                    {annuals ? `${annuals.length} 個年度節點已載入` : "年度節點將於起運後展開"}
                                                </p>
                                            </div>

                                            <div className="mt-4 flex flex-wrap gap-2 lg:mt-5">
                                                {annuals
                                                    ? annuals.map((annual) => (
                                                          <Link
                                                              key={annual.year}
                                                              href={buildBaziHref(selectedProfile?.id, activeMode, annual.year)}
                                                              className={`rounded-full border px-3 py-2 text-[0.82rem] transition lg:px-4 lg:text-sm ${
                                                                  annual.isSelected
                                                                      ? "border-amber-300/28 bg-amber-50/[0.08] text-amber-50 shadow-[0_0_18px_rgba(251,191,36,0.08)]"
                                                                      : annual.isCurrent
                                                                        ? "border-white/16 bg-white/[0.05] text-stone-100 hover:border-amber-300/24 hover:bg-amber-50/[0.04] hover:text-amber-50"
                                                                        : "border-white/10 bg-white/[0.02] text-stone-400 hover:border-amber-300/22 hover:bg-amber-50/[0.035] hover:text-amber-100"
                                                              }`}
                                                          >
                                                              {annual.year} {annual.stem}{annual.branch}
                                                          </Link>
                                                      ))
                                                    : luckPillarSlots.slice(0, 6).map((pillar) => (
                                                          <button
                                                              key={pillar.order}
                                                              type="button"
                                                              disabled
                                                              className="rounded-full border border-white/10 bg-white/[0.02] px-4 py-2 text-sm text-stone-400"
                                                          >
                                                              {hasCompleteProfileData ? `20${26 + pillar.order - 1}` : `20${26 + pillar.order - 1} 待選`}
                                                          </button>
                                                      ))}
                                            </div>

                                            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:mt-5">
                                                <div className="rounded-[16px] border border-white/8 bg-[#17110f] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] lg:rounded-[18px]">
                                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-400">目前流年</p>
                                                    <p className={`mt-3 text-lg ${selectedAnnual ? "font-medium text-stone-100" : "text-stone-100"}`}>
                                                        {selectedAnnual
                                                            ? `${selectedAnnual.year} / ${selectedAnnual.stem}${selectedAnnual.branch}`
                                                            : hasCompleteProfileData
                                                              ? "請選流年"
                                                              : "命主資料未齊"}
                                                    </p>
                                                    <p className="mt-2 text-sm leading-7 text-stone-300">
                                                        {selectedAnnual
                                                            ? `歲數 ${selectedAnnual.age}，十神 ${selectedAnnual.stemTenGod} / ${selectedAnnual.branchTenGod}`
                                                            : "請先選定欲查看的年度。"}
                                                    </p>
                                                </div>
                                                <div className="rounded-[16px] border border-white/8 bg-[#17110f] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] lg:rounded-[18px]">
                                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-400">年度解讀</p>
                                                    <p className={`mt-3 text-lg ${selectedAnnual ? "font-medium text-stone-100" : "text-stone-100"}`}>
                                                        {selectedAnnual
                                                            ? selectedAnnual.themes
                                                                  .map((theme) => `${theme.label} ${getReadingStatusLabel(theme.readingStatus)}`)
                                                                  .join(" / ")
                                                            : "年度解讀將顯示於此"}
                                                    </p>
                                                </div>
                                            </div>

                                            {selectedAnnual ? (
                                                <div className="mt-4 rounded-[16px] border border-white/8 bg-[#17110f] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] lg:rounded-[18px]">
                                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-400">本年互動重點</p>
                                                    <div className="mt-3 grid gap-2">
                                                        {selectedAnnual.relations.map((relation) => (
                                                            <p key={`${relation.target}-${relation.relationType}`} className="text-sm leading-7 text-stone-300">
                                                                {relation.target} {relation.relationType}：{relation.description}
                                                            </p>
                                                        ))}
                                                    </div>
                                                </div>
                                            ) : null}

                                            <details className="mt-4 rounded-[16px] border border-white/8 bg-[#17110f] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.02)] lg:rounded-[18px]">
                                                <summary className="cursor-pointer list-none">
                                                    <div className="flex flex-wrap items-center justify-between gap-3">
                                                        <div>
                                                            <p className="text-xs uppercase tracking-[0.22em] text-stone-400">古籍解說</p>
                                                            <p className="mt-2 text-sm leading-7 text-stone-300">
                                                                以歲運判讀的古籍語氣補上讀盤脈絡，協助把時間軸轉成可理解的吉凶機理。
                                                            </p>
                                                        </div>
                                                        <div className="text-right">
                                                            <p className="text-xs tracking-[0.18em] text-stone-500">滴天髓 / 窮通寶鑑 / 三命通會</p>
                                                            <p className="mt-2 text-xs tracking-[0.18em] text-amber-200/70">點擊展開</p>
                                                        </div>
                                                    </div>
                                                </summary>
                                                <div className="mt-4 space-y-3">
                                                    {timingClassics.map((item) => (
                                                        <div
                                                            key={item.id}
                                                            className="rounded-[14px] border border-white/8 bg-white/[0.02] p-4 shadow-[0_0_18px_rgba(0,0,0,0.14)]"
                                                        >
                                                            <p className="text-xs uppercase tracking-[0.22em] text-amber-200/70">{item.book}</p>
                                                            <p className="mt-2 text-sm font-medium tracking-[0.04em] text-stone-100">
                                                                {item.title}
                                                            </p>
                                                            <p className="mt-3 text-sm leading-7 text-amber-100/90">{item.excerpt}</p>
                                                            <p className="mt-2 text-sm leading-7 text-stone-300">{item.paraphrase}</p>
                                                            <a
                                                                href={item.sourceUrl}
                                                                target="_blank"
                                                                rel="noreferrer"
                                                                className="mt-3 inline-flex text-xs tracking-[0.18em] text-stone-400 underline decoration-white/10 underline-offset-4 hover:text-amber-100"
                                                            >
                                                                查看原文出處
                                                            </a>
                                                        </div>
                                                    ))}
                                                </div>
                                            </details>
                                        </div>

                                        <p className="mt-4 text-xs leading-6 text-stone-400">
                                            {luckCycle && annuals
                                                ? "大運與流年已依時間脈絡排布，方便在同一工作區追蹤歲運節奏。"
                                                : "命主資料補齊後，這一區會展開完整時間軸與年度切換。"}
                                        </p>
                                    </>
                                ) : (
                                    <div className="mt-5 rounded-[18px] border border-white/8 bg-[#120d0b] p-4 lg:rounded-[20px] lg:p-5">
                                        <div className="flex flex-wrap items-center justify-between gap-3">
                                            <p className="text-sm text-stone-300">大運 / 流年速覽</p>
                                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] tracking-[0.16em] text-stone-300">
                                                摘要模式
                                            </span>
                                        </div>
                                        <div className="mt-4 grid gap-3 sm:grid-cols-3">
                                            <div className="rounded-[16px] border border-amber-300/12 bg-amber-50/[0.04] p-4 lg:rounded-[18px]">
                                                <p className="text-xs uppercase tracking-[0.2em] text-stone-500">起運點</p>
                                                <p className="mt-3 text-lg font-medium text-stone-100">
                                                    {luckCycle
                                                        ? `${luckCycle.startAge} 歲 / ${luckCycle.startYear}`
                                                        : hasCompleteProfileData
                                                          ? "起運整理中"
                                                          : "命主資料未齊"}
                                                </p>
                                                <p className="mt-2 text-xs leading-6 text-stone-500">
                                                    {luckCycle
                                                        ? `${luckCycle.direction === "forward" ? "順排" : "逆排"} / ${luckCycle.startDateTimeLabel}`
                                                        : "起運資料建立後顯示"}
                                                </p>
                                            </div>
                                            <div className="rounded-[16px] border border-white/8 bg-white/[0.03] p-4 lg:rounded-[18px]">
                                                <p className="text-xs uppercase tracking-[0.2em] text-stone-500">目前大運</p>
                                                <p className="mt-3 text-lg font-medium text-stone-100">
                                                    {currentLuckPillar ? `${currentLuckPillar.stem}${currentLuckPillar.branch}` : "運程整理中"}
                                                </p>
                                                <p className="mt-2 text-xs leading-6 text-stone-500">
                                                    {currentLuckPillar
                                                        ? `${currentLuckPillar.startAge} - ${currentLuckPillar.endAge} 歲`
                                                        : `${luckCycle?.pillars.length ?? luckPillarSlots.length} 柱時間軸已定位`}
                                                </p>
                                            </div>
                                            <div className="rounded-[16px] border border-white/8 bg-white/[0.03] p-4 lg:rounded-[18px]">
                                                <p className="text-xs uppercase tracking-[0.2em] text-stone-500">目前流年</p>
                                                <p className="mt-3 text-lg font-medium text-stone-100">
                                                    {selectedAnnual ? `${selectedAnnual.year} / ${selectedAnnual.stem}${selectedAnnual.branch}` : "年度資料整理中"}
                                                </p>
                                                <p className="mt-2 text-xs leading-6 text-stone-500">
                                                    {selectedAnnual ? `歲數 ${selectedAnnual.age} / ${selectedAnnual.stemTenGod}` : "切回大運流年模式可查看年度細節"}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="mt-4 flex flex-wrap gap-2">
                                            <span className="rounded-full border border-amber-300/14 bg-amber-50/[0.04] px-3 py-2 text-xs tracking-[0.16em] text-amber-50/80">
                                                切回大運流年模式可展開完整時間軸與年度細節
                                            </span>
                                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-300">
                                                年度節點：{annuals?.length ?? 0} 組
                                            </span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div
                            className={`rounded-[28px] border bg-[linear-gradient(180deg,rgba(34,211,238,0.08)_0%,rgba(8,14,19,0.985)_100%)] p-5 transition lg:rounded-[30px] lg:p-6 ${  
                                isReadingMode
                                    ? "border-violet-300/22 shadow-[0_0_110px_rgba(124,58,237,0.18)]"
                                    : "border-violet-300/12 opacity-84"
                            }`}
                        >
                            <div className="rounded-[22px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.14)_0%,rgba(18,24,38,0.62)_100%)] px-5 py-4 backdrop-blur-md">
                                <p className="text-xs uppercase tracking-[0.28em] text-violet-200/85">主觀解讀區</p>
                                <p className="mt-2 text-[0.92rem] leading-7 text-stone-300">
                                    這一區專門保留 AI 靈樞解讀、LOT 題卡、提問輸入與 Reading 歷史。視覺上用玄青冷色分區，刻意與命盤數據區做層次切割。
                                </p>
                            </div>

                            <div className="flex flex-wrap items-center justify-between gap-3">
                                <div>
                                    <p className="mt-6 text-xs uppercase tracking-[0.28em] text-cyan-200/55">Reading 入口</p>
                                    <h2 className="mt-3 text-[1.8rem] leading-tight tracking-[0.04em] text-cyan-50 lg:text-[2.05rem] lg:tracking-[0.05em]">深度解讀入口</h2>
                                </div>
                                <span
                                    className={`rounded-full border px-4 py-2 text-xs tracking-[0.22em] ${getSectionStateClasses(
                                        Boolean(selectedProfile),
                                        hasCompleteProfileData,
                                        "cyan",
                                    )}`}
                                >
                                    {getSectionStateLabel(Boolean(selectedProfile), hasCompleteProfileData)}
                                </span>
                            </div>

                            <div className="mt-4">
                                <span className="rounded-full border border-violet-300/18 bg-violet-500/12 px-4 py-2 text-xs tracking-[0.2em] text-violet-100">
                                    解讀記錄模式焦點區
                                </span>
                            </div>

                            <p className="mt-4 text-[0.88rem] leading-6 text-stone-300">
                                這一區集中呈現 AI 提問、LOT 建議題與解讀紀錄，讓命主上下文、題卡與閱讀結果能在同一工作區連續銜接。
                            </p>

                            {isReadingMode ? (
                                <>
                                    <div className="mt-5 grid gap-3 xl:grid-cols-[0.95fr_1.05fr] lg:mt-6 lg:gap-4">
                                        <div className="rounded-[18px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.78)_100%)] p-4 shadow-[0_0_24px_rgba(124,58,237,0.08)] backdrop-blur-md lg:rounded-[20px] lg:p-5">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <p className="text-[0.95rem] font-medium text-violet-100">主題分類</p>
                                                <p className="text-xs tracking-[0.18em] text-stone-500">先選主題，再抽建議問題</p>
                                            </div>
                                            <div className="mt-4 flex flex-wrap gap-2 lg:mt-5">
                                                {aiTopics.map((topic) => (
                                                    <button
                                                        key={topic}
                                                        type="button"
                                                        disabled
                                                        className={`rounded-full border px-4 py-2 text-sm ${
                                                            readingContext && topic === getReadingTopicLabel(readingContext.questionTopic)
                                                                ? "border-violet-300/24 bg-violet-500/14 text-violet-50"
                                                                : "border-violet-300/14 bg-violet-500/6 text-stone-300"
                                                        }`}
                                                    >
                                                        {topic}
                                                    </button>
                                                ))}
                                            </div>

                                            <div className="mt-4 rounded-[18px] border border-violet-300/16 bg-[rgba(12,16,26,0.82)] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.025)] backdrop-blur-md lg:mt-5">
                                                <p className="text-xs uppercase tracking-[0.22em] text-stone-500">當前上下文</p>
                                                <p className={`mt-3 leading-7 ${readingContext ? "text-base text-stone-200" : "text-sm text-stone-300"}`}>
                                                    {readingContext
                                                        ? `${selectedProfile?.name} / ${
                                                              readingContext.selectedAnnualYear ?? "本命"
                                                          } / ${getReadingTopicLabel(readingContext.questionTopic)}`
                                                        : selectedProfile
                                                          ? hasCompleteProfileData
                                                          ? `${selectedProfile.name} / 本命 / 解讀上下文整理中`
                                                              : `${selectedProfile.name} / 命主資料未齊，暫不建立正式提問`
                                                          : "尚未選定命主，尚未建立 AI 上下文"}
                                                </p>
                                                <p className="mt-3 text-xs leading-6 text-stone-500">
                                                    {readingContext
                                                        ? `prompt：${readingContext.promptVersion} / chart：${readingContext.chartVersion}`
                                                        : "解讀快照建立後會顯示於此"}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="rounded-[18px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.78)_100%)] p-4 shadow-[0_0_24px_rgba(124,58,237,0.08)] backdrop-blur-md lg:rounded-[20px] lg:p-5">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <p className="text-[0.95rem] font-medium text-violet-100">LOT 建議題</p>
                                                <button
                                                    type="button"
                                                    disabled
                                                    className="rounded-full border border-white/10 px-4 py-2 text-xs tracking-[0.18em] text-stone-400"
                                                >
                                                    換一組題卡
                                                </button>
                                            </div>
                                            <div className="mt-4 grid gap-3 md:grid-cols-2 lg:mt-5">
                                                {aiLotCards.map((card, index) => (
                                                    <div
                                                        key={card.id}
                                                        className={`rounded-[18px] border p-4 ${
                                                            index === 0 && readingContext
                                                                ? "border-violet-300/24 bg-violet-500/14 shadow-[0_0_24px_rgba(124,58,237,0.14)]"
                                                                : "border-violet-300/14 bg-violet-500/8"
                                                        }`}
                                                    >
                                                        <p className="text-xs uppercase tracking-[0.22em] text-violet-200/75">
                                                            {card.label}
                                                        </p>
                                                        <p className="mt-3 text-sm leading-7 text-stone-200">
                                                            {index === 0 && readingContext ? readingContext.finalQuestion : card.title}
                                                        </p>
                                                        <p className="mt-3 text-xs leading-6 text-stone-500">
                                                            {index === 0 && readingContext
                                                                ? `主題：${getReadingTopicLabel(readingContext.questionTopic)} / 年度：${
                                                                      readingContext.selectedAnnualYear ?? "本命"
                                                                  }`
                                                                : readingRecord?.summary ?? "系統會依命盤與上下文整理建議題卡。"}
                                                        </p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="mt-4 grid gap-3 xl:grid-cols-[1.15fr_0.85fr] lg:gap-4">
                                        <div className="rounded-[18px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.78)_100%)] p-4 backdrop-blur-md lg:rounded-[20px] lg:p-5">
                                            <div className="flex flex-wrap items-center justify-between gap-3">
                                                <p className="text-[0.95rem] font-medium text-violet-100">提問輸入區</p>
                                                <p className="text-xs tracking-[0.18em] text-stone-500">正式送出前顯示扣點提示</p>
                                            </div>
                                            <div className="mt-4 rounded-[18px] border border-violet-300/16 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md lg:mt-5">     
                                                <p className="text-[0.92rem] leading-7 text-stone-400">
                                                    {readingContext
                                                        ? readingContext.finalQuestion
                                                        : hasCompleteProfileData
                                                          ? "這裡會承接命盤上下文與最終提問內容，作為 深度解讀的正式送出區。"
                                                          : "命主資料未齊，正式提問會在資料補齊後開放。"}
                                                </p>
                                            </div>
                                            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                                                <p className={`text-sm ${readingRecord ? "text-stone-200" : "text-stone-300"}`}>
                                                    {readingRecord
                                                        ? `扣點規則：本筆 Reading 扣 ${readingRecord.tokenCost ?? 0} 點，只有成功產生可保存 Reading 才扣點。`
                                                        : "扣點規則：只有成功產生可保存 Reading 才扣點。"}
                                                </p>
                                                <button
                                                    type="button"
                                                    disabled
                                                    className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 opacity-70"
                                                >
                                                    開始解讀
                                                </button>
                                            </div>
                                        </div>

                                        <div className="rounded-[18px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.78)_100%)] p-4 backdrop-blur-md lg:rounded-[20px] lg:p-5">
                                            <p className="text-[0.95rem] font-medium text-violet-100">Reading 狀態</p>
                                            <div className="mt-5 grid gap-3">
                                                <div className="rounded-[18px] border border-violet-300/16 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md">
                                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-500">歷史提問</p>
                                                    <p className="mt-3 text-sm leading-7 text-stone-300">
                                                        {readingContext
                                                            ? `${(readingContext.createdAt ?? "").slice(0, 10)} / ${readingContext.finalQuestion}`
                                                            : "歷史提問建立後，會依時間順序顯示於此。"}
                                                    </p>
                                                </div>
                                                <div className="rounded-[18px] border border-violet-300/16 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md">
                                                    <p className="text-xs uppercase tracking-[0.22em] text-stone-500">繼續閱讀</p>
                                                    <p className={`mt-3 leading-7 ${readingRecord ? "text-base text-stone-200" : "text-sm text-stone-300"}`}>
                                                        {readingRecord
                                                            ? `${readingRecord.title} / ${getReadingStatusLabel(readingRecord.status ?? "locked")}`
                                                        : "已建立的解讀紀錄會集中顯示於此。"}
                                                    </p>
                                                    <p className="mt-3 text-xs leading-6 text-stone-500">
                                                        {readingRecord?.summary ?? "完成後可從這裡接續閱讀解讀內容。"}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p className="mt-4 text-xs leading-6 text-stone-500">
                                        {readingContext && readingRecord
                                            ? "深度解讀區已接上命主上下文、題卡與閱讀紀錄，可沿著同一條提問路徑持續閱讀。"
                                            : "命主與解讀上下文建立後，這一區會展開完整提問與閱讀流程。"}
                                    </p>
                                </>
                            ) : (
                                <div className="mt-5 rounded-[18px] border border-violet-300/18 bg-[linear-gradient(180deg,rgba(124,58,237,0.12)_0%,rgba(18,24,38,0.78)_100%)] p-4 backdrop-blur-md lg:mt-6 lg:rounded-[20px] lg:p-5">
                                    <div className="flex flex-wrap items-center justify-between gap-3">
                                        <p className="text-[0.95rem] font-medium text-violet-100">深度解讀速覽</p>
                                        <span className="rounded-full border border-violet-300/14 bg-violet-500/10 px-3 py-1 text-[11px] tracking-[0.16em] text-violet-100">
                                            摘要模式
                                        </span>
                                    </div>
                                    <div className="mt-4 grid gap-3 sm:grid-cols-3">
                                        <div className="rounded-[16px] border border-violet-300/18 bg-violet-500/12 p-4 lg:rounded-[18px]">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">當前主題</p>
                                            <p className="mt-3 text-lg font-medium text-stone-100">
                                                {readingContext ? getReadingTopicLabel(readingContext.questionTopic) : "等待解讀上下文"}
                                            </p>
                                            <p className="mt-2 text-xs leading-6 text-stone-500">
                                                {readingContext ? `年度：${readingContext.selectedAnnualYear ?? "本命"}` : `${aiTopics.length} 個主題可用`}
                                            </p>
                                        </div>
                                        <div className="rounded-[16px] border border-violet-300/16 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md lg:rounded-[18px]">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">提問狀態</p>
                                            <p className="mt-3 text-lg font-medium text-stone-100">
                                                {readingContext ? "問題已就緒" : `${aiLotCards.length} 組題卡可展開`}
                                            </p>
                                            <p className="mt-2 text-xs leading-6 text-stone-500">
                                                {readingContext ? readingContext.finalQuestion : "切回 深度解讀模式可查看完整題卡與提問輸入區"}
                                            </p>
                                        </div>
                                        <div className="rounded-[16px] border border-violet-300/16 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md lg:rounded-[18px]">
                                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">解讀紀錄</p>
                                            <p className="mt-3 text-lg font-medium text-stone-100">
                                                {readingRecord ? getReadingStatusLabel(readingRecord.status ?? "locked") : "等待建立"}
                                            </p>
                                            <p className="mt-2 text-xs leading-6 text-stone-500">
                                                {readingRecord ? readingRecord.title : "切回 深度解讀模式可查看完整解讀紀錄"}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="mt-4 flex flex-wrap gap-2">
                                        <span className="rounded-full border border-violet-300/14 bg-violet-500/10 px-3 py-2 text-xs tracking-[0.16em] text-violet-100">
                                            切回 深度解讀可展開題卡、提問與紀錄
                                        </span>
                                        {readingRecord ? (
                                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-300">
                                                扣點：{readingRecord.tokenCost ?? 0} 點
                                            </span>
                                        ) : null}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </article>

                <aside className="rounded-[26px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,24,38,0.9)_0%,rgba(10,14,23,0.98)_100%)] p-5 shadow-[0_0_90px_rgba(124,58,237,0.08)] lg:rounded-[32px] lg:p-8 xl:sticky xl:top-8">
                    <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">工作側欄</p>
                    <h2 className="mt-4 text-[1.65rem] leading-tight tracking-[0.03em] text-stone-50 lg:text-[2.05rem] lg:tracking-[0.05em]">命主切換器</h2>
                    <p className="mt-4 text-[0.95rem] leading-7 text-stone-300">
                        這裡是八字工作側欄。命理師可先鎖定命主，再決定要進入本命盤、大運流年或 解讀記錄。
                    </p>

                    <div className="mt-5 rounded-[22px] border border-amber-400/16 bg-amber-500/10 p-4 backdrop-blur-md lg:mt-6 lg:rounded-[26px] lg:p-5">
                        <p className="text-xs uppercase tracking-[0.22em] text-amber-200/45">目前命主</p>
                        <p className="mt-3 text-[1.35rem] tracking-[0.04em] text-amber-50 lg:text-2xl lg:tracking-[0.05em]">
                            {selectedProfile ? selectedProfile.name : "尚未選定命主"}
                        </p>
                        <div className="mt-4 flex flex-wrap gap-2">
                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-200">
                                類型：{selectedProfile?.tag ?? "未選擇"}
                            </span>
                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-200">
                                性別：{selectedProfile?.gender ?? "未選擇"}
                            </span>
                            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs tracking-[0.16em] text-stone-200">
                                狀態：{hasCompleteProfileData ? "可排盤" : "待補資料"}
                            </span>
                        </div>
                    </div>

                    <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                        <div className="rounded-[20px] border border-white/8 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md lg:rounded-[24px]">
                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">側欄概況</p>
                            <p className="mt-3 text-lg text-stone-100">命主總數：{workspaceData.availableProfiles.length}</p>
                            <p className="mt-2 text-sm leading-7 text-stone-400">
                                已綁定命主後，右側側欄會作為工作切換與資料回看的固定入口。
                            </p>
                        </div>
                        <div className="rounded-[20px] border border-white/8 bg-[rgba(18,24,38,0.74)] p-4 backdrop-blur-md lg:rounded-[24px]">
                            <p className="text-xs uppercase tracking-[0.2em] text-stone-500">目前路線</p>
                            <div className="mt-3 flex flex-wrap gap-2">
                                <span
                                    className={`rounded-full border px-3 py-2 text-xs tracking-[0.16em] ${
                                        activeMode === "natal"
                                            ? "border-amber-300/20 bg-amber-50/[0.08] text-amber-50"
                                            : "border-white/10 bg-white/[0.03] text-stone-200"
                                    }`}
                                >
                                    本命盤
                                </span>
                                <span
                                    className={`rounded-full border px-3 py-2 text-xs tracking-[0.16em] ${
                                        activeMode === "timing"
                                            ? "border-amber-300/20 bg-amber-50/[0.08] text-amber-50"
                                            : "border-white/10 bg-white/[0.03] text-stone-200"
                                    }`}
                                >
                                    大運流年
                                </span>
                                <span
                                    className={`rounded-full border px-3 py-2 text-xs tracking-[0.16em] ${
                                        activeMode === "reading"
                                            ? "border-cyan-300/20 bg-cyan-50/[0.08] text-cyan-50"
                                            : "border-cyan-300/10 bg-cyan-50/[0.03] text-cyan-50/80"
                                    }`}
                                >
                                    解讀記錄
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="mt-5 border-t border-white/8 pt-5 lg:mt-6 lg:pt-6">
                        <div className="flex items-center justify-between gap-3">
                            <p className="text-sm text-amber-100">命主名單</p>
                            <Link
                                href="/profiles"
                                className="rounded-full border border-white/10 px-3 py-2 text-xs tracking-[0.16em] text-stone-200 transition hover:border-amber-300/34 hover:bg-amber-50/[0.05] hover:text-amber-50"
                            >
                                管理資料庫
                            </Link>
                        </div>
                        <div className="mt-4 grid gap-3">
                            {workspaceData.availableProfiles.length > 0 ? (
                                workspaceData.availableProfiles.map((profile) => {
                                    const isActive = profile.id === selectedProfile?.id;

                                    return (
                                        <Link
                                            key={profile.id}
                                            href={buildBaziHref(profile.id, activeMode)}
                                            className={`rounded-[22px] border px-4 py-4 text-sm transition lg:rounded-[26px] ${
                                                isActive
                                                    ? "border-amber-300/42 bg-amber-50/[0.08] text-amber-50 shadow-[0_0_34px_rgba(251,191,36,0.1)]"
                                                    : "border-white/8 bg-[#120d0b]/95 text-stone-200 hover:border-amber-300/32 hover:bg-amber-50/[0.04] hover:text-amber-50"
                                            }`}
                                        >
                                            <div className="flex items-start justify-between gap-3">
                                                <div>
                                                    <p className="text-[0.95rem] tracking-[0.02em] lg:text-base lg:tracking-[0.03em]">{profile.name}</p>
                                                    <p className="mt-2 text-xs tracking-[0.18em] text-stone-400">
                                                        {profile.tag} / {profile.birthDate} / {profile.birthTime}
                                                    </p>
                                                </div>
                                                <span
                                                    className={`rounded-full border px-3 py-1 text-[11px] tracking-[0.16em] ${
                                                        isActive
                                                            ? "border-amber-300/26 bg-amber-50/[0.07] text-amber-50"
                                                            : "border-white/10 bg-white/[0.03] text-stone-300"
                                                    }`}
                                                >
                                                    {isActive ? "目前命主" : "切換"}
                                                </span>
                                            </div>
                                            <div className="mt-3 flex flex-wrap gap-2 lg:mt-4">
                                                <span className="rounded-full border border-white/8 bg-white/[0.03] px-3 py-1 text-[11px] tracking-[0.16em] text-stone-300">
                                                    性別：{profile.gender}
                                                </span>
                                                <span className="rounded-full border border-white/8 bg-white/[0.03] px-3 py-1 text-[11px] tracking-[0.16em] text-stone-300">
                                                    出生地：{profile.birthPlace}
                                                </span>
                                            </div>
                                        </Link>
                                    );
                                })
                            ) : (
                                <div className="rounded-2xl border border-dashed border-white/10 px-4 py-6 text-sm leading-7 text-stone-400">
                                    目前還沒有親友資料，請先到親友資料庫新增一筆命主資料。
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="mt-5 rounded-[22px] border border-white/8 bg-[#120d0b]/95 p-4 backdrop-blur-sm lg:mt-6 lg:rounded-[26px] lg:p-5">
                        <p className="text-xs uppercase tracking-[0.2em] text-stone-500">快速操作</p>
                        <div className="mt-4 grid gap-2.5 lg:gap-3">
                            <Link
                                href="/profiles/new"
                                className="rounded-[18px] border border-white/8 bg-white/[0.03] px-4 py-3 text-sm text-stone-200 transition hover:border-amber-300/32 hover:bg-amber-50/[0.045] hover:text-amber-50 lg:rounded-2xl"
                            >
                                新增命主資料
                            </Link>
                            {selectedProfile ? (
                                <Link
                                    href={`/profiles/${selectedProfile.id}`}
                                    className="rounded-[18px] border border-white/8 bg-white/[0.03] px-4 py-3 text-sm text-stone-200 transition hover:border-amber-300/32 hover:bg-amber-50/[0.045] hover:text-amber-50 lg:rounded-2xl"
                                >
                                    查看目前命主詳情
                                </Link>
                            ) : null}
                        </div>
                    </div>
                </aside>
            </section>
        </PageShell>
    );
}
