import Link from "next/link";
import { ArrowRight, BookOpenText, CheckCircle2, ShieldCheck, Sparkles, UserRoundCheck } from "lucide-react";

import { ModuleGrid } from "@/components/module-grid";
import { PageShell } from "@/components/page-shell";
import { XuanjingBridge } from "@/components/xuanjing-bridge";
import { productModules } from "@/lib/site-data";

const plans = [
    {
        name: "免費基本排盤",
        price: "NT$0",
        description: "先把命盤基本結構看清楚，確認資料與方向，再決定是否需要深入。",
        features: ["八字基本盤", "紫微基本盤", "兩人基本比較"],
        href: "/auth" as const,
        cta: "建立免費命盤",
    },
    {
        name: "個人深度解讀",
        price: "NT$299",
        description: "針對單一命主，把命局、歲運與目前真正需要處理的問題拉到同一條線上看。",
        features: ["個人命局深度整理", "重要時間節點", "白話重點與實際建議"],
        href: "/services?plan=personal_299" as const,
        cta: "提出解讀需求",
    },
    {
        name: "雙人深度合盤",
        price: "NT$1,200",
        description: "雙方八字＋紫微交叉閱讀，適合感情、婚姻、合作或長期關係的重要決定。",
        features: ["雙人八字互動", "紫微關係結構", "相處風險與調整方向"],
        href: "/services?plan=compatibility_1200" as const,
        cta: "提出合盤需求",
    },
] as const;

export default function HomePage() {
    return (
        <PageShell
            eyebrow="HUGO 天命智庫"
            title="先免費看懂，再一步一步讀深。"
            description="八字、紫微斗數與雙人合盤都採同一套由淺入深的閱讀方式：先免費看基本盤與核心摘要，真正需要處理感情、工作、財運或關係決策時，再進入 HUGO 深度解讀。"
            actions={
                <>
                    <Link
                        href="/auth"
                        className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 shadow-[0_0_30px_rgba(251,191,36,0.2)]"
                    >
                        免費建立命盤
                    </Link>
                    <Link
                        href="/about"
                        className="rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 transition hover:border-amber-300/35 hover:bg-amber-50/[0.06]"
                    >
                        認識 HUGO
                    </Link>
                </>
            }
        >
            <section className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
                <article className="overflow-hidden rounded-[30px] border border-amber-300/14 bg-[linear-gradient(135deg,rgba(37,21,13,0.92)_0%,rgba(17,12,10,0.98)_58%,rgba(9,7,6,1)_100%)] p-7 shadow-[0_0_90px_rgba(217,119,6,0.08)] lg:p-9">
                    <p className="text-xs uppercase tracking-[0.36em] text-amber-200/55">命理服務主線</p>
                    <h2 className="mt-4 max-w-3xl text-3xl leading-tight tracking-[0.06em] text-stone-50 lg:text-4xl">
                        免費盤先給你資料，深度解讀才處理真正的問題。
                    </h2>
                    <p className="mt-5 max-w-3xl text-sm leading-8 text-stone-300">
                        不把免費頁做成一堆看不懂的術語，也不急著把使用者推去付費。基本盤先讓人知道自己在看什麼；需要更深時，再進入完整歲運、關係或個人決策分析。
                    </p>
                    <div className="mt-7 grid gap-3 sm:grid-cols-3">
                        {["八字命盤", "紫微斗數", "兩人合盤"].map((item) => (
                            <div key={item} className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-4 text-sm text-stone-200">
                                <CheckCircle2 className="mb-3 h-5 w-5 text-amber-200" />
                                {item}
                            </div>
                        ))}
                    </div>
                </article>

                <aside className="rounded-[30px] border border-white/10 bg-white/[0.035] p-7 lg:p-8">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-300/20 bg-amber-200/10">
                        <UserRoundCheck className="h-5 w-5 text-amber-100" />
                    </div>
                    <p className="mt-5 text-xs uppercase tracking-[0.34em] text-amber-200/55">HUGO 深度解讀</p>
                    <h2 className="mt-3 text-2xl tracking-[0.06em] text-stone-50">需要深入時，直接把問題交進來。</h2>
                    <p className="mt-4 text-sm leading-7 text-stone-300">
                        會員選好命主資料與服務方案後，就能把實際問題送到 HUGO 工作台。八字、紫微與合盤資料不必重填。
                    </p>
                    <Link href="/services" className="mt-6 inline-flex items-center gap-2 text-sm text-amber-100 hover:text-amber-50">
                        查看深度服務 <ArrowRight className="h-4 w-4" />
                    </Link>
                </aside>
            </section>

            <section className="rounded-[30px] border border-white/9 bg-white/[0.025] p-7 lg:p-8">
                <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">閱讀方式</p>
                <h2 className="mt-3 text-3xl tracking-[0.06em] text-stone-50">三大主題，都用同一種節奏：免費 → 初見 → 深度。</h2>
                <p className="mt-4 max-w-4xl text-sm leading-8 text-stone-400">不要求使用者先學會命理術語，也不把所有資訊一次塞滿。每個主題都先給能看懂的免費內容，再把真正需要深入的部分清楚標價。</p>
                <div className="mt-6 grid gap-4 lg:grid-cols-3">
                    {[
                        { title: "八字", path: "/bazi" as const, flow: "四柱／日主／五行 → 個性／感情／事業摘要 → NT$299 深度解讀" },
                        { title: "紫微斗數", path: "/ziwei" as const, flow: "命宮／主星／十二宮 → 夫妻／官祿／財帛摘要 → NT$299 深度解讀" },
                        { title: "雙人合盤", path: "/compatibility" as const, flow: "基本互動 → 情緒／溝通／衝突摘要 → NT$1,200 八字＋紫微深度合盤" },
                    ].map((item) => (
                        <Link key={item.title} href={item.path} className="group rounded-[24px] border border-white/8 bg-[#120d0b] p-5 hover:border-amber-300/20 hover:bg-amber-50/[0.035]">
                            <p className="text-xl tracking-[0.06em] text-stone-50">{item.title}</p>
                            <p className="mt-3 text-sm leading-7 text-stone-400">{item.flow}</p>
                            <span className="mt-4 inline-flex items-center gap-2 text-sm text-amber-100">開始閱讀 <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></span>
                        </Link>
                    ))}
                </div>
            </section>

            <ModuleGrid items={productModules} />

            <section>
                <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
                    <div>
                        <p className="text-xs uppercase tracking-[0.36em] text-amber-200/55">服務方案</p>
                        <h2 className="mt-3 text-3xl tracking-[0.06em] text-stone-50">先免費看盤，再依需求深入。</h2>
                    </div>
                    <p className="max-w-xl text-sm leading-7 text-stone-400">價格與服務層級直接公開，不用先私訊才知道。</p>
                </div>
                <div className="grid gap-4 lg:grid-cols-3">
                    {plans.map((plan, index) => (
                        <article
                            key={plan.name}
                            className={`rounded-[28px] border p-6 lg:p-7 ${index === 1 ? "border-amber-300/26 bg-amber-50/[0.055] shadow-[0_0_70px_rgba(217,119,6,0.08)]" : "border-white/10 bg-white/[0.03]"}`}
                        >
                            <p className="text-xs uppercase tracking-[0.28em] text-amber-200/55">{plan.name}</p>
                            <p className="mt-4 text-4xl font-medium tracking-[0.03em] text-stone-50">{plan.price}</p>
                            <p className="mt-4 min-h-20 text-sm leading-7 text-stone-300">{plan.description}</p>
                            <div className="mt-5 space-y-3">
                                {plan.features.map((feature) => (
                                    <div key={feature} className="flex items-start gap-3 text-sm text-stone-300">
                                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-amber-200" />
                                        <span>{feature}</span>
                                    </div>
                                ))}
                            </div>
                            <Link
                                href={plan.href}
                                className="mt-7 inline-flex items-center gap-2 rounded-full border border-amber-200/24 px-4 py-2.5 text-sm text-amber-50 transition hover:bg-amber-50/[0.06]"
                            >
                                {plan.cta} <ArrowRight className="h-4 w-4" />
                            </Link>
                        </article>
                    ))}
                </div>
            </section>

            <section className="grid gap-4 md:grid-cols-3">
                {[
                    { icon: ShieldCheck, title: "會員資料隔離", text: "命主資料依登入帳號分流，會員只能讀取自己的資料。" },
                    { icon: BookOpenText, title: "傳統命理脈絡", text: "八字時間閱讀保留經典來源與規則說明，避免只剩一句模糊結論。" },
                    { icon: Sparkles, title: "白話閱讀", text: "基本盤盡量用一般人看得懂的文字呈現；專業術語放在需要的地方。" },
                ].map((item) => {
                    const Icon = item.icon;
                    return (
                        <article key={item.title} className="rounded-[26px] border border-white/9 bg-white/[0.025] p-6">
                            <Icon className="h-5 w-5 text-amber-200" />
                            <h3 className="mt-4 text-xl tracking-[0.05em] text-stone-50">{item.title}</h3>
                            <p className="mt-3 text-sm leading-7 text-stone-400">{item.text}</p>
                        </article>
                    );
                })}
            </section>

            <XuanjingBridge />
        </PageShell>
    );
}
