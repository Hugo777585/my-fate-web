"use server";

import { revalidatePath } from "next/cache";

import { requireOwner } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

const allowedStatuses = new Set(["submitted", "in_review", "contacted", "completed", "cancelled"]);

export async function updateConsultationStatusAction(requestId: string, formData: FormData) {
    await requireOwner();
    const status = String(formData.get("status") ?? "");
    if (!allowedStatuses.has(status)) throw new Error("案件狀態不正確。");

    const supabase = await createClient();
    const { error } = await supabase
        .from("consultation_requests")
        .update({ status, updated_at: new Date().toISOString() })
        .eq("id", requestId);
    if (error) throw new Error(`更新案件失敗：${error.message}`);
    revalidatePath("/workspace");
}
