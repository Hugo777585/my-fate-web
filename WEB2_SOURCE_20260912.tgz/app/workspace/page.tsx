import Link from "next/link";
import { ArrowRight, BookOpenText, HeartHandshake, Plus, Sparkles, Stars, UserRoundCog } from "lucide-react";

import { updateConsultationStatusAction } from "@/app/workspace/actions";
import { PageShell } from "@/components/page-shell";
import { requireOwner } from "@/lib/auth";
import { listConsultationRequestsForOwner } from "@/lib/consultations";
import { listProfiles } from "@/lib/profiles";

function complete(profile: Awaited<ReturnType<typeof listProfiles>>[number]) {
    return [profile.gender, profile.birthDate, profile.birthTime, profile.birthPlace].every((value) => value && value !== "未填");
}

function statusLabel(status: string) {
    return ({ submitted: "新案件", in_review: "處理中", contacted: "已聯繫", completed: "已完成", cancelled: "取消" } as Record<string, string>)[status] ?? status;
}

export default async function WorkspacePage() {
    const { user } = await requireOwner();
    const [profiles, requests] = await Promise.all([listProfiles(user.id), listConsultationRequestsForOwner()]);
    const clients = profiles.filter((profile) => profile.tag === "客戶");
    const completeCount = clients.filter(complete).length;
    const openRequests = requests.filter((item) => !["completed", "cancelled"].includes(item.status)).length;

    return (
        <PageShell
            eyebrow="HUGO 客戶工作台"
            title="線上客戶從送件、建檔到排盤集中處理。"
            description="一般會員無法進入這裡。客戶送出的 NT$299 個人深度解讀與 NT$1,200 雙人合盤會直接進案件列表，HUGO 可再沿用同一套命主資料處理八字、紫微與合盤。"
            actions={<Link href="/profiles/new" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950"><Plus className="h-4 w-4" />新增客戶資料</Link>}
        >
            <section className="grid gap-4 sm:grid-cols-4">
                {[{label:"自建客戶",value:clients.length},{label:"資料完整",value:completeCount},{label:"待補資料",value:Math.max(0,clients.length-completeCount)},{label:"待處理案件",value:openRequests}].map((item) => (
                    <article key={item.label} className="rounded-[26px] border border-white/10 bg-white/[0.03] p-6"><p className="text-xs uppercase tracking-[0.26em] text-stone-500">{item.label}</p><p className="mt-3 text-4xl text-stone-50">{item.value}</p></article>
                ))}
            </section>

            <section className="rounded-[30px] border border-amber-300/16 bg-[#140d0b] p-7">
                <div className="flex items-center gap-3"><UserRoundCog className="h-5 w-5 text-amber-200"/><p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">線上服務案件</p></div>
                <h2 className="mt-3 text-2xl text-stone-50">會員送給 HUGO 的深度解讀需求</h2>
                <div className="mt-6 grid gap-4">
                    {requests.length ? requests.map((request) => {
                        const updateAction = updateConsultationStatusAction.bind(null, request.id);
                        return (
                            <article key={request.id} className="rounded-[22px] border border-white/8 bg-[#120d0b] p-5">
                                <div className="flex flex-wrap items-start justify-between gap-4">
                                    <div>
                                        <p className="text-lg text-stone-50">{request.serviceCode === "compatibility_1200" ? "雙人深度合盤" : "個人深度解讀"} · NT${request.amountTwd.toLocaleString("zh-TW")}</p>
                                        <p className="mt-2 text-sm text-stone-400">{request.profileName}{request.secondProfileName ? ` × ${request.secondProfileName}` : ""}</p>
                                        <p className="mt-3 max-w-4xl whitespace-pre-wrap text-sm leading-7 text-stone-300">{request.question}</p><p className="mt-3 text-xs text-amber-100/75">聯絡：{request.contactNote || "未填"}</p>
                                    </div>
                                    <span className="rounded-full border border-amber-200/15 bg-amber-50/[0.04] px-3 py-1.5 text-xs text-amber-100">{statusLabel(request.status)}</span>
                                </div>
                                <div className="mt-5 flex flex-wrap items-center gap-2">
                                    <Link href={`/bazi?profile=${request.profileId}`} className="rounded-full border border-white/10 px-3 py-2 text-xs text-stone-200">八字</Link>
                                    <Link href={`/ziwei?profile=${request.profileId}`} className="rounded-full border border-white/10 px-3 py-2 text-xs text-stone-200">紫微</Link>
                                    {request.secondProfileId ? <Link href={`/compatibility?a=${request.profileId}&b=${request.secondProfileId}`} className="rounded-full border border-amber-200/15 px-3 py-2 text-xs text-amber-100">合盤</Link> : null}
                                    <form action={updateAction} className="ml-auto flex flex-wrap items-center gap-2">
                                        <select name="status" defaultValue={request.status} className="rounded-full border border-white/10 bg-[#0d0908] px-3 py-2 text-xs text-stone-200">
                                            <option value="submitted">新案件</option><option value="in_review">處理中</option><option value="contacted">已聯繫</option><option value="completed">已完成</option><option value="cancelled">取消</option>
                                        </select>
                                        <button className="rounded-full border border-amber-200/18 px-3 py-2 text-xs text-amber-100">更新</button>
                                    </form>
                                </div>
                            </article>
                        );
                    }) : <p className="rounded-[22px] border border-dashed border-white/10 p-6 text-sm text-stone-400">目前沒有會員送出的深度解讀案件。</p>}
                </div>
            </section>

            <section className="grid gap-4 lg:grid-cols-3">
                {([{href:"/bazi",label:"八字工作區",desc:"四柱、五行、大運、流年",icon:Sparkles},{href:"/ziwei",label:"紫微工作區",desc:"十二宮、主星、四化",icon:Stars},{href:"/compatibility",label:"雙人合盤",desc:"選兩筆命主做關係比較",icon:HeartHandshake}] as const).map((item) => { const Icon=item.icon; return <Link key={item.href} href={item.href} className="group rounded-[28px] border border-white/10 bg-white/[0.03] p-6 transition hover:-translate-y-1 hover:border-amber-300/30"><Icon className="h-5 w-5 text-amber-200"/><h2 className="mt-5 text-2xl text-stone-50">{item.label}</h2><p className="mt-2 text-sm text-stone-400">{item.desc}</p><ArrowRight className="mt-5 h-4 w-4 text-stone-600 transition group-hover:translate-x-1 group-hover:text-amber-100"/></Link>})}
            </section>

            <section className="rounded-[30px] border border-white/10 bg-white/[0.025] p-7">
                <div className="flex flex-wrap items-center justify-between gap-4"><div><div className="flex items-center gap-3"><BookOpenText className="h-5 w-5 text-amber-200"/><p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">自行建立的客戶</p></div><h2 className="mt-3 text-2xl text-stone-50">HUGO 手動建檔資料</h2></div><Link href="/profiles" className="text-sm text-amber-100 hover:text-amber-50">查看全部命主資料 →</Link></div>
                <div className="mt-6 grid gap-3">
                    {clients.length ? clients.slice(0,12).map((client) => <article key={client.id} className="grid gap-4 rounded-[22px] border border-white/8 bg-[#120d0b] p-5 lg:grid-cols-[1fr_auto] lg:items-center"><div><p className="text-lg text-stone-50">{client.name}</p><p className="mt-1 text-xs text-stone-500">{client.birthDate} · {client.birthTime} · {client.birthPlace}</p><p className={`mt-2 text-xs ${complete(client)?"text-emerald-300":"text-amber-200"}`}>{complete(client)?"排盤資料完整":"資料尚未補齊"}</p></div><div className="flex flex-wrap gap-2"><Link href={`/profiles/${client.id}`} className="rounded-full border border-white/10 px-3 py-2 text-xs text-stone-300">資料</Link><Link href={`/bazi?profile=${client.id}`} className="rounded-full border border-amber-200/15 px-3 py-2 text-xs text-amber-100">八字</Link><Link href={`/ziwei?profile=${client.id}`} className="rounded-full border border-amber-200/15 px-3 py-2 text-xs text-amber-100">紫微</Link><Link href={`/compatibility?profile=${client.id}`} className="rounded-full border border-amber-200/15 px-3 py-2 text-xs text-amber-100">合盤</Link></div></article>) : <div className="rounded-[22px] border border-dashed border-white/10 p-7 text-sm leading-7 text-stone-400">目前沒有 HUGO 手動建立的客戶資料。</div>}
                </div>
            </section>
        </PageShell>
    );
}
