import { Coins, Gift, History, Hourglass, WalletCards } from "lucide-react";

import { PageShell } from "@/components/page-shell";
import { WalletPurchaseButton } from "@/components/wallet-purchase-button";
import { requireUser } from "@/lib/auth";
import { getWalletData, walletPackages } from "@/lib/wallet";

function formatDate(value: string | null) {
    if (!value) return "永久";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("zh-TW", { dateStyle: "medium" }).format(date);
}

export default async function WalletPage() {
    const user = await requireUser();
    const wallet = await getWalletData(user.id);

    return (
        <PageShell
            eyebrow="天命幣錢包"
            title="餘額、贈幣效期與交易紀錄一次看清楚。"
            description="系統會優先使用較早到期的贈幣，再使用永久儲值點數。付款完成後由後端回調入帳，不由前端自行加幣。"
        >
            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                    { label: "目前餘額", value: wallet.balance, suffix: "枚", icon: Coins },
                    { label: "暫時保留", value: wallet.reservedPoints, suffix: "枚", icon: Hourglass },
                    { label: "累積儲值", value: wallet.lifetimePurchased, suffix: "枚", icon: WalletCards },
                    { label: "累積贈幣", value: wallet.lifetimeBonus, suffix: "枚", icon: Gift },
                ].map((item) => {
                    const Icon = item.icon;
                    return (
                        <article key={item.label} className="rounded-[26px] border border-white/10 bg-white/[0.03] p-6">
                            <Icon className="h-5 w-5 text-amber-200" />
                            <p className="mt-5 text-xs uppercase tracking-[0.26em] text-stone-500">{item.label}</p>
                            <p className="mt-2 text-4xl font-medium tracking-[0.03em] text-stone-50">{item.value}<span className="ml-1 text-sm text-stone-500">{item.suffix}</span></p>
                        </article>
                    );
                })}
            </section>

            <section>
                <div className="mb-5">
                    <p className="text-xs uppercase tracking-[0.32em] text-amber-200/55">儲值方案</p>
                    <h2 className="mt-3 text-3xl tracking-[0.05em] text-stone-50">選擇天命幣方案</h2>
                </div>
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    {walletPackages.map((pkg) => (
                        <article key={pkg.code} className={`rounded-[28px] border p-6 ${pkg.featured ? "border-amber-300/30 bg-amber-50/[0.055] shadow-[0_0_60px_rgba(217,119,6,0.08)]" : "border-white/10 bg-white/[0.03]"}`}>
                            <div className="flex items-center justify-between gap-3">
                                <p className="text-xs uppercase tracking-[0.24em] text-amber-200/60">{pkg.name}</p>
                                {pkg.featured ? <span className="rounded-full border border-amber-200/20 bg-amber-50/[0.06] px-2.5 py-1 text-[10px] text-amber-100">熱門</span> : null}
                            </div>
                            <p className="mt-4 text-3xl font-medium text-stone-50">NT${pkg.amount.toLocaleString("zh-TW")}</p>
                            <p className="mt-3 text-sm text-stone-300">{pkg.points + pkg.bonus} 枚天命幣</p>
                            <p className="mt-1 min-h-6 text-xs text-stone-500">{pkg.bonus > 0 ? `含贈送 ${pkg.bonus} 枚` : "10 枚永久儲值幣"}</p>
                            <div className="mt-6">
                                <WalletPurchaseButton packageCode={pkg.code} enabled={wallet.ecpayConfigured} />
                            </div>
                        </article>
                    ))}
                </div>
                {!wallet.ecpayConfigured ? (
                    <p className="mt-4 rounded-2xl border border-amber-200/12 bg-amber-50/[0.035] px-4 py-3 text-xs leading-6 text-amber-50/75">
                        綠界付款程式已完成安全回調與入帳流程；目前尚未放入正式 MerchantID / HashKey / HashIV，因此付款按鈕先鎖定。部署時補上正式金鑰即可啟用。
                    </p>
                ) : null}
            </section>

            <section className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
                <article className="rounded-[28px] border border-white/10 bg-white/[0.03] p-6 lg:p-7">
                    <div className="flex items-center gap-3"><Hourglass className="h-5 w-5 text-amber-200" /><h2 className="text-2xl tracking-[0.05em] text-stone-50">目前可用批次</h2></div>
                    <div className="mt-5 space-y-3">
                        {wallet.lots.length > 0 ? wallet.lots.map((lot) => (
                            <div key={lot.id} className="rounded-[18px] border border-white/8 bg-[#120d0b] px-4 py-4">
                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-sm text-stone-200">{lot.category}</span>
                                    <span className="text-sm text-amber-100">{lot.availablePoints} 枚</span>
                                </div>
                                <p className="mt-2 text-xs text-stone-500">到期：{formatDate(lot.expiresAt)}</p>
                            </div>
                        )) : <p className="rounded-[18px] border border-dashed border-white/10 p-5 text-sm text-stone-400">目前沒有獨立的贈幣批次。</p>}
                    </div>
                </article>

                <article className="rounded-[28px] border border-white/10 bg-white/[0.03] p-6 lg:p-7">
                    <div className="flex items-center gap-3"><History className="h-5 w-5 text-amber-200" /><h2 className="text-2xl tracking-[0.05em] text-stone-50">最近交易</h2></div>
                    <div className="mt-5 space-y-3">
                        {wallet.transactions.length > 0 ? wallet.transactions.map((tx) => (
                            <div key={tx.id} className="grid gap-2 rounded-[18px] border border-white/8 bg-[#120d0b] px-4 py-4 sm:grid-cols-[1fr_auto] sm:items-center">
                                <div>
                                    <p className="text-sm text-stone-200">{tx.reason}</p>
                                    <p className="mt-1 text-xs text-stone-500">{formatDate(tx.createdAt)} · {tx.entryType}</p>
                                </div>
                                <div className="text-right">
                                    <p className={`text-sm ${tx.delta >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{tx.delta >= 0 ? "+" : ""}{tx.delta}</p>
                                    <p className="mt-1 text-xs text-stone-500">餘額 {tx.balanceAfter}</p>
                                </div>
                            </div>
                        )) : <p className="rounded-[18px] border border-dashed border-white/10 p-5 text-sm text-stone-400">目前還沒有交易紀錄。</p>}
                    </div>
                </article>
            </section>
        </PageShell>
    );
}
