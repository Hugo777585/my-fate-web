import { buildBaziChartFromProfile, toAdapterProfile } from "@/lib/bazi-adapter";
import type { BaziChart, BaziElement } from "@/lib/bazi-fixture";
import type { ProfileDetail } from "@/lib/profiles";

const elementLabels: Record<BaziElement, string> = {
    wood: "木",
    fire: "火",
    earth: "土",
    metal: "金",
    water: "水",
};

const productiveNext: Record<BaziElement, BaziElement> = {
    wood: "fire",
    fire: "earth",
    earth: "metal",
    metal: "water",
    water: "wood",
};

const controllingNext: Record<BaziElement, BaziElement> = {
    wood: "earth",
    earth: "water",
    water: "fire",
    fire: "metal",
    metal: "wood",
};

const sixHarmonyPairs = new Set(["子丑", "寅亥", "卯戌", "辰酉", "巳申", "午未"]);
const sixClashPairs = new Set(["子午", "丑未", "寅申", "卯酉", "辰戌", "巳亥"]);
const trineGroups = ["申子辰", "亥卯未", "寅午戌", "巳酉丑"];

function pairKey(a: string, b: string) {
    return [a, b].sort((left, right) => left.localeCompare(right, "zh-Hant")).join("");
}

function hasPair(set: Set<string>, a: string, b: string) {
    return set.has(`${a}${b}`) || set.has(`${b}${a}`) || set.has(pairKey(a, b));
}

function clampScore(score: number) {
    return Math.max(35, Math.min(95, Math.round(score)));
}

function hasCompleteChart(chart: BaziChart) {
    return chart.status === "ready" && Boolean(chart.dayMasterSummary && chart.fourPillars);
}

export type CompatibilityResult = {
    score: number;
    label: string;
    summary: string;
    personA: { name: string; dayMaster: string; element: string; dayBranch: string };
    personB: { name: string; dayMaster: string; element: string; dayBranch: string };
    strengths: string[];
    cautions: string[];
    signals: string[];
};

export async function buildBasicCompatibility(
    profileA: ProfileDetail,
    profileB: ProfileDetail,
): Promise<CompatibilityResult | null> {
    const [chartA, chartB] = await Promise.all([
        buildBaziChartFromProfile(toAdapterProfile(profileA)),
        buildBaziChartFromProfile(toAdapterProfile(profileB)),
    ]);

    if (!hasCompleteChart(chartA) || !hasCompleteChart(chartB)) {
        return null;
    }

    const dmA = chartA.dayMasterSummary!;
    const dmB = chartB.dayMasterSummary!;
    const branchA = chartA.fourPillars!.day.branch;
    const branchB = chartB.fourPillars!.day.branch;
    const strengths: string[] = [];
    const cautions: string[] = [];
    const signals: string[] = [];
    let score = 58;

    if (dmA.element === dmB.element) {
        score += 7;
        strengths.push(`兩人的日主同屬${elementLabels[dmA.element]}，理解彼此做事節奏通常比較快。`);
        signals.push("日主五行同類");
    } else if (productiveNext[dmA.element] === dmB.element || productiveNext[dmB.element] === dmA.element) {
        score += 14;
        strengths.push(`兩人的日主形成五行相生，盤面上有互相補位、帶動彼此的條件。`);
        signals.push("日主五行相生");
    } else if (controllingNext[dmA.element] === dmB.element || controllingNext[dmB.element] === dmA.element) {
        score -= 4;
        cautions.push("日主五行存在相剋關係，遇到壓力時容易用不同方式處理同一件事，需要把界線講清楚。");
        signals.push("日主五行相剋");
    } else {
        score += 3;
        strengths.push("兩人的日主五行差異明顯，若現實目標一致，反而有分工互補的空間。");
        signals.push("日主五行差異");
    }

    if (hasPair(sixHarmonyPairs, branchA, branchB)) {
        score += 18;
        strengths.push(`兩人日支形成六合（${branchA}、${branchB}），互動上較容易出現自然靠近與合作感。`);
        signals.push("日支六合");
    } else if (hasPair(sixClashPairs, branchA, branchB)) {
        score -= 15;
        cautions.push(`兩人日支形成六沖（${branchA}、${branchB}），相處中容易出現節奏、習慣或立場拉扯。`);
        signals.push("日支六沖");
    } else if (branchA === branchB) {
        score += 6;
        strengths.push(`兩人日支同為${branchA}，對關係安全感與生活節奏有部分相似處。`);
        signals.push("日支同支");
    } else if (trineGroups.some((group) => group.includes(branchA) && group.includes(branchB))) {
        score += 8;
        strengths.push(`兩人日支落在同一三合局結構，容易在特定情境下形成共同目標。`);
        signals.push("日支三合結構");
    }

    const strengthGap = Math.abs(dmA.strengthScore - dmB.strengthScore);
    if (strengthGap <= 12) {
        score += 5;
        strengths.push("兩人的日主強弱接近，關係中的主導感通常不會長期只落在同一方。");
        signals.push("日主強弱接近");
    } else if (strengthGap >= 30) {
        score -= 5;
        cautions.push("兩人的日主強弱差距較大，遇到重大決定時要留意一方長期主導、另一方長期退讓。");
        signals.push("日主強弱落差");
    }

    const finalScore = clampScore(score);
    const label = finalScore >= 80
        ? "互補度高"
        : finalScore >= 65
            ? "具穩定互動條件"
            : finalScore >= 50
                ? "需要建立磨合規則"
                : "差異較大，先看現實條件";

    const summary = finalScore >= 80
        ? "基本盤面顯示兩人的互補訊號明顯，適合進一步看大運、流年與紫微宮位互動。"
        : finalScore >= 65
            ? "基本盤面有可合作的結構，但關係能不能走得穩，仍要看現實溝通方式與雙方當下運勢。"
            : finalScore >= 50
                ? "盤面同時存在吸引與摩擦訊號，重點不是只看分數，而是哪些問題會反覆發生。"
                : "基本盤面差異偏大，先把價值觀、生活安排與關係期待談清楚，再看是否值得投入。";

    if (cautions.length === 0) {
        cautions.push("基本盤只看核心結構，尚未納入雙方大運、流年與紫微十二宮，重要決策不宜只用單一分數判斷。");
    }

    return {
        score: finalScore,
        label,
        summary,
        personA: { name: profileA.name, dayMaster: dmA.stem, element: elementLabels[dmA.element], dayBranch: branchA },
        personB: { name: profileB.name, dayMaster: dmB.stem, element: elementLabels[dmB.element], dayBranch: branchB },
        strengths,
        cautions,
        signals,
    };
}
