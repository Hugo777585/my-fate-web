export const BAZI_RULE_VERSION = "v1-standard-time-lichun-jieqi-zichu" as const;
export const BAZI_TIMEZONE = "Asia/Taipei" as const;

export type BaziTimeMode = "natal" | "luck_pillar" | "annual";
export type BaziPillarKey = "year" | "month" | "day" | "hour";
export type BaziElement = "wood" | "fire" | "earth" | "metal" | "water";
export type BaziYinYang = "yin" | "yang";
export type BaziChartStatus =
    | "ready"
    | "missing_required_fields"
    | "calculating"
    | "calculation_failed";
export type BaziReadingStatus = "locked" | "available" | "generating" | "failed";
export type BaziMissingFieldKey = "gender" | "birthDate" | "birthTimeLabel" | "birthPlace";

export type BaziHiddenStem = {
    stem: string;
    tenGod: string;
};

export type BaziPillar = {
    key: BaziPillarKey;
    stem: string;
    branch: string;
    stemTenGod: string;
    hiddenStems: BaziHiddenStem[];
    hiddenStemTenGods: string[];
    growthStage: string;
    nayin: string;
    shensha: string[];
    voidBranches: string[];
};

export type BaziFourPillars = {
    year: BaziPillar;
    month: BaziPillar;
    day: BaziPillar;
    hour: BaziPillar;
};

export type BaziDayMasterSummary = {
    stem: string;
    yinYang: BaziYinYang;
    element: BaziElement;
    title: string;
    strengthScore: number;
    strengthLabel: "極弱" | "偏弱" | "中和" | "偏強" | "極強";
    summary: string;
    pattern: string;
    usefulGods: string[];
    favorableGods: string[];
    unfavorableGods: string[];
};

export type BaziElementBalanceItem = {
    element: BaziElement;
    score: number;
    percentage: number;
    label: "極弱" | "偏弱" | "中和" | "偏強" | "極強";
};

export type BaziElementBalance = Record<BaziElement, BaziElementBalanceItem>;

export type BaziLuckPillar = {
    id: string;
    order: number;
    startAge: number;
    endAge: number;
    startYear: number;
    endYear: number;
    stem: string;
    branch: string;
    stemTenGod: string;
    branchTenGod: string;
    growthStage: string;
    isCurrent: boolean;
    readingStatus: BaziReadingStatus;
    readingId?: string;
};

export type BaziLuckCycle = {
    direction: "forward" | "backward";
    startAge: number;
    startYear: number;
    startMonth: number;
    startDay: number;
    startHour: number;
    startOffsetLabel: string;
    startDateTimeLabel: string;
    calculationBasis: string;
    pillars: BaziLuckPillar[];
};

export type BaziAnnualRelation = {
    relationType: "合" | "沖" | "刑" | "害" | "破" | "會" | "其他";
    target: "本命" | "大運";
    description: string;
};

export type BaziAnnualTheme = {
    key: "career" | "relationship" | "wealth" | "health" | "timing";
    label: string;
    readingStatus: BaziReadingStatus;
    readingId?: string;
};

export type BaziAnnualItem = {
    year: number;
    age: number;
    stem: string;
    branch: string;
    stemTenGod: string;
    branchTenGod: string;
    isCurrent: boolean;
    isSelected: boolean;
    relations: BaziAnnualRelation[];
    themes: BaziAnnualTheme[];
};

export type BaziChart = {
    id: string;
    profileId: string;
    chartVersion: string;
    ruleVersion: string;
    timezone: string;
    standardTimeUsed: boolean;
    trueSolarTimeEnabled: boolean;
    calculatedAt: string;
    status: BaziChartStatus;
    missingFields: BaziMissingFieldKey[];
    fourPillars?: BaziFourPillars;
    dayMasterSummary?: BaziDayMasterSummary;
    elementBalance?: BaziElementBalance;
    luckCycle?: BaziLuckCycle;
    annuals?: BaziAnnualItem[];
};

export type BaziWorkspaceProfileOption = {
    id: string;
    name: string;
    tag: string;
    gender: string;
    birthDate: string;
    birthTime: string;
    birthPlace: string;
};

export type BaziWorkspaceData = {
    profileId?: string;
    mode: BaziTimeMode;
    chart: BaziChart | null;
    availableProfiles: BaziWorkspaceProfileOption[];
    selectedLuckPillarId?: string;
    selectedAnnualYear?: number;
};

export type BaziReadingContextSnapshot = {
    id: string;
    userId: string;
    profileId: string;
    chartId: string;
    chartVersion: string;
    ruleVersion: string;
    system: "bazi";
    mode: BaziTimeMode;
    selectedLuckPillarId?: string;
    selectedAnnualYear?: number;
    questionTopic?: "career" | "relationship" | "wealth" | "health" | "timing";
    finalQuestion: string;
    modelVersion?: string;
    promptVersion?: string;
    createdAt: string;
};

export type BaziReadingRecord = {
    id: string;
    profileId: string;
    contextSnapshotId: string;
    status: BaziReadingStatus;
    title: string;
    summary: string;
    content: string;
    tokenCost?: number;
    createdAt: string;
    updatedAt: string;
};

export type BuildBaziChartInput = {
    profileId: string;
    gender: string;
    birthDate: string;
    birthTimeLabel: string;
    birthPlace: string;
    timezone: typeof BAZI_TIMEZONE;
    ruleVersion: string;
};

export interface BaziChartAdapter {
    buildChart(input: BuildBaziChartInput): Promise<BaziChart>;
}

const baseCalculatedAt = "2026-07-21T21:08:00+08:00";

export const baziFixtureProfiles: BaziWorkspaceProfileOption[] = [
    {
        id: "fixture-chen",
        name: "陳星宇",
        tag: "本人",
        gender: "男",
        birthDate: "1988-10-23",
        birthTime: "子時 23:00-01:00",
        birthPlace: "台北",
    },
    {
        id: "fixture-lin",
        name: "林若衡",
        tag: "親友",
        gender: "女",
        birthDate: "1992-06-18",
        birthTime: "未時 13:00-15:00",
        birthPlace: "台中",
    },
    {
        id: "fixture-missing",
        name: "測試命主B",
        tag: "客戶",
        gender: "未填",
        birthDate: "未填",
        birthTime: "未填",
        birthPlace: "高雄",
    },
];

const baseFourPillars: BaziFourPillars = {
    year: {
        key: "year",
        stem: "戊",
        branch: "辰",
        stemTenGod: "偏財",
        hiddenStems: [
            { stem: "戊", tenGod: "偏財" },
            { stem: "乙", tenGod: "正官" },
            { stem: "癸", tenGod: "正印" },
        ],
        hiddenStemTenGods: ["偏財", "正官", "正印"],
        growthStage: "冠帶",
        nayin: "大林木",
        shensha: ["華蓋", "天乙"],
        voidBranches: ["戌", "亥"],
    },
    month: {
        key: "month",
        stem: "壬",
        branch: "戌",
        stemTenGod: "偏印",
        hiddenStems: [
            { stem: "戊", tenGod: "偏財" },
            { stem: "辛", tenGod: "食神" },
            { stem: "丁", tenGod: "劫財" },
        ],
        hiddenStemTenGods: ["偏財", "食神", "劫財"],
        growthStage: "衰",
        nayin: "大海水",
        shensha: ["月德", "將星"],
        voidBranches: ["申", "酉"],
    },
    day: {
        key: "day",
        stem: "甲",
        branch: "午",
        stemTenGod: "日主",
        hiddenStems: [
            { stem: "丁", tenGod: "傷官" },
            { stem: "己", tenGod: "正財" },
        ],
        hiddenStemTenGods: ["傷官", "正財"],
        growthStage: "死",
        nayin: "沙中金",
        shensha: ["天喜", "紅鸞"],
        voidBranches: ["辰", "巳"],
    },
    hour: {
        key: "hour",
        stem: "丙",
        branch: "子",
        stemTenGod: "食神",
        hiddenStems: [{ stem: "癸", tenGod: "正印" }],
        hiddenStemTenGods: ["正印"],
        growthStage: "沐浴",
        nayin: "澗下水",
        shensha: ["文昌", "太極"],
        voidBranches: ["寅", "卯"],
    },
};

const baseElementBalance: BaziElementBalance = {
    wood: { element: "wood", score: 78, percentage: 26, label: "偏強" },
    fire: { element: "fire", score: 54, percentage: 18, label: "中和" },
    earth: { element: "earth", score: 72, percentage: 24, label: "偏強" },
    metal: { element: "metal", score: 42, percentage: 14, label: "偏弱" },
    water: { element: "water", score: 57, percentage: 18, label: "中和" },
};

const baseLuckCycle: BaziLuckCycle = {
    direction: "forward",
    startAge: 6,
    startYear: 1994,
    startMonth: 2,
    startDay: 0,
    startHour: 0,
    startOffsetLabel: "5 年 2 個月",
    startDateTimeLabel: "1994-04-15 07:00",
    calculationBasis: "三日一歲 / 一日四個月 / 一小時五天",
    pillars: [
        {
            id: "luck-1",
            order: 1,
            startAge: 6,
            endAge: 15,
            startYear: 1994,
            endYear: 2003,
            stem: "癸",
            branch: "亥",
            stemTenGod: "正印",
            branchTenGod: "偏印",
            growthStage: "長生",
            isCurrent: false,
            readingStatus: "available",
            readingId: "reading-luck-1",
        },
        {
            id: "luck-2",
            order: 2,
            startAge: 16,
            endAge: 25,
            startYear: 2004,
            endYear: 2013,
            stem: "甲",
            branch: "子",
            stemTenGod: "比肩",
            branchTenGod: "正印",
            growthStage: "沐浴",
            isCurrent: false,
            readingStatus: "locked",
        },
        {
            id: "luck-3",
            order: 3,
            startAge: 26,
            endAge: 35,
            startYear: 2014,
            endYear: 2023,
            stem: "乙",
            branch: "丑",
            stemTenGod: "劫財",
            branchTenGod: "正財",
            growthStage: "冠帶",
            isCurrent: false,
            readingStatus: "locked",
        },
        {
            id: "luck-4",
            order: 4,
            startAge: 36,
            endAge: 45,
            startYear: 2024,
            endYear: 2033,
            stem: "丙",
            branch: "寅",
            stemTenGod: "食神",
            branchTenGod: "比肩",
            growthStage: "臨官",
            isCurrent: true,
            readingStatus: "available",
            readingId: "reading-luck-4",
        },
    ],
};

const baseAnnuals: BaziAnnualItem[] = [
    {
        year: 2026,
        age: 38,
        stem: "丙",
        branch: "午",
        stemTenGod: "食神",
        branchTenGod: "傷官",
        isCurrent: true,
        isSelected: true,
        relations: [
            { relationType: "合", target: "本命", description: "與日柱形成火局呼應，利於表達與曝光。" },
            { relationType: "沖", target: "大運", description: "與當前大運節奏有推進感，適合主動布局。" },
        ],
        themes: [
            { key: "career", label: "事業", readingStatus: "available", readingId: "reading-2026-career" },
            { key: "relationship", label: "情感", readingStatus: "locked" },
            { key: "wealth", label: "財局", readingStatus: "locked" },
            { key: "health", label: "康健", readingStatus: "locked" },
            { key: "timing", label: "時運", readingStatus: "available", readingId: "reading-2026-timing" },
        ],
    },
    {
        year: 2027,
        age: 39,
        stem: "丁",
        branch: "未",
        stemTenGod: "傷官",
        branchTenGod: "正財",
        isCurrent: false,
        isSelected: false,
        relations: [
            { relationType: "害", target: "本命", description: "需留意人際節奏與合作邊界。" },
        ],
        themes: [
            { key: "career", label: "事業", readingStatus: "locked" },
            { key: "relationship", label: "情感", readingStatus: "locked" },
            { key: "wealth", label: "財局", readingStatus: "locked" },
            { key: "health", label: "康健", readingStatus: "locked" },
            { key: "timing", label: "時運", readingStatus: "locked" },
        ],
    },
];

export const baziReadyChartFixture: BaziChart = {
    id: "chart-fixture-ready",
    profileId: "fixture-chen",
    chartVersion: "chart-v1-fixture-ready",
    ruleVersion: BAZI_RULE_VERSION,
    timezone: BAZI_TIMEZONE,
    standardTimeUsed: true,
    trueSolarTimeEnabled: false,
    calculatedAt: baseCalculatedAt,
    status: "ready",
    missingFields: [],
    fourPillars: baseFourPillars,
    dayMasterSummary: {
        stem: "甲",
        yinYang: "yang",
        element: "wood",
        title: "陽木日主",
        strengthScore: 78,
        strengthLabel: "偏強",
        summary: "命局以木土成勢，日主根氣穩，宜先以疏土通關、再談火氣引動，適合在主動布局中打開新節點。",
        pattern: "木土相持",
        usefulGods: ["火", "金"],
        favorableGods: ["火", "土"],
        unfavorableGods: ["水過旺"],
    },
    elementBalance: baseElementBalance,
    luckCycle: baseLuckCycle,
    annuals: baseAnnuals,
};

export const baziMissingFieldChartFixture: BaziChart = {
    id: "chart-fixture-missing",
    profileId: "fixture-missing",
    chartVersion: "chart-v1-fixture-missing",
    ruleVersion: BAZI_RULE_VERSION,
    timezone: BAZI_TIMEZONE,
    standardTimeUsed: true,
    trueSolarTimeEnabled: false,
    calculatedAt: baseCalculatedAt,
    status: "missing_required_fields",
    missingFields: ["gender", "birthDate", "birthTimeLabel"],
};

export const baziCalculatingChartFixture: BaziChart = {
    id: "chart-fixture-calculating",
    profileId: "fixture-lin",
    chartVersion: "chart-v1-fixture-calculating",
    ruleVersion: BAZI_RULE_VERSION,
    timezone: BAZI_TIMEZONE,
    standardTimeUsed: true,
    trueSolarTimeEnabled: false,
    calculatedAt: baseCalculatedAt,
    status: "calculating",
    missingFields: [],
};

export const baziFixtureReadingContext: BaziReadingContextSnapshot = {
    id: "snapshot-fixture-2026-career",
    userId: "user-fixture-001",
    profileId: "fixture-chen",
    chartId: "chart-fixture-ready",
    chartVersion: "chart-v1-fixture-ready",
    ruleVersion: BAZI_RULE_VERSION,
    system: "bazi",
    mode: "annual",
    selectedLuckPillarId: "luck-4",
    selectedAnnualYear: 2026,
    questionTopic: "career",
    finalQuestion: "如果只先處理一個年度突破口，2026 年我應該先押哪個方向？",
    modelVersion: "gpt-reading-v1",
    promptVersion: "bazi-reading-prompt-v1",
    createdAt: baseCalculatedAt,
};

export const baziFixtureReadingRecord: BaziReadingRecord = {
    id: "reading-2026-career",
    profileId: "fixture-chen",
    contextSnapshotId: "snapshot-fixture-2026-career",
    status: "available",
    title: "2026 年事業切面解讀",
    summary: "今年重點不在全面鋪開，而在先確立一條可持續放大的主線。",
    content:
        "命盤摘要會依實際排盤資料整理；付費深度解讀會再結合問題、大運與流年。",
    tokenCost: 20,
    createdAt: baseCalculatedAt,
    updatedAt: baseCalculatedAt,
};

export function getBaziChartFixture(status: BaziChartStatus = "ready"): BaziChart {
    switch (status) {
        case "missing_required_fields":
            return baziMissingFieldChartFixture;
        case "calculating":
            return baziCalculatingChartFixture;
        case "calculation_failed":
            return {
                ...baziCalculatingChartFixture,
                id: "chart-fixture-error",
                chartVersion: "chart-v1-fixture-error",
                status: "calculation_failed",
            };
        case "ready":
        default:
            return baziReadyChartFixture;
    }
}

export function buildBaziWorkspaceFixture({
    profileId = baziFixtureProfiles[0]?.id,
    mode = "natal",
    chartStatus = "ready",
}: {
    profileId?: string;
    mode?: BaziTimeMode;
    chartStatus?: BaziChartStatus;
} = {}): BaziWorkspaceData {
    const chart = getBaziChartFixture(chartStatus);
    const selectedLuckPillarId = chart.luckCycle?.pillars.find((pillar) => pillar.isCurrent)?.id;
    const selectedAnnualYear = chart.annuals?.find((annual) => annual.isSelected)?.year;

    return {
        profileId,
        mode,
        chart: profileId ? { ...chart, profileId } : null,
        availableProfiles: baziFixtureProfiles,
        selectedLuckPillarId,
        selectedAnnualYear,
    };
}
