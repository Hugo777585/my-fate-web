import { LunarYear, Solar } from "lunar-javascript";

import type {
    BaziDayMasterSummary,
    BaziElement,
    BaziElementBalance,
    BaziFourPillars,
    BaziLuckCycle,
    BaziLuckPillar,
    BaziAnnualItem,
    BaziPillar,
    BaziPillarKey,
    BuildBaziChartInput,
} from "@/lib/bazi-fixture";

const stemElementMap: Record<string, BaziElement> = {
    甲: "wood",
    乙: "wood",
    丙: "fire",
    丁: "fire",
    戊: "earth",
    己: "earth",
    庚: "metal",
    辛: "metal",
    壬: "water",
    癸: "water",
};

const yangStems = new Set(["甲", "丙", "戊", "庚", "壬"]);
const branchMainStemMap: Record<string, string> = {
    子: "癸",
    丑: "己",
    寅: "甲",
    卯: "乙",
    辰: "戊",
    巳: "丙",
    午: "丁",
    未: "己",
    申: "庚",
    酉: "辛",
    戌: "戊",
    亥: "壬",
};
const generateElementMap: Record<BaziElement, BaziElement> = {
    wood: "fire",
    fire: "earth",
    earth: "metal",
    metal: "water",
    water: "wood",
};
const controlElementMap: Record<BaziElement, BaziElement> = {
    wood: "earth",
    earth: "water",
    water: "fire",
    fire: "metal",
    metal: "wood",
};
const resourceElementMap: Record<BaziElement, BaziElement> = {
    wood: "water",
    fire: "wood",
    earth: "fire",
    metal: "earth",
    water: "metal",
};
const officerElementMap: Record<BaziElement, BaziElement> = {
    wood: "metal",
    fire: "water",
    earth: "wood",
    metal: "fire",
    water: "earth",
};
const seasonElementMap: Record<string, BaziElement> = {
    寅: "wood",
    卯: "wood",
    辰: "wood",
    巳: "fire",
    午: "fire",
    未: "fire",
    申: "metal",
    酉: "metal",
    戌: "metal",
    亥: "water",
    子: "water",
    丑: "water",
};
const patternLabelMap: Record<string, string> = {
    比肩: "建祿格",
    劫財: "月劫格",
    食神: "食神格",
    傷官: "傷官格",
    偏財: "偏財格",
    正財: "正財格",
    七殺: "七殺格",
    正官: "正官格",
    偏印: "偏印格",
    正印: "印綬格",
};

const elementLabelMap: Record<BaziElement, string> = {
    wood: "木",
    fire: "火",
    earth: "土",
    metal: "金",
    water: "水",
};
const elementStrengthLabels = ["極弱", "偏弱", "中和", "偏強", "極強"] as const;
function parseBirthDate(value: string) {
    const parts = value.split("-").map((item) => Number(item));
    const [year, month, day] = parts;

    if (!year || !month || !day) {
        throw new Error("Invalid birthDate");
    }

    return { year, month, day };
}

function parseBirthTimeLabel(value: string) {
    const match = value.match(/(\d{2}):(\d{2})-(\d{2}):(\d{2})/);

    if (!match) {
        throw new Error("Invalid birthTimeLabel");
    }

    const hour = Number(match[1]);
    const minute = Number(match[2]);

    if (Number.isNaN(hour) || Number.isNaN(minute)) {
        throw new Error("Invalid birthTimeLabel");
    }

    return { hour, minute };
}

function splitGanZhi(value: string) {
    const chars = Array.from(value);
    const stem = chars[0] ?? "";
    const branch = chars[1] ?? "";
    return { stem, branch };
}

function buildPillar(
    key: BaziPillarKey,
    value: string,
    getStemTenGod: () => string,
    getHiddenStems: () => string[],
    getHiddenStemTenGods: () => string[],
    getGrowthStage: () => string,
    getNaYin: () => string,
    getVoidBranches: () => string,
): BaziPillar {
    const { stem, branch } = splitGanZhi(value);
    const hiddenStems = getHiddenStems();
    const hiddenStemTenGods = getHiddenStemTenGods();

    return {
        key,
        stem,
        branch,
        stemTenGod: key === "day" ? "日主" : getStemTenGod(),
        hiddenStems: hiddenStems.map((hiddenStem, index) => ({
            stem: hiddenStem,
            tenGod: hiddenStemTenGods[index] ?? "",
        })),
        hiddenStemTenGods,
        growthStage: getGrowthStage(),
        nayin: getNaYin(),
        shensha: [],
        voidBranches: Array.from(getVoidBranches()),
    };
}

export function buildFourPillarsFromInput(input: BuildBaziChartInput): BaziFourPillars {
    const { year, month, day } = parseBirthDate(input.birthDate);
    const { hour, minute } = parseBirthTimeLabel(input.birthTimeLabel);
    const solar = Solar.fromYmdHms(year, month, day, hour, minute, 0);
    const eightChar = solar.getLunar().getEightChar();

    eightChar.setSect(1);

    return {
        year: buildPillar(
            "year",
            eightChar.getYear(),
            () => eightChar.getYearShiShenGan(),
            () => eightChar.getYearHideGan(),
            () => eightChar.getYearShiShenZhi(),
            () => eightChar.getYearDiShi(),
            () => eightChar.getYearNaYin(),
            () => eightChar.getYearXunKong(),
        ),
        month: buildPillar(
            "month",
            eightChar.getMonth(),
            () => eightChar.getMonthShiShenGan(),
            () => eightChar.getMonthHideGan(),
            () => eightChar.getMonthShiShenZhi(),
            () => eightChar.getMonthDiShi(),
            () => eightChar.getMonthNaYin(),
            () => eightChar.getMonthXunKong(),
        ),
        day: buildPillar(
            "day",
            eightChar.getDay(),
            () => eightChar.getDayShiShenGan(),
            () => eightChar.getDayHideGan(),
            () => eightChar.getDayShiShenZhi(),
            () => eightChar.getDayDiShi(),
            () => eightChar.getDayNaYin(),
            () => eightChar.getDayXunKong(),
        ),
        hour: buildPillar(
            "hour",
            eightChar.getTime(),
            () => eightChar.getTimeShiShenGan(),
            () => eightChar.getTimeHideGan(),
            () => eightChar.getTimeShiShenZhi(),
            () => eightChar.getTimeDiShi(),
            () => eightChar.getTimeNaYin(),
            () => eightChar.getTimeXunKong(),
        ),
    };
}

function calculateTenGod(dayStem: string, otherStem: string) {
    const dayElement = stemElementMap[dayStem];
    const otherElement = stemElementMap[otherStem];

    if (!dayElement || !otherElement) {
        return "待計算";
    }

    const samePolarity = yangStems.has(dayStem) === yangStems.has(otherStem);

    if (otherElement === dayElement) {
        return samePolarity ? "比肩" : "劫財";
    }

    if (otherElement === generateElementMap[dayElement]) {
        return samePolarity ? "食神" : "傷官";
    }

    if (otherElement === controlElementMap[dayElement]) {
        return samePolarity ? "偏財" : "正財";
    }

    if (controlElementMap[otherElement] === dayElement) {
        return samePolarity ? "七殺" : "正官";
    }

    if (generateElementMap[otherElement] === dayElement) {
        return samePolarity ? "偏印" : "正印";
    }

    return "待計算";
}

function getCurrentYear() {
    return new Date().getFullYear();
}

function buildStartOffsetLabel(startYear: number, startMonth: number, startDay: number, startHour: number) {
    const segments: string[] = [];

    if (startYear > 0) {
        segments.push(`${startYear} 年`);
    }

    if (startMonth > 0) {
        segments.push(`${startMonth} 個月`);
    }

    if (startDay > 0) {
        segments.push(`${startDay} 天`);
    }

    if (startHour > 0) {
        segments.push(`${startHour} 小時`);
    }

    return segments.length > 0 ? segments.join(" ") : "出生後即起運";
}

function padDateTimeUnit(value: number) {
    return String(value).padStart(2, "0");
}

function buildStartDateTimeLabel(
    birthDate: string,
    birthTimeLabel: string,
    startYear: number,
    startMonth: number,
    startDay: number,
    startHour: number,
) {
    const { year, month, day } = parseBirthDate(birthDate);
    const { hour, minute } = parseBirthTimeLabel(birthTimeLabel);
    const startDate = new Date(year, month - 1, day, hour, minute, 0, 0);

    startDate.setFullYear(startDate.getFullYear() + startYear);
    startDate.setMonth(startDate.getMonth() + startMonth);
    startDate.setDate(startDate.getDate() + startDay);
    startDate.setHours(startDate.getHours() + startHour);

    return `${startDate.getFullYear()}-${padDateTimeUnit(startDate.getMonth() + 1)}-${padDateTimeUnit(startDate.getDate())} ${padDateTimeUnit(startDate.getHours())}:${padDateTimeUnit(startDate.getMinutes())}`;
}

function createEmptyElementScores(): Record<BaziElement, number> {
    return {
        wood: 0,
        fire: 0,
        earth: 0,
        metal: 0,
        water: 0,
    };
}

function toStrengthLabel(score: number) {
    if (score < 12) {
        return elementStrengthLabels[0];
    }

    if (score < 18) {
        return elementStrengthLabels[1];
    }

    if (score < 24) {
        return elementStrengthLabels[2];
    }

    if (score < 30) {
        return elementStrengthLabels[3];
    }

    return elementStrengthLabels[4];
}

function getElementByScoreLabel(score: number) {
    if (score < 8) {
        return elementStrengthLabels[0];
    }

    if (score < 14) {
        return elementStrengthLabels[1];
    }

    if (score < 22) {
        return elementStrengthLabels[2];
    }

    if (score < 30) {
        return elementStrengthLabels[3];
    }

    return elementStrengthLabels[4];
}

function uniqueElements(elements: BaziElement[]) {
    return Array.from(new Set(elements));
}

function isStrongStrengthLabel(strengthLabel: BaziDayMasterSummary["strengthLabel"]) {
    return strengthLabel === "偏強" || strengthLabel === "極強";
}

function isWeakStrengthLabel(strengthLabel: BaziDayMasterSummary["strengthLabel"]) {
    return strengthLabel === "偏弱" || strengthLabel === "極弱";
}

function getSeasonBonus(dayElement: BaziElement, monthBranch: string) {
    const seasonElement = seasonElementMap[monthBranch];

    if (!seasonElement) {
        return 0;
    }

    if (dayElement === seasonElement) {
        return 10;
    }

    if (dayElement === generateElementMap[seasonElement]) {
        return 6;
    }

    if (dayElement === resourceElementMap[seasonElement]) {
        return 3;
    }

    if (dayElement === controlElementMap[seasonElement]) {
        return -4;
    }

    if (dayElement === officerElementMap[seasonElement]) {
        return -8;
    }

    return 0;
}

function getRelationWeight(
    dayElement: BaziElement,
    targetElement: BaziElement,
    weight: number,
    bucket: { support: number; drain: number },
) {
    if (targetElement === dayElement) {
        bucket.support += weight;
        return;
    }

    if (targetElement === resourceElementMap[dayElement]) {
        bucket.support += weight * 0.85;
        return;
    }

    if (targetElement === generateElementMap[dayElement]) {
        bucket.drain += weight * 0.7;
        return;
    }

    if (targetElement === controlElementMap[dayElement]) {
        bucket.drain += weight * 0.9;
        return;
    }

    if (targetElement === officerElementMap[dayElement]) {
        bucket.drain += weight * 1.05;
    }
}

function calculateBodyStrengthScore(fourPillars: BaziFourPillars, dayElement: BaziElement) {
    const bucket = { support: 0, drain: 0 };
    const stemWeights: Record<BaziPillarKey, number> = {
        year: 6,
        month: 10,
        day: 8,
        hour: 6,
    };
    const hiddenStemWeights: Record<BaziPillarKey, number[]> = {
        year: [8, 4, 2],
        month: [12, 6, 3],
        day: [8, 4, 2],
        hour: [8, 4, 2],
    };

    for (const [key, pillar] of Object.entries(fourPillars) as [BaziPillarKey, BaziPillar][]) {
        const stemElement = stemElementMap[pillar.stem];

        if (stemElement) {
            getRelationWeight(dayElement, stemElement, stemWeights[key], bucket);
        }

        pillar.hiddenStems.forEach((hiddenStem, index) => {
            const hiddenElement = stemElementMap[hiddenStem.stem];
            const hiddenWeight = hiddenStemWeights[key][index] ?? 2;

            if (hiddenElement) {
                getRelationWeight(dayElement, hiddenElement, hiddenWeight, bucket);
            }
        });
    }

    const monthBranchMainStem = branchMainStemMap[fourPillars.month.branch];
    const monthBranchElement = monthBranchMainStem ? stemElementMap[monthBranchMainStem] : undefined;

    if (monthBranchElement) {
        getRelationWeight(dayElement, monthBranchElement, 8, bucket);
    }

    const rawScore =
        20 +
        bucket.support +
        getSeasonBonus(dayElement, fourPillars.month.branch) -
        bucket.drain;

    return Math.max(0, Math.round(rawScore / 2.2));
}

function getPatternTenGod(fourPillars: BaziFourPillars) {
    const dayStem = fourPillars.day.stem;
    const monthBranchMainStem = branchMainStemMap[fourPillars.month.branch];
    const monthBranchTenGod = monthBranchMainStem ? calculateTenGod(dayStem, monthBranchMainStem) : "待計算";

    if (monthBranchTenGod !== "待計算") {
        return monthBranchTenGod;
    }

    return fourPillars.month.stemTenGod;
}

function getPatternLabel(patternTenGod: string) {
    return patternLabelMap[patternTenGod] ?? `${patternTenGod}格`;
}

function getBodyStrengthPattern(strengthLabel: BaziDayMasterSummary["strengthLabel"]) {
    if (isStrongStrengthLabel(strengthLabel)) {
        return "身強";
    }

    if (isWeakStrengthLabel(strengthLabel)) {
        return "身弱";
    }

    return "中和";
}

function getPatternUsefulElements(
    dayElement: BaziElement,
    strengthLabel: BaziDayMasterSummary["strengthLabel"],
    patternTenGod: string,
) {
    const resource = resourceElementMap[dayElement];
    const output = generateElementMap[dayElement];
    const wealth = controlElementMap[dayElement];
    const officer = officerElementMap[dayElement];

    if (isWeakStrengthLabel(strengthLabel)) {
        return uniqueElements([dayElement, resource]);
    }

    if (isStrongStrengthLabel(strengthLabel)) {
        switch (patternTenGod) {
            case "正官":
            case "偏財":
            case "正財":
                return uniqueElements([wealth, officer, output]);
            case "七殺":
                return uniqueElements([output, wealth, officer]);
            case "正印":
            case "偏印":
                return uniqueElements([wealth, output]);
            case "食神":
            case "傷官":
                return uniqueElements([wealth, officer]);
            case "比肩":
            case "劫財":
            default:
                return uniqueElements([output, wealth, officer]);
        }
    }

    switch (patternTenGod) {
        case "正官":
        case "偏財":
        case "正財":
            return uniqueElements([wealth, officer]);
        case "七殺":
            return uniqueElements([output, resource]);
        case "正印":
        case "偏印":
            return uniqueElements([output, wealth]);
        case "食神":
        case "傷官":
            return uniqueElements([wealth, officer]);
        case "比肩":
        case "劫財":
            return uniqueElements([output, wealth]);
        default:
            return uniqueElements([output, resource]);
    }
}

function getPatternUnfavorableElements(
    dayElement: BaziElement,
    strengthLabel: BaziDayMasterSummary["strengthLabel"],
    usefulElements: BaziElement[],
) {
    const resource = resourceElementMap[dayElement];
    const output = generateElementMap[dayElement];
    const wealth = controlElementMap[dayElement];
    const officer = officerElementMap[dayElement];

    if (isWeakStrengthLabel(strengthLabel)) {
        return uniqueElements([output, wealth, officer].filter((element) => !usefulElements.includes(element)));
    }

    if (isStrongStrengthLabel(strengthLabel)) {
        return uniqueElements([dayElement, resource].filter((element) => !usefulElements.includes(element)));
    }

    return uniqueElements([dayElement, resource, output, wealth, officer].filter((element) => !usefulElements.includes(element)));
}

export function buildElementBalanceFromFourPillars(fourPillars: BaziFourPillars): BaziElementBalance {
    const scores = createEmptyElementScores();
    const pillars = Object.values(fourPillars);

    for (const pillar of pillars) {
        const stemElement = stemElementMap[pillar.stem];

        if (stemElement) {
            scores[stemElement] += 12;
        }

        for (const hiddenStem of pillar.hiddenStems) {
            const hiddenElement = stemElementMap[hiddenStem.stem];

            if (hiddenElement) {
                scores[hiddenElement] += 4;
            }
        }
    }

    const total = Object.values(scores).reduce((sum, value) => sum + value, 0) || 1;

    return {
        wood: {
            element: "wood",
            score: scores.wood,
            percentage: Math.round((scores.wood / total) * 100),
            label: getElementByScoreLabel(scores.wood),
        },
        fire: {
            element: "fire",
            score: scores.fire,
            percentage: Math.round((scores.fire / total) * 100),
            label: getElementByScoreLabel(scores.fire),
        },
        earth: {
            element: "earth",
            score: scores.earth,
            percentage: Math.round((scores.earth / total) * 100),
            label: getElementByScoreLabel(scores.earth),
        },
        metal: {
            element: "metal",
            score: scores.metal,
            percentage: Math.round((scores.metal / total) * 100),
            label: getElementByScoreLabel(scores.metal),
        },
        water: {
            element: "water",
            score: scores.water,
            percentage: Math.round((scores.water / total) * 100),
            label: getElementByScoreLabel(scores.water),
        },
    };
}

export function buildLuckCycleFromInput(
    input: BuildBaziChartInput,
    options: { year?: number } = {},
): BaziLuckCycle {
    const { year, month, day } = parseBirthDate(input.birthDate);
    const { hour, minute } = parseBirthTimeLabel(input.birthTimeLabel);
    const solar = Solar.fromYmdHms(year, month, day, hour, minute, 0);
    const eightChar = solar.getLunar().getEightChar();

    eightChar.setSect(1);

    const yun = eightChar.getYun(input.gender);
    const dayuns = yun.getDaYun(9);
    const pillars: BaziLuckPillar[] = [];
    const nowYear = options.year ?? getCurrentYear();
    const dayStem = eightChar.getDayGan();
    const startYearOffset = yun.getStartYear();
    const startMonthOffset = yun.getStartMonth();
    const startDayOffset = yun.getStartDay();
    const startHourOffset = yun.getStartHour();

    for (let index = 1; index <= 8; index += 1) {
        const dayun = dayuns[index];

        if (!dayun) {
            continue;
        }

        const ganZhi = dayun.getGanZhi();
        const { stem, branch } = splitGanZhi(ganZhi);
        const branchMainStem = branchMainStemMap[branch];
        const stemTenGod = calculateTenGod(dayStem, stem);
        const branchTenGod = branchMainStem ? calculateTenGod(dayStem, branchMainStem) : "待計算";

        pillars.push({
            id: `${input.profileId}-dayun-${index}`,
            order: index,
            startAge: dayun.getStartAge(),
            endAge: dayun.getEndAge(),
            startYear: dayun.getStartYear(),
            endYear: dayun.getEndYear(),
            stem,
            branch,
            stemTenGod,
            branchTenGod,
            growthStage: "待計算",
            isCurrent: dayun.getStartYear() <= nowYear && nowYear <= dayun.getEndYear(),
            readingStatus: "locked",
        });
    }

    const firstPillar = pillars[0];

    return {
        direction: yun.isForward() ? "forward" : "backward",
        startAge: firstPillar?.startAge ?? yun.getStartYear(),
        startYear: firstPillar?.startYear ?? year + yun.getStartYear(),
        startMonth: startMonthOffset,
        startDay: startDayOffset,
        startHour: startHourOffset,
        startOffsetLabel: buildStartOffsetLabel(
            startYearOffset,
            startMonthOffset,
            startDayOffset,
            startHourOffset,
        ),
        startDateTimeLabel: buildStartDateTimeLabel(
            input.birthDate,
            input.birthTimeLabel,
            startYearOffset,
            startMonthOffset,
            startDayOffset,
            startHourOffset,
        ),
        calculationBasis: "三日一歲 / 一日四個月 / 一小時五天",
        pillars,
    };
}

export function buildAnnualsFromInput(
    input: BuildBaziChartInput,
    luckCycle: BaziLuckCycle,
    template: Pick<BaziAnnualItem, "themes" | "relations"> | null,
    options: { year?: number; count?: number } = {},
): BaziAnnualItem[] {
    const { year: birthYear } = parseBirthDate(input.birthDate);
    const nowYear = options.year ?? getCurrentYear();
    const count = options.count ?? 12;
    const { year, month, day } = parseBirthDate(input.birthDate);
    const { hour, minute } = parseBirthTimeLabel(input.birthTimeLabel);
    const dayStem = Solar.fromYmdHms(year, month, day, hour, minute, 0).getLunar().getEightChar().getDayGan();

    const currentPillar = luckCycle.pillars.find((pillar) => pillar.isCurrent);
    const baseStartYear = currentPillar?.startYear ?? nowYear - 2;
    const minYear = Math.max(baseStartYear, nowYear - 2);
    const years = Array.from({ length: count }, (_, index) => minYear + index);

    return years.map((annualYear) => {
        const ganZhi = LunarYear.fromYear(annualYear).getGanZhi();
        const { stem, branch } = splitGanZhi(ganZhi);
        const branchMainStem = branchMainStemMap[branch];
        const stemTenGod = calculateTenGod(dayStem, stem);
        const branchTenGod = branchMainStem ? calculateTenGod(dayStem, branchMainStem) : "待計算";
        const relations = template?.relations ?? [];
        const themes = template?.themes ?? [];

        return {
            year: annualYear,
            age: Math.max(0, annualYear - birthYear + 1),
            stem,
            branch,
            stemTenGod,
            branchTenGod,
            isCurrent: annualYear === nowYear,
            isSelected: annualYear === nowYear,
            relations,
            themes,
        };
    });
}

export function buildDayMasterSummaryFromFourPillars(
    fourPillars: BaziFourPillars,
    elementBalance: BaziElementBalance,
): BaziDayMasterSummary {
    const stem = fourPillars.day.stem;
    const yinYang = yangStems.has(stem) ? "yang" : "yin";
    const element = stemElementMap[stem] ?? "earth";
    const title = `${stem}${elementLabelMap[element]}日主`;
    const strengthScore = calculateBodyStrengthScore(fourPillars, element);
    const strengthLabel = toStrengthLabel(strengthScore);
    const patternTenGod = getPatternTenGod(fourPillars);
    const pattern = getPatternLabel(patternTenGod);
    const bodyStrengthPattern = getBodyStrengthPattern(strengthLabel);
    const usefulElements = getPatternUsefulElements(element, strengthLabel, patternTenGod);
    const unfavorableElements = getPatternUnfavorableElements(element, strengthLabel, usefulElements);
    const favorableGods = usefulElements.map((item) => elementLabelMap[item]);
    const unfavorableGods = unfavorableElements.map((item) => elementLabelMap[item]);
    const usefulGods = favorableGods;
    const monthBranchMainStem = branchMainStemMap[fourPillars.month.branch];
    const patternBasis = monthBranchMainStem ? `${fourPillars.month.branch}月令主氣 ${monthBranchMainStem}` : `${fourPillars.month.branch}月令`;
    const strongestElement = Object.values(elementBalance).sort((left, right) => right.score - left.score)[0];
    const strongestElementLabel = strongestElement ? elementLabelMap[strongestElement.element] : "未定";
    const summary = `${title}定為${pattern}，命局屬${bodyStrengthPattern}${strengthLabel}。以${patternBasis}為格局判斷基準，目前${strongestElementLabel}勢較明顯，取${favorableGods.join("、")}為用，${unfavorableGods.join("、")}需節制。`;

    return {
        stem,
        yinYang,
        element,
        title,
        strengthScore,
        strengthLabel,
        summary,
        pattern,
        usefulGods,
        favorableGods,
        unfavorableGods,
    };
}
