export type BirthTimeCode =
    | "zi"
    | "chou"
    | "yin"
    | "mao"
    | "chen"
    | "si"
    | "wu"
    | "wei"
    | "shen"
    | "you"
    | "xu"
    | "hai";

export type BirthTimeStartTime = {
    hour: number;
    minute: number;
};

export type BirthTimeEntry = {
    code: BirthTimeCode;
    branch: string;
    standardLabel: string;
    startTime: BirthTimeStartTime;
    branchIndex: number;
    legacyLabels: readonly string[];
};

const rawBirthTimeEntries = [
    {
        code: "zi",
        branch: "子",
        standardLabel: "子時（23:00–01:00）",
        startTime: { hour: 23, minute: 0 },
        branchIndex: 0,
        legacyLabels: ["子時 23:00-01:00", "子时 23:00-01:00"],
    },
    {
        code: "chou",
        branch: "丑",
        standardLabel: "丑時（01:00–03:00）",
        startTime: { hour: 1, minute: 0 },
        branchIndex: 1,
        legacyLabels: ["丑時 01:00-03:00", "丑时 01:00-03:00"],
    },
    {
        code: "yin",
        branch: "寅",
        standardLabel: "寅時（03:00–05:00）",
        startTime: { hour: 3, minute: 0 },
        branchIndex: 2,
        legacyLabels: ["寅時 03:00-05:00", "寅时 03:00-05:00"],
    },
    {
        code: "mao",
        branch: "卯",
        standardLabel: "卯時（05:00–07:00）",
        startTime: { hour: 5, minute: 0 },
        branchIndex: 3,
        legacyLabels: ["卯時 05:00-07:00", "卯时 05:00-07:00"],
    },
    {
        code: "chen",
        branch: "辰",
        standardLabel: "辰時（07:00–09:00）",
        startTime: { hour: 7, minute: 0 },
        branchIndex: 4,
        legacyLabels: ["辰時 07:00-09:00", "辰时 07:00-09:00"],
    },
    {
        code: "si",
        branch: "巳",
        standardLabel: "巳時（09:00–11:00）",
        startTime: { hour: 9, minute: 0 },
        branchIndex: 5,
        legacyLabels: ["巳時 09:00-11:00", "巳时 09:00-11:00"],
    },
    {
        code: "wu",
        branch: "午",
        standardLabel: "午時（11:00–13:00）",
        startTime: { hour: 11, minute: 0 },
        branchIndex: 6,
        legacyLabels: ["午時 11:00-13:00", "午时 11:00-13:00"],
    },
    {
        code: "wei",
        branch: "未",
        standardLabel: "未時（13:00–15:00）",
        startTime: { hour: 13, minute: 0 },
        branchIndex: 7,
        legacyLabels: ["未時 13:00-15:00", "未时 13:00-15:00"],
    },
    {
        code: "shen",
        branch: "申",
        standardLabel: "申時（15:00–17:00）",
        startTime: { hour: 15, minute: 0 },
        branchIndex: 8,
        legacyLabels: ["申時 15:00-17:00", "申时 15:00-17:00"],
    },
    {
        code: "you",
        branch: "酉",
        standardLabel: "酉時（17:00–19:00）",
        startTime: { hour: 17, minute: 0 },
        branchIndex: 9,
        legacyLabels: ["酉時 17:00-19:00", "酉时 17:00-19:00"],
    },
    {
        code: "xu",
        branch: "戌",
        standardLabel: "戌時（19:00–21:00）",
        startTime: { hour: 19, minute: 0 },
        branchIndex: 10,
        legacyLabels: ["戌時 19:00-21:00", "戌时 19:00-21:00"],
    },
    {
        code: "hai",
        branch: "亥",
        standardLabel: "亥時（21:00–23:00）",
        startTime: { hour: 21, minute: 0 },
        branchIndex: 11,
        legacyLabels: ["亥時 21:00-23:00", "亥时 21:00-23:00"],
    },
] as const satisfies readonly BirthTimeEntry[];

export const birthTimeEntries: readonly BirthTimeEntry[] = rawBirthTimeEntries;

const birthTimeCodeMap = new Map<BirthTimeCode, BirthTimeEntry>(
    birthTimeEntries.map((entry) => [entry.code, entry]),
);

const legacyBirthTimeLabelMap = new Map<string, BirthTimeCode>();

for (const entry of birthTimeEntries) {
    legacyBirthTimeLabelMap.set(normalizeLegacyBirthTimeLabel(entry.standardLabel), entry.code);
    legacyBirthTimeLabelMap.set(
        normalizeLegacyBirthTimeLabel(entry.standardLabel.replace("時", "时")),
        entry.code,
    );

    for (const legacyLabel of entry.legacyLabels) {
        legacyBirthTimeLabelMap.set(normalizeLegacyBirthTimeLabel(legacyLabel), entry.code);
    }
}

function normalizeLegacyBirthTimeLabel(value: string) {
    return value.trim().replace(/\s+/g, " ");
}

export function isBirthTimeCode(value: string): value is BirthTimeCode {
    return birthTimeCodeMap.has(value as BirthTimeCode);
}

export function birthTimeCodeToLabel(code: BirthTimeCode): string | null {
    return birthTimeCodeMap.get(code)?.standardLabel ?? null;
}

export function legacyBirthTimeLabelToCode(label: string): BirthTimeCode | null {
    const normalized = normalizeLegacyBirthTimeLabel(label);

    if (!normalized) {
        return null;
    }

    return legacyBirthTimeLabelMap.get(normalized) ?? null;
}

export function birthTimeCodeToStartTime(code: BirthTimeCode): BirthTimeStartTime | null {
    const startTime = birthTimeCodeMap.get(code)?.startTime;

    if (!startTime) {
        return null;
    }

    return {
        hour: startTime.hour,
        minute: startTime.minute,
    };
}

export function birthTimeCodeToBranchIndex(code: BirthTimeCode): number | null {
    return birthTimeCodeMap.get(code)?.branchIndex ?? null;
}
