import { isEcpayConfigured } from "@/lib/ecpay";
import { createClient } from "@/lib/supabase/server";

export const walletPackages = [
    { code: "starter", name: "小型包", amount: 300, points: 10, bonus: 0, featured: false },
    { code: "entry", name: "入門包", amount: 600, points: 20, bonus: 10, featured: false },
    { code: "advanced", name: "進階包", amount: 1800, points: 60, bonus: 40, featured: true },
    { code: "professional", name: "專業包", amount: 4800, points: 160, bonus: 125, featured: false },
] as const;

export type WalletTransaction = {
    id: string;
    entryType: string;
    delta: number;
    balanceAfter: number;
    reason: string;
    createdAt: string;
};

export type WalletLot = {
    id: string;
    category: string;
    availablePoints: number;
    expiresAt: string | null;
    createdAt: string;
};

export type WalletData = {
    balance: number;
    reservedPoints: number;
    lifetimePurchased: number;
    lifetimeBonus: number;
    lots: WalletLot[];
    transactions: WalletTransaction[];
    ecpayConfigured: boolean;
};

export async function getWalletData(userId: string): Promise<WalletData> {
    const supabase = await createClient();
    const { error: ensureError } = await supabase.rpc("ensure_wallet");
    if (ensureError) {
        throw new Error(`初始化錢包失敗：${ensureError.message}`);
    }

    const [account, lots, transactions] = await Promise.all([
        supabase
            .from("wallet_accounts")
            .select("balance, reserved_points, lifetime_purchased, lifetime_bonus")
            .eq("user_id", userId)
            .single(),
        supabase
            .from("wallet_credit_lots")
            .select("id, category, available_points, expires_at, created_at")
            .eq("user_id", userId)
            .gt("available_points", 0)
            .order("expires_at", { ascending: true, nullsFirst: false })
            .limit(12),
        supabase
            .from("wallet_transactions")
            .select("id, entry_type, delta, balance_after, reason, created_at")
            .eq("user_id", userId)
            .order("created_at", { ascending: false })
            .limit(20),
    ]);

    if (account.error) throw new Error(`讀取錢包失敗：${account.error.message}`);
    if (lots.error) throw new Error(`讀取點數批次失敗：${lots.error.message}`);
    if (transactions.error) throw new Error(`讀取交易紀錄失敗：${transactions.error.message}`);

    return {
        balance: account.data.balance ?? 0,
        reservedPoints: account.data.reserved_points ?? 0,
        lifetimePurchased: account.data.lifetime_purchased ?? 0,
        lifetimeBonus: account.data.lifetime_bonus ?? 0,
        lots: (lots.data ?? []).map((row) => ({
            id: row.id,
            category: row.category,
            availablePoints: row.available_points,
            expiresAt: row.expires_at,
            createdAt: row.created_at,
        })),
        transactions: (transactions.data ?? []).map((row) => ({
            id: row.id,
            entryType: row.entry_type,
            delta: row.delta,
            balanceAfter: row.balance_after,
            reason: row.reason,
            createdAt: row.created_at,
        })),
        ecpayConfigured: isEcpayConfigured(),
    };
}
