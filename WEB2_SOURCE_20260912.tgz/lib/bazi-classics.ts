export type BaziClassicBook = "滴天髓" | "窮通寶鑑" | "三命通會";

export type BaziClassicTopic = "luck_and_annual" | "luck_cycle" | "annual" | "general";

export type BaziClassicExcerpt = {
    id: string;
    book: BaziClassicBook;
    topic: BaziClassicTopic;
    title: string;
    excerpt: string;
    paraphrase: string;
    sourceUrl: string;
    sourceLabel?: string;
    tags?: string[];
};

export const baziClassicExcerpts: BaziClassicExcerpt[] = [
    {
        id: "dts-001",
        book: "滴天髓",
        topic: "luck_and_annual",
        title: "歲運的主從與戰和",
        excerpt: "休囚系乎運，尤系乎歲，戰沖視孰降，和好視孰切。",
        paraphrase:
            "命局旺衰與通塞，會被大運帶動，而流年又會把吉凶放大成可感的事件。看歲運，不是只看某一字吉凶，而是要看歲運與命局之間的衝、合、戰、和，哪一方更有力、哪一方更貼近命局關鍵點。",
        sourceUrl: "http://www.360doc.com/content/22/0811/08/22129012_1043340934.shtml",
        sourceLabel: "《滴天髓》二十八·歲運",
        tags: ["歲運", "戰沖", "和好", "吉凶顯現"],
    },
    {
        id: "qtbj-001",
        book: "窮通寶鑑",
        topic: "general",
        title: "行運亦如之（以中道觀動態）",
        excerpt: "行運亦如之，識其微意，則於命理之說，思過半矣。",
        paraphrase:
            "命局分析講究折衷與中道；行運的判讀也是同一個精神。先把命局的偏與平抓住，再看歲運如何補偏、如何助長偏差，才能真正把握趨吉避凶的關鍵。",
        sourceUrl:
            "https://github.com/garychowcmu/daizhigev20/blob/master/%E6%98%93%E8%97%8F/%E6%9C%AF%E6%95%B0/%E7%A9%B7%E9%80%9A%E5%AE%9D%E9%89%B4.txt",
        sourceLabel: "《窮通寶鑑》五行總論",
        tags: ["中道", "折衷", "行運", "旺衰"],
    },
    {
        id: "smt-001",
        book: "三命通會",
        topic: "luck_and_annual",
        title: "流年看天元，大運看支神",
        excerpt: "看流年歲君，只用天元；若行運雖重地支，亦要看運天元。",
        paraphrase:
            "流年多主「當年事件與觸發點」，以天干為主線來取象；大運多主「十年舞台與環境」，以地支為主。但兩者都不能只看一半：流年仍需究支，行運仍要看干，才不會判斷失真。",
        sourceUrl: "http://ab.newdu.com/book/ms264475.html",
        sourceLabel: "《三命通會》卷十·看命口訣",
        tags: ["流年", "大運", "天元", "地支", "主次"],
    },
];

export function getBaziClassicsForTiming(): BaziClassicExcerpt[] {
    return baziClassicExcerpts.filter((item) => item.topic === "luck_and_annual" || item.topic === "luck_cycle" || item.topic === "annual");
}

