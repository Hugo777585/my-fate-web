import {
    buildBaziChartInputFromProfile,
    buildBaziWorkspaceFromProfile,
    buildBaziReadingBundle,
    getMissingBaziProfileFields,
    toAdapterProfile,
} from "@/lib/bazi-adapter";
import type { BaziChart, BaziTimeMode, BaziWorkspaceData, BuildBaziChartInput } from "@/lib/bazi-fixture";
import { getProfileById, listProfiles, type ProfileDetail, type ProfileSummary } from "@/lib/profiles";

export const baziWorkspaceModes = ["natal", "timing", "reading"] as const;

export type BaziWorkspaceMode = (typeof baziWorkspaceModes)[number];

export type BaziPageSearchParams = {
    profile?: string | string[] | undefined;
    mode?: string | string[] | undefined;
    annual?: string | string[] | undefined;
};

export type BaziPageData = {
    profiles: ProfileSummary[];
    selectedProfile: ProfileDetail | null;
    selectedProfileId?: string;
    activeMode: BaziWorkspaceMode;
    workspaceData: BaziWorkspaceData;
    chart: BaziChart | null;
    chartInput: BuildBaziChartInput | null;
    hasChartInput: boolean;
    missingFieldKeys: ReturnType<typeof getMissingBaziProfileFields>;
    readingBundle: ReturnType<typeof buildBaziReadingBundle> | null;
};

function getSingleSearchParam(value: string | string[] | undefined) {
    return Array.isArray(value) ? value[0] : value;
}

export function normalizeBaziWorkspaceMode(value: string | string[] | undefined): BaziWorkspaceMode {
    const mode = getSingleSearchParam(value);

    if (mode === "timing" || mode === "reading") {
        return mode;
    }

    return "natal";
}

export function toBaziTimeMode(mode: BaziWorkspaceMode): BaziTimeMode {
    if (mode === "timing") {
        return "luck_pillar";
    }

    if (mode === "reading") {
        return "annual";
    }

    return "natal";
}

export async function loadBaziPageData(
    userId: string,
    searchParams: BaziPageSearchParams,
): Promise<BaziPageData> {
    const profiles = await listProfiles(userId);
    const selectedProfileId = getSingleSearchParam(searchParams.profile);
    const activeMode = normalizeBaziWorkspaceMode(searchParams.mode);
    const selectedAnnualYearParam = getSingleSearchParam(searchParams.annual);
    const selectedAnnualYear = selectedAnnualYearParam ? Number(selectedAnnualYearParam) : undefined;
    const selectedProfile = selectedProfileId
        ? await getProfileById(userId, selectedProfileId)
        : null;
    const adapterProfiles = profiles.map((profile) => toAdapterProfile(profile));
    const selectedAdapterProfile = selectedProfile ? toAdapterProfile(selectedProfile) : null;
    const chartInput = selectedAdapterProfile ? buildBaziChartInputFromProfile(selectedAdapterProfile) : null;
    const workspaceData = await buildBaziWorkspaceFromProfile({
        profile: selectedAdapterProfile,
        profiles: adapterProfiles,
        mode: toBaziTimeMode(activeMode),
    });
    const chart = selectedProfile ? workspaceData.chart : null;
    const annuals = chart?.status === "ready" ? chart.annuals : undefined;
    const selectedAnnual = annuals?.find((annual) => annual.year === selectedAnnualYear)
        ?? annuals?.find((annual) => annual.isSelected)
        ?? annuals?.[0];
    const normalizedAnnuals = annuals?.map((annual) => ({
        ...annual,
        isSelected: annual.year === selectedAnnual?.year,
    }));
    const normalizedChart = chart?.status === "ready"
        ? {
              ...chart,
              annuals: normalizedAnnuals,
          }
        : chart;
    const readingBundle = normalizedChart?.status === "ready"
        ? buildBaziReadingBundle({
              chart: normalizedChart,
              profileId: selectedProfile?.id,
              mode: toBaziTimeMode(activeMode),
              annualYear: selectedAnnual?.year,
          })
        : null;

    return {
        profiles,
        selectedProfile,
        selectedProfileId,
        activeMode,
        workspaceData,
        chart: normalizedChart,
        chartInput,
        hasChartInput: Boolean(chartInput),
        missingFieldKeys: getMissingBaziProfileFields(selectedAdapterProfile),
        readingBundle,
    };
}
