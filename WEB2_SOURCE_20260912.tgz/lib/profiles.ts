import { createClient } from "@/lib/supabase/server";

export const profileTypeLabels = {
    self: "本人",
    family: "親友",
    client: "客戶",
} as const;

export type ProfileType = keyof typeof profileTypeLabels;

type ClientRow = {
    id: string;
    owner_id: string;
    name: string;
    gender: string | null;
    birth_date: string | null;
    birth_time_label: string;
    birth_place: string;
    notes: string;
    profile_type: ProfileType;
    created_at: string;
    updated_at: string;
};

export type ProfileSummary = {
    id: string;
    type: string;
    name: string;
    tag: string;
    gender: string;
    birthDate: string;
    birthTime: string;
    birthPlace: string;
    notes: string;
};

export type ProfileDetail = ProfileSummary & {
    ownerId: string;
    profileType: ProfileType;
    createdAt: string;
    updatedAt: string;
};

function mapProfile(row: ClientRow): ProfileDetail {
    return {
        id: row.id,
        ownerId: row.owner_id,
        profileType: row.profile_type,
        type: row.profile_type.toUpperCase(),
        tag: profileTypeLabels[row.profile_type],
        name: row.name,
        gender: row.gender?.trim() || "未填",
        birthDate: row.birth_date ?? "未填",
        birthTime: row.birth_time_label.trim() || "未填",
        birthPlace: row.birth_place.trim() || "未填",
        notes: row.notes.trim() || "尚未填寫備註。",
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}

export async function listProfiles(userId: string) {
    const supabase = await createClient();
    const { data, error } = await supabase
        .from("clients")
        .select("id, owner_id, name, gender, birth_date, birth_time_label, birth_place, notes, profile_type, created_at, updated_at")
        .eq("owner_id", userId)
        .order("created_at", {
            ascending: false,
        });

    if (error) {
        throw new Error(`讀取親友資料失敗：${error.message}`);
    }

    return ((data ?? []) as ClientRow[]).map(mapProfile);
}

export async function getProfileById(userId: string, profileId: string) {
    const supabase = await createClient();
    const { data, error } = await supabase
        .from("clients")
        .select("id, owner_id, name, gender, birth_date, birth_time_label, birth_place, notes, profile_type, created_at, updated_at")
        .eq("owner_id", userId)
        .eq("id", profileId)
        .maybeSingle();

    if (error) {
        throw new Error(`讀取單筆親友資料失敗：${error.message}`);
    }

    if (!data) {
        return null;
    }

    return mapProfile(data as ClientRow);
}
