import { cache } from "react";
import { redirect } from "next/navigation";

import { createClient } from "@/lib/supabase/server";

export const getCurrentUser = cache(async () => {
    const supabase = await createClient();
    const {
        data: { user },
    } = await supabase.auth.getUser();

    return user;
});

export async function requireUser() {
    const user = await getCurrentUser();

    if (!user) {
        redirect("/auth");
    }

    return user;
}

export type MemberRole = "owner" | "admin" | "member";

export const getCurrentRole = cache(async (): Promise<MemberRole> => {
    const user = await getCurrentUser();
    if (!user) return "member";

    const supabase = await createClient();
    const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .maybeSingle();

    if (error || !data?.role) return "member";
    return data.role === "owner" || data.role === "admin" ? data.role : "member";
});

export async function requireOwner() {
    const user = await requireUser();
    const role = await getCurrentRole();
    if (role !== "owner" && role !== "admin") {
        redirect("/dashboard");
    }
    return { user, role };
}
