import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export type EcpayFields = Record<string, string>;

export type EcpayConfig = Readonly<{
    merchantId: string;
    hashKey: string;
    hashIv: string;
    environment: "production";
    choosePayment: "Credit";
    returnUrl: string;
    clientBackUrl: string;
    orderResultUrl: string;
}>;

export type CheckoutOrder = {
    merchantTradeNo: string;
    environment: "production";
    amount: number;
    itemName: string;
    packageCode: string;
};

export type CallbackOrder = {
    merchantTradeNo: string;
    environment: "production";
    amount: number;
};

export const ECPAY_CHECKOUT_URL = "https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5";
const BLOCKED_SOURCE_HOST = "xuanjing-web2.dream53721.chatgpt.site";

export function ecpayUrlEncode(value: string) {
    return encodeURIComponent(value)
        .replace(/%20/g, "+")
        .replace(/~/g, "%7E")
        .replace(/'/g, "%27")
        .replace(/%2D/gi, "-")
        .replace(/%5F/gi, "_")
        .replace(/%2E/gi, ".")
        .replace(/%21/gi, "!")
        .replace(/%2A/gi, "*")
        .replace(/%28/gi, "(")
        .replace(/%29/gi, ")")
        .toLowerCase();
}

export function createCheckMacValue(parameters: EcpayFields, hashKey: string, hashIv: string) {
    const entries = Object.entries(parameters);
    if (entries.some(([key, value]) => !key || typeof value !== "string")) {
        throw new Error("Payment parameters must be strings");
    }

    const seen = new Set<string>();
    for (const [key] of entries) {
        const normalized = key.toLowerCase();
        if (seen.has(normalized)) throw new Error("Duplicate parameter");
        seen.add(normalized);
    }

    const payload = entries
        .filter(([key]) => key.toLowerCase() !== "checkmacvalue")
        .sort(([a], [b]) => a.toLowerCase().localeCompare(b.toLowerCase()))
        .map(([key, value]) => `${key}=${value}`)
        .join("&");

    return createHash("sha256")
        .update(ecpayUrlEncode(`HashKey=${hashKey}&${payload}&HashIV=${hashIv}`), "utf8")
        .digest("hex")
        .toUpperCase();
}

export function verifyCheckMacValue(parameters: EcpayFields, hashKey: string, hashIv: string) {
    const received = parameters.CheckMacValue;
    if (typeof received !== "string" || !/^[a-fA-F0-9]{64}$/.test(received)) return false;

    try {
        const expected = createCheckMacValue(parameters, hashKey, hashIv);
        return timingSafeEqual(Buffer.from(received.toUpperCase()), Buffer.from(expected));
    } catch {
        return false;
    }
}

export function parseNotification(body: string): EcpayFields {
    const result: EcpayFields = Object.create(null) as EcpayFields;
    const seen = new Set<string>();

    for (const [key, value] of new URLSearchParams(body)) {
        const normalized = key.toLowerCase();
        if (!key || seen.has(normalized)) throw new Error("Duplicate or empty parameter");
        seen.add(normalized);
        result[key] = value;
    }

    return result;
}

function checkedUrl(value: string, name: string) {
    const url = new URL(value);
    if (
        url.protocol !== "https:" ||
        url.username ||
        url.password ||
        url.hash ||
        value.length > 200 ||
        url.hostname === BLOCKED_SOURCE_HOST ||
        url.hostname.endsWith(".invalid")
    ) {
        throw new Error(`Invalid WEB2 URL: ${name}`);
    }
    return value;
}

export function getEcpayConfig(env: NodeJS.ProcessEnv = process.env): EcpayConfig {
    const required = (name: string) => {
        const value = env[name]?.trim();
        if (!value) throw new Error(`Missing server setting: ${name}`);
        return value;
    };

    if (required("ECPAY_ENV") !== "production" || required("ECPAY_TEST_MODE").toLowerCase() !== "false") {
        throw new Error("ECPay must run in production mode with test mode disabled");
    }

    const merchantId = required("ECPAY_MERCHANT_ID");
    if (merchantId !== "3502227") throw new Error("Unexpected ECPay merchant ID");

    const choosePayment = required("ECPAY_CHOOSE_PAYMENT");
    if (choosePayment !== "Credit") throw new Error("WEB2 currently accepts Credit payments only");

    const hashKey = required("ECPAY_HASH_KEY");
    const hashIv = required("ECPAY_HASH_IV");
    if (!/^\S{16}$/.test(hashKey) || !/^\S{16}$/.test(hashIv)) {
        throw new Error("Check ECPay HashKey / HashIV lengths");
    }

    const returnUrl = checkedUrl(required("ECPAY_RETURN_URL"), "ECPAY_RETURN_URL");
    const clientBackUrl = checkedUrl(required("ECPAY_CLIENT_BACK_URL"), "ECPAY_CLIENT_BACK_URL");
    const rawResultUrl = env.ECPAY_ORDER_RESULT_URL?.trim();
    const orderResultUrl = rawResultUrl ? checkedUrl(rawResultUrl, "ECPAY_ORDER_RESULT_URL") : "";

    if (orderResultUrl) {
        const result = new URL(orderResultUrl);
        const notification = new URL(returnUrl);
        if (`${result.origin}${result.pathname}` === `${notification.origin}${notification.pathname}`) {
            throw new Error("OrderResultURL and ReturnURL must be different endpoints");
        }
    }

    return Object.freeze({
        merchantId,
        hashKey,
        hashIv,
        environment: "production" as const,
        choosePayment: "Credit" as const,
        returnUrl,
        clientBackUrl,
        orderResultUrl,
    });
}

export function isEcpayConfigured() {
    try {
        getEcpayConfig();
        return Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY);
    } catch {
        return false;
    }
}

export function createMerchantTradeNo() {
    return `TM2${randomBytes(9).toString("hex").toUpperCase().slice(0, 17)}`;
}

export function formatMerchantTradeDate(date = new Date()) {
    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Taipei",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23",
    }).formatToParts(date);
    const get = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
    return `${get("year")}/${get("month")}/${get("day")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

export function buildCheckoutParameters(order: CheckoutOrder, config: EcpayConfig, date = new Date()) {
    if (order.environment !== "production" || config.environment !== "production") throw new Error("Environment mismatch");
    if (!/^TM2[A-Za-z0-9]{1,17}$/.test(order.merchantTradeNo)) throw new Error("Invalid WEB2 trade number");
    if (!Number.isSafeInteger(order.amount) || order.amount <= 0) throw new Error("Invalid order amount");
    if (!order.itemName || order.itemName.length > 400 || /[\x00-\x1f\x7f]/.test(order.itemName)) throw new Error("Invalid item name");
    if (!/^[A-Za-z0-9_-]{1,50}$/.test(order.packageCode)) throw new Error("Invalid package code");

    const fields: EcpayFields = {
        MerchantID: config.merchantId,
        MerchantTradeNo: order.merchantTradeNo,
        MerchantTradeDate: formatMerchantTradeDate(date),
        PaymentType: "aio",
        TotalAmount: String(order.amount),
        TradeDesc: "Tianming WEB2 purchase",
        ItemName: order.itemName,
        ReturnURL: config.returnUrl,
        ClientBackURL: config.clientBackUrl,
        ChoosePayment: config.choosePayment,
        NeedExtraPaidInfo: "N",
        EncryptType: "1",
        CustomField1: order.packageCode,
        CustomField2: "production",
        CustomField3: "TM2",
    };

    if (config.orderResultUrl) fields.OrderResultURL = config.orderResultUrl;
    return { ...fields, CheckMacValue: createCheckMacValue(fields, config.hashKey, config.hashIv) };
}

export function buildAutoSubmitPaymentPage(parameters: EcpayFields) {
    const escapeHtml = (value: string) =>
        String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#39;");

    const fields = Object.entries(parameters)
        .map(([key, value]) => `<input type="hidden" name="${escapeHtml(key)}" value="${escapeHtml(value)}">`)
        .join("");

    return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>前往綠界付款</title></head><body><p>正在前往綠界付款…</p><form id="ecpay-checkout" method="post" accept-charset="UTF-8" action="${ECPAY_CHECKOUT_URL}">${fields}<button type="submit">繼續付款</button></form><script>document.getElementById('ecpay-checkout').submit();</script></body></html>`;
}

export function validatePaidNotification(parameters: EcpayFields, order: CallbackOrder, config: EcpayConfig) {
    if (!verifyCheckMacValue(parameters, config.hashKey, config.hashIv)) throw new Error("Invalid payment signature");

    if (
        !order ||
        order.environment !== "production" ||
        config.environment !== "production" ||
        !Number.isSafeInteger(order.amount) ||
        order.amount <= 0 ||
        parameters.MerchantID !== config.merchantId ||
        parameters.MerchantTradeNo !== order.merchantTradeNo ||
        !/^TM2[A-Za-z0-9]{1,17}$/.test(parameters.MerchantTradeNo ?? "") ||
        parameters.TradeAmt !== String(order.amount) ||
        parameters.CustomField2 !== "production" ||
        parameters.CustomField3 !== "TM2"
    ) {
        throw new Error("Payment does not match this WEB2 order");
    }

    if (parameters.RtnCode !== "1") return { paid: false as const, reason: "not_paid" as const };
    if (parameters.SimulatePaid !== "0") return { paid: false as const, reason: "not_confirmed_real_payment" as const };
    if (!parameters.TradeNo) throw new Error("Missing ECPay trade number");

    return {
        paid: true as const,
        merchantTradeNo: order.merchantTradeNo,
        ecpayTradeNo: parameters.TradeNo,
        amount: order.amount,
    };
}
