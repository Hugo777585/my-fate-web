import { createHash } from "node:crypto";

export type EcpayFields = Record<string, string>;

function ecpayUrlEncode(value: string) {
    return encodeURIComponent(value)
        .replace(/%20/g, "+")
        .replace(/%2D/gi, "-")
        .replace(/%5F/gi, "_")
        .replace(/%2E/gi, ".")
        .replace(/%21/gi, "!")
        .replace(/%2A/gi, "*")
        .replace(/%28/gi, "(")
        .replace(/%29/gi, ")")
        .toLowerCase();
}

export function createCheckMacValue(fields: EcpayFields, hashKey: string, hashIv: string) {
    const sorted = Object.entries(fields)
        .filter(([key]) => key !== "CheckMacValue")
        .sort(([a], [b]) => a.toLowerCase().localeCompare(b.toLowerCase()))
        .map(([key, value]) => `${key}=${value}`)
        .join("&");

    const raw = `HashKey=${hashKey}&${sorted}&HashIV=${hashIv}`;
    const encoded = ecpayUrlEncode(raw);
    return createHash("sha256").update(encoded, "utf8").digest("hex").toUpperCase();
}

export function verifyCheckMacValue(fields: EcpayFields, hashKey: string, hashIv: string) {
    const incoming = fields.CheckMacValue?.toUpperCase();
    if (!incoming) return false;
    return createCheckMacValue(fields, hashKey, hashIv) === incoming;
}

export function formatTaipeiTradeDate(date = new Date()) {
    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Taipei",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
    }).formatToParts(date);
    const get = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
    return `${get("year")}/${get("month")}/${get("day")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

export function getEcpayAction(environment: "test" | "production") {
    return environment === "test"
        ? "https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5"
        : "https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5";
}
