import type { ProfileDetail, ProfileSummary } from "@/lib/profiles";

export type ZiweiAdapterProfile = Pick<
    ProfileSummary,
    "id" | "name" | "tag" | "gender" | "birthDate" | "birthTime" | "birthPlace"
>;

export type ZiweiWorkspaceProfileOption = {
    id: string;
    name: string;
    tag: string | null;
    gender: string;
    birthDate: string;
    birthTime: string;
    birthPlace: string;
};

export function normalizeZiweiProfileOption(profile: ZiweiAdapterProfile): ZiweiWorkspaceProfileOption {
    return {
        id: profile.id,
        name: profile.name,
        tag: profile.tag,
        gender: profile.gender,
        birthDate: profile.birthDate,
        birthTime: profile.birthTime,
        birthPlace: profile.birthPlace,
    };
}

export function toZiweiAdapterProfile(profile: ProfileDetail | ProfileSummary): ZiweiAdapterProfile {
    return {
        id: profile.id,
        name: profile.name,
        tag: profile.tag,
        gender: profile.gender,
        birthDate: profile.birthDate,
        birthTime: profile.birthTime,
        birthPlace: profile.birthPlace,
    };
}

