import { createClient } from "@/lib/supabase/server";

export type RecentReading = {
    id: string;
    system: string;
    topic: string;
    status: string;
    createdAt: string;
    answerTitle: string | null;
};

export type MemberDashboardData = {
    profileCount: number;
    clientCount: number;
    walletBalance: number;
    walletReserved: number;
    readingCount: number;
    paymentCount: number;
    recentReadings: RecentReading[];
};

export async function getMemberDashboardData(userId: string): Promise<MemberDashboardData> {
    const supabase = await createClient();

    await supabase.rpc("ensure_wallet");

    const [profiles, clients, wallet, readings, payments, recent] = await Promise.all([
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("owner_id", userId),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("owner_id", userId).eq("profile_type", "client"),
        supabase.from("wallet_accounts").select("balance, reserved_points").eq("user_id", userId).maybeSingle(),
        supabase.from("readings").select("id", { count: "exact", head: true }).eq("user_id", userId),
        supabase.from("payment_orders").select("id", { count: "exact", head: true }).eq("user_id", userId),
        supabase
            .from("readings")
            .select("id, system, topic, status, created_at, answer_title")
            .eq("user_id", userId)
            .order("created_at", { ascending: false })
            .limit(5),
    ]);

    const errors = [profiles.error, clients.error, wallet.error, readings.error, payments.error, recent.error].filter(Boolean);
    if (errors.length > 0) {
        throw new Error(`讀取會員資料失敗：${errors[0]?.message ?? "未知錯誤"}`);
    }

    return {
        profileCount: profiles.count ?? 0,
        clientCount: clients.count ?? 0,
        walletBalance: wallet.data?.balance ?? 0,
        walletReserved: wallet.data?.reserved_points ?? 0,
        readingCount: readings.count ?? 0,
        paymentCount: payments.count ?? 0,
        recentReadings: (recent.data ?? []).map((row) => ({
            id: row.id,
            system: row.system,
            topic: row.topic,
            status: row.status,
            createdAt: row.created_at,
            answerTitle: row.answer_title,
        })),
    };
}
