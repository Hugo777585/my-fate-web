import type { Route } from "next";
import type { LucideIcon } from "lucide-react";
import {
    BookUser,
    Coins,
    HeartHandshake,
    LayoutDashboard,
    Sparkles,
    Stars,
    UserRoundCog,
} from "lucide-react";

export const mainNav: ReadonlyArray<{ href: Route; label: string }> = [
    { href: "/", label: "首頁" },
    { href: "/bazi", label: "八字" },
    { href: "/ziwei", label: "紫微" },
    { href: "/compatibility", label: "兩人合盤" },
    { href: "/profiles", label: "命主資料" },
    { href: "/services", label: "深度服務" },
    { href: "/workspace", label: "HUGO 工作台" },
    { href: "/wallet", label: "錢包" },
    { href: "/about", label: "關於 HUGO" },
] as const;

export const productModules: ReadonlyArray<{
    title: string;
    description: string;
    href: Route;
    icon: LucideIcon;
    accent: string;
}> = [
    {
        title: "八字命盤",
        description: "從四柱、日主與五行開始，先免費看懂命盤骨架，再逐步進入個性、感情、事業、財運與 NT$299 深度解讀。",
        href: "/bazi",
        icon: Sparkles,
        accent: "免費基本排盤",
    },
    {
        title: "紫微斗數",
        description: "先看命宮、主星與十二宮，再依序閱讀夫妻、官祿、財帛與時間節奏；需要時再進入 NT$299 深度解讀。",
        href: "/ziwei",
        icon: Stars,
        accent: "免費基本排盤",
    },
    {
        title: "兩人合盤",
        description: "先看兩人的基本互動、吸引與衝突訊號，再往情緒、溝通與長期發展深入；NT$1,200 深度版加入八字＋紫微交叉判讀。",
        href: "/compatibility",
        icon: HeartHandshake,
        accent: "免費基本比較",
    },
    {
        title: "命主資料庫",
        description: "自己、親友與客戶只要建檔一次，八字、紫微與合盤都直接共用，不必每次重新輸入出生資料。",
        href: "/profiles",
        icon: BookUser,
        accent: "會員功能",
    },
    {
        title: "HUGO 深度解讀",
        description: "個人深度解讀 NT$299、雙人八字＋紫微合盤 NT$1,200；會員可直接帶入已建立的命主資料送出需求。",
        href: "/services",
        icon: UserRoundCog,
        accent: "真人顧問服務",
    },
    {
        title: "天命幣錢包",
        description: "查看目前餘額、贈幣到期與交易紀錄；深度解讀與後續服務可由同一個帳戶管理。",
        href: "/wallet",
        icon: Coins,
        accent: "會員資產",
    },
] as const;

export const dashboardLinks: ReadonlyArray<{ href: Route; label: string; icon: LucideIcon }> = [
    { href: "/profiles", label: "命主資料", icon: BookUser },
    { href: "/bazi", label: "八字排盤", icon: Sparkles },
    { href: "/ziwei", label: "紫微斗數", icon: Stars },
    { href: "/compatibility", label: "兩人合盤", icon: HeartHandshake },
    { href: "/wallet", label: "錢包與紀錄", icon: Coins },
    { href: "/workspace", label: "HUGO 工作台", icon: LayoutDashboard },
] as const;
