import { createClient } from "@/lib/supabase/server";

export type ConsultationRequestSummary = {
    id: string;
    userId: string;
    serviceCode: "personal_299" | "compatibility_1200";
    amountTwd: number;
    question: string;
    contactNote: string;
    status: string;
    createdAt: string;
    profileId: string;
    secondProfileId: string | null;
    profileName: string;
    secondProfileName: string | null;
};

export async function listConsultationRequestsForOwner(limit = 30): Promise<ConsultationRequestSummary[]> {
    const supabase = await createClient();
    const { data, error } = await supabase
        .from("consultation_requests")
        .select("id, user_id, service_code, amount_twd, question, contact_note, status, created_at, profile_id, second_profile_id")
        .order("created_at", { ascending: false })
        .limit(limit);

    if (error) throw new Error(`讀取客戶需求失敗：${error.message}`);

    const ids = Array.from(new Set((data ?? []).flatMap((row) => [row.profile_id, row.second_profile_id].filter(Boolean)))) as string[];
    const { data: profiles, error: profileError } = ids.length
        ? await supabase.from("clients").select("id, name").in("id", ids)
        : { data: [], error: null };
    if (profileError) throw new Error(`讀取案件命主失敗：${profileError.message}`);
    const names = new Map((profiles ?? []).map((row) => [row.id, row.name]));

    return (data ?? []).map((row) => ({
        id: row.id,
        userId: row.user_id,
        serviceCode: row.service_code as "personal_299" | "compatibility_1200",
        amountTwd: row.amount_twd,
        question: row.question,
        contactNote: row.contact_note,
        status: row.status,
        createdAt: row.created_at,
        profileId: row.profile_id,
        secondProfileId: row.second_profile_id,
        profileName: names.get(row.profile_id) ?? "命主",
        secondProfileName: row.second_profile_id ? names.get(row.second_profile_id) ?? "第二命主" : null,
    }));
}
