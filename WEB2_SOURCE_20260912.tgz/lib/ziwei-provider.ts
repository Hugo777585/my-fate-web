import {
    normalizeZiweiProfileOption,
    toZiweiAdapterProfile,
    type ZiweiAdapterProfile,
} from "@/lib/ziwei-adapter";
import {
    buildZiweiChartFromIztro,
    type ZiweiChart,
    type ZiweiChartInput,
} from "@/lib/ziwei-iztro-adapter";
import { getProfileById, listProfiles, type ProfileDetail, type ProfileSummary } from "@/lib/profiles";

export const ziweiWorkspaceModes = ["natal", "decade", "annual", "monthly", "daily", "hourly"] as const;

export type ZiweiWorkspaceMode = (typeof ziweiWorkspaceModes)[number];

export type ZiweiPageSearchParams = {
    profile?: string | string[] | undefined;
    mode?: string | string[] | undefined;
};

export type ZiweiPageData = {
    profiles: ProfileSummary[];
    selectedProfile: ProfileDetail | null;
    selectedProfileId?: string;
    activeMode: ZiweiWorkspaceMode;
    availableProfiles: ReturnType<typeof normalizeZiweiProfileOption>[];
    chartInput: ZiweiChartInput | null;
    hasChartInput: boolean;
    chart: ZiweiChart | null;
};

function getSingleSearchParam(value: string | string[] | undefined) {
    return Array.isArray(value) ? value[0] : value;
}

function normalizeZiweiGender(value: string): "男" | "女" | null {
    const normalized = value.trim();

    if (normalized === "男" || normalized === "男性") {
        return "男";
    }

    if (normalized === "女" || normalized === "女性") {
        return "女";
    }

    return null;
}

function normalizeZiweiBirthDate(value: string) {
    const normalized = value.trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(normalized) ? normalized : null;
}

function normalizeZiweiBirthTimeLabel(value: string) {
    const normalized = value.trim();
    return /(子|丑|寅|卯|辰|巳|午|未|申|酉|戌|亥)時/.test(normalized) ? normalized : null;
}

function buildZiweiChartInput(profile: ZiweiAdapterProfile): ZiweiChartInput | null {
    const gender = normalizeZiweiGender(profile.gender);
    const birthDate = normalizeZiweiBirthDate(profile.birthDate);
    const birthTimeLabel = normalizeZiweiBirthTimeLabel(profile.birthTime);

    if (!gender || !birthDate || !birthTimeLabel) {
        return null;
    }

    return {
        profileId: profile.id,
        gender,
        birthDate,
        birthTimeLabel,
        timezone: "Asia/Taipei",
        calendar: "solar",
        language: "zh-TW",
        ruleVersion: "ZIWEI_RULE_V1",
        engine: "iztro",
    };
}

export function normalizeZiweiWorkspaceMode(value: string | string[] | undefined): ZiweiWorkspaceMode {
    const mode = getSingleSearchParam(value);

    if (mode === "decade" || mode === "annual" || mode === "monthly" || mode === "daily" || mode === "hourly") {
        return mode;
    }

    return "natal";
}

export async function loadZiweiPageData(userId: string, searchParams: ZiweiPageSearchParams): Promise<ZiweiPageData> {
    const profiles = await listProfiles(userId);
    const selectedProfileId = getSingleSearchParam(searchParams.profile);
    const activeMode = normalizeZiweiWorkspaceMode(searchParams.mode);
    const selectedProfile = selectedProfileId ? await getProfileById(userId, selectedProfileId) : null;
    const availableProfiles = profiles.map((profile) => normalizeZiweiProfileOption(toZiweiAdapterProfile(profile)));
    const selectedAdapterProfile = selectedProfile ? toZiweiAdapterProfile(selectedProfile) : null;
    const chartInput = selectedAdapterProfile ? buildZiweiChartInput(selectedAdapterProfile) : null;
    const chart = chartInput ? await buildZiweiChartFromIztro(chartInput, activeMode) : null;

    return {
        profiles,
        selectedProfile,
        selectedProfileId: selectedProfile?.id ?? selectedProfileId,
        activeMode,
        availableProfiles,
        chartInput,
        hasChartInput: Boolean(chartInput),
        chart,
    };
}
