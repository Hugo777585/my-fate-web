export type ZiweiWorkspaceMode = "natal" | "decade" | "annual" | "monthly" | "daily" | "hourly";

export type ZiweiChartStatus = "ready" | "missing_required_fields" | "engine_error";

export type ZiweiChartInput = {
    profileId: string;
    gender: "男" | "女";
    birthDate: string;
    birthTimeLabel: string;
    timezone: string;
    calendar: "solar" | "lunar";
    lunarLeapMonth?: boolean;
    language: "zh-TW";
    ruleVersion: string;
    engine: "iztro";
    engineConfig?: Record<string, unknown>;
};

export type ZiweiPalaceKey =
    | "ming"
    | "siblings"
    | "spouse"
    | "children"
    | "wealth"
    | "health"
    | "travel"
    | "friends"
    | "career"
    | "property"
    | "fortune"
    | "parents";

export type ZiweiStar = {
    name: string;
    type: "major" | "minor" | "malefic" | "auxiliary" | "transform" | "unknown";
    brightness?: string;
    palaceKey: ZiweiPalaceKey;
    palaceIndex: number;
    tags?: string[];
};

export type ZiweiStarRef = {
    name: string;
    type?: ZiweiStar["type"];
    brightness?: string;
};

export type ZiweiTransformRef = {
    kind: "祿" | "權" | "科" | "忌";
    starName: string;
    targetPalaceKey?: ZiweiPalaceKey;
};

export type ZiweiTransformSet = {
    source: {
        heavenlyStem: string;
        mode: ZiweiWorkspaceMode;
    };
    map: {
        祿: string;
        權: string;
        科: string;
        忌: string;
    };
};

export type ZiweiLinkGraph = {
    nodes: Array<{
        id: string;
        kind: "palace" | "star";
        palaceKey?: ZiweiPalaceKey;
        starName?: string;
    }>;
    edges: Array<{
        id: string;
        kind: "surround" | "transform" | "opposite" | "custom";
        fromNodeId: string;
        toNodeId: string;
        strength?: number;
        label?: string;
    }>;
};

export type ZiweiPalace = {
    key: ZiweiPalaceKey;
    label: string;
    index: number;
    position: {
        ringIndex: number;
        gridRow: number;
        gridCol: number;
    };
    mainStars: ZiweiStarRef[];
    minorStars: ZiweiStarRef[];
    transforms: ZiweiTransformRef[];
    isEmpty: boolean;
    metadata?: Record<string, unknown>;
};

export type ZiweiChart = {
    id: string;
    status: ZiweiChartStatus;
    profileId: string;
    ruleVersion: string;
    timezone: string;
    standardTimeUsed: true;
    trueSolarTimeEnabled: false;
    mode: ZiweiWorkspaceMode;
    generatedAt: string;
    engine: {
        name: "iztro";
        version?: string;
    };
    subject: {
        name: string;
        gender: "男" | "女";
        birthDate: string;
        birthTimeLabel: string;
        birthPlace?: string;
    };
    meta: {
        zodiac?: string;
        constellation?: string;
        fourPillars?: {
            year: string;
            month: string;
            day: string;
            hour: string;
        };
    };
    palaces: ZiweiPalace[];
    stars: ZiweiStar[];
    transforms: ZiweiTransformSet;
    links: ZiweiLinkGraph;
};

type IztroStar = {
    name?: unknown;
    type?: unknown;
    brightness?: unknown;
    mutagen?: unknown;
};

type IztroPalace = {
    index?: unknown;
    name?: unknown;
    heavenlyStem?: unknown;
    earthlyBranch?: unknown;
    majorStars?: unknown;
    minorStars?: unknown;
    adjectiveStars?: unknown;
    isEmpty?: unknown;
};

type IztroChineseDate = {
    yearly?: unknown;
    monthly?: unknown;
    daily?: unknown;
    hourly?: unknown;
};

type IztroAstrolabe = {
    palaces?: unknown;
    zodiac?: unknown;
    sign?: unknown;
    rawDates?: unknown;
};

const palaceKeyMap: Record<string, ZiweiPalaceKey> = {
    命宮: "ming",
    兄弟: "siblings",
    夫妻: "spouse",
    子女: "children",
    財帛: "wealth",
    疾厄: "health",
    遷移: "travel",
    僕役: "friends",
    交友: "friends",
    官祿: "career",
    事業: "career",
    田宅: "property",
    福德: "fortune",
    父母: "parents",
};

const palacePositionMap: Record<ZiweiPalaceKey, ZiweiPalace["position"]> = {
    parents: { ringIndex: 0, gridRow: 0, gridCol: 0 },
    fortune: { ringIndex: 1, gridRow: 0, gridCol: 1 },
    property: { ringIndex: 2, gridRow: 0, gridCol: 2 },
    career: { ringIndex: 3, gridRow: 0, gridCol: 3 },
    ming: { ringIndex: 4, gridRow: 1, gridCol: 0 },
    friends: { ringIndex: 7, gridRow: 1, gridCol: 3 },
    siblings: { ringIndex: 8, gridRow: 2, gridCol: 0 },
    travel: { ringIndex: 11, gridRow: 2, gridCol: 3 },
    spouse: { ringIndex: 12, gridRow: 3, gridCol: 0 },
    children: { ringIndex: 13, gridRow: 3, gridCol: 1 },
    wealth: { ringIndex: 14, gridRow: 3, gridCol: 2 },
    health: { ringIndex: 15, gridRow: 3, gridCol: 3 },
};

const oppositePairs: Array<[ZiweiPalaceKey, ZiweiPalaceKey]> = [
    ["ming", "travel"],
    ["siblings", "friends"],
    ["spouse", "career"],
    ["children", "property"],
    ["wealth", "fortune"],
    ["health", "parents"],
];

function toStringValue(value: unknown) {
    return typeof value === "string" ? value : null;
}

function toNumberValue(value: unknown) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function toArrayValue<T>(value: unknown): T[] {
    return Array.isArray(value) ? (value as T[]) : [];
}

function normalizeMutagenKind(value: string | null): ZiweiTransformRef["kind"] | null {
    if (!value) {
        return null;
    }

    if (value === "祿" || value === "權" || value === "科" || value === "忌") {
        return value;
    }

    if (value.includes("祿")) {
        return "祿";
    }

    if (value.includes("權")) {
        return "權";
    }

    if (value.includes("科")) {
        return "科";
    }

    if (value.includes("忌")) {
        return "忌";
    }

    return null;
}

export function toIztroTimeIndex(birthTimeLabel: string) {
    const match = birthTimeLabel.match(/(子|丑|寅|卯|辰|巳|午|未|申|酉|戌|亥)時/);
    const key = match?.[1];

    switch (key) {
        case "子":
            return 0;
        case "丑":
            return 1;
        case "寅":
            return 2;
        case "卯":
            return 3;
        case "辰":
            return 4;
        case "巳":
            return 5;
        case "午":
            return 6;
        case "未":
            return 7;
        case "申":
            return 8;
        case "酉":
            return 9;
        case "戌":
            return 10;
        case "亥":
            return 11;
        default:
            return 0;
    }
}

function mapIztroStarType(raw: string | null, bucket: "major" | "minor" | "adjective"): ZiweiStar["type"] {
    if (bucket === "major") {
        return "major";
    }

    if (bucket === "adjective") {
        return "auxiliary";
    }

    if (!raw) {
        return "minor";
    }

    if (raw.includes("major")) {
        return "major";
    }

    if (raw.includes("malefic")) {
        return "malefic";
    }

    if (raw.includes("transform")) {
        return "transform";
    }

    return "minor";
}

function extractFourPillars(rawDates: unknown) {
    if (!rawDates || typeof rawDates !== "object") {
        return null;
    }

    const raw = rawDates as Record<string, unknown>;
    const chineseDate = raw.chineseDate as IztroChineseDate | undefined;

    const yearly = Array.isArray(chineseDate?.yearly) ? (chineseDate?.yearly as unknown[]) : null;
    const monthly = Array.isArray(chineseDate?.monthly) ? (chineseDate?.monthly as unknown[]) : null;
    const daily = Array.isArray(chineseDate?.daily) ? (chineseDate?.daily as unknown[]) : null;
    const hourly = Array.isArray(chineseDate?.hourly) ? (chineseDate?.hourly as unknown[]) : null;

    if (!yearly || !monthly || !daily || !hourly) {
        return null;
    }

    const year = `${toStringValue(yearly[0]) ?? ""}${toStringValue(yearly[1]) ?? ""}`.trim();
    const month = `${toStringValue(monthly[0]) ?? ""}${toStringValue(monthly[1]) ?? ""}`.trim();
    const day = `${toStringValue(daily[0]) ?? ""}${toStringValue(daily[1]) ?? ""}`.trim();
    const hour = `${toStringValue(hourly[0]) ?? ""}${toStringValue(hourly[1]) ?? ""}`.trim();

    if (!year || !month || !day || !hour) {
        return null;
    }

    return { year, month, day, hour };
}

export async function buildZiweiChartFromIztro(input: ZiweiChartInput, mode: ZiweiWorkspaceMode): Promise<ZiweiChart> {
    try {
        const iztro = await import("iztro");
        const astro = (iztro as unknown as { astro?: unknown }).astro as
            | {
                  bySolar: (date: string, timeIndex: number, gender: string, isLeapMonth: boolean, language: string) => unknown;
              }
            | undefined;

        if (!astro) {
            return {
                id: `ziwei:${input.profileId}:${Date.now()}`,
                status: "engine_error",
                profileId: input.profileId,
                ruleVersion: input.ruleVersion,
                timezone: input.timezone,
                standardTimeUsed: true,
                trueSolarTimeEnabled: false,
                mode,
                generatedAt: new Date().toISOString(),
                engine: { name: "iztro" },
                subject: {
                    name: input.profileId,
                    gender: input.gender,
                    birthDate: input.birthDate,
                    birthTimeLabel: input.birthTimeLabel,
                },
                meta: {},
                palaces: [],
                stars: [],
                transforms: {
                    source: { heavenlyStem: "", mode },
                    map: { 祿: "", 權: "", 科: "", 忌: "" },
                },
                links: { nodes: [], edges: [] },
            };
        }

        const timeIndex = toIztroTimeIndex(input.birthTimeLabel);
        const astrolabe = astro.bySolar(input.birthDate, timeIndex, input.gender, Boolean(input.lunarLeapMonth), input.language) as
            | IztroAstrolabe
            | undefined;

        const palaceRows = toArrayValue<IztroPalace>((astrolabe as IztroAstrolabe | undefined)?.palaces);

        const palaces: ZiweiPalace[] = [];
        const stars: ZiweiStar[] = [];
        const transformMap: ZiweiTransformSet["map"] = { 祿: "", 權: "", 科: "", 忌: "" };

        for (const palaceRaw of palaceRows) {
            const label = toStringValue(palaceRaw?.name) ?? "未定";
            const palaceKey = palaceKeyMap[label] ?? "ming";
            const palaceIndex = toNumberValue(palaceRaw?.index) ?? 0;
            const majorStars = toArrayValue<IztroStar>(palaceRaw?.majorStars);
            const minorStars = toArrayValue<IztroStar>(palaceRaw?.minorStars);
            const adjectiveStars = toArrayValue<IztroStar>(palaceRaw?.adjectiveStars);
            const isEmptyFn = palaceRaw?.isEmpty;
            const isEmpty = typeof isEmptyFn === "function" ? Boolean((isEmptyFn as () => unknown)()) : false;

            const mainStarRefs: ZiweiStarRef[] = majorStars
                .map((star) => ({
                    name: toStringValue(star.name) ?? "未定",
                    type: mapIztroStarType(toStringValue(star.type), "major"),
                    brightness: toStringValue(star.brightness) ?? undefined,
                }))
                .filter((star) => star.name !== "未定");

            const minorStarRefs: ZiweiStarRef[] = [...minorStars, ...adjectiveStars]
                .map((star, index) => ({
                    name: toStringValue(star.name) ?? `星曜 ${index + 1}`,
                    type: mapIztroStarType(toStringValue(star.type), star === adjectiveStars[index - minorStars.length] ? "adjective" : "minor"),
                    brightness: toStringValue(star.brightness) ?? undefined,
                }))
                .filter((star) => Boolean(star.name));

            const transforms: ZiweiTransformRef[] = [];
            const allStars = [
                { bucket: "major" as const, items: majorStars },
                { bucket: "minor" as const, items: minorStars },
                { bucket: "adjective" as const, items: adjectiveStars },
            ];

            for (const group of allStars) {
                for (const star of group.items) {
                    const name = toStringValue(star.name);

                    if (!name) {
                        continue;
                    }

                    const kind = normalizeMutagenKind(toStringValue(star.mutagen));

                    if (kind) {
                        transforms.push({ kind, starName: name });

                        if (!transformMap[kind]) {
                            transformMap[kind] = name;
                        }
                    }

                    stars.push({
                        name,
                        type: mapIztroStarType(toStringValue(star.type), group.bucket),
                        brightness: toStringValue(star.brightness) ?? undefined,
                        palaceKey,
                        palaceIndex,
                    });
                }
            }

            palaces.push({
                key: palaceKey,
                label,
                index: palaceIndex,
                position: palacePositionMap[palaceKey],
                mainStars: mainStarRefs,
                minorStars: minorStarRefs,
                transforms,
                isEmpty,
                metadata: {
                    heavenlyStem: toStringValue(palaceRaw?.heavenlyStem) ?? undefined,
                    earthlyBranch: toStringValue(palaceRaw?.earthlyBranch) ?? undefined,
                },
            });
        }

        const palaceNodes = (Object.values(palaceKeyMap) as ZiweiPalaceKey[]).filter(
            (value, index, values) => values.indexOf(value) === index,
        );

        const links: ZiweiLinkGraph = {
            nodes: palaceNodes.map((key) => ({ id: `palace:${key}`, kind: "palace", palaceKey: key })),
            edges: oppositePairs.map(([left, right]) => ({
                id: `opposite:${left}:${right}`,
                kind: "opposite",
                fromNodeId: `palace:${left}`,
                toNodeId: `palace:${right}`,
                strength: 1,
                label: "對宮",
            })),
        };

        const fourPillars = extractFourPillars((astrolabe as unknown as { rawDates?: unknown } | undefined)?.rawDates);
        const zodiac = toStringValue((astrolabe as unknown as { zodiac?: unknown } | undefined)?.zodiac) ?? undefined;
        const constellation = toStringValue((astrolabe as unknown as { sign?: unknown } | undefined)?.sign) ?? undefined;

        return {
            id: `ziwei:${input.profileId}:${Date.now()}`,
            status: "ready",
            profileId: input.profileId,
            ruleVersion: input.ruleVersion,
            timezone: input.timezone,
            standardTimeUsed: true,
            trueSolarTimeEnabled: false,
            mode,
            generatedAt: new Date().toISOString(),
            engine: { name: "iztro", version: toStringValue((iztro as unknown as { version?: unknown }).version) ?? undefined },
            subject: {
                name: input.profileId,
                gender: input.gender,
                birthDate: input.birthDate,
                birthTimeLabel: input.birthTimeLabel,
            },
            meta: {
                zodiac,
                constellation,
                fourPillars: fourPillars ?? undefined,
            },
            palaces,
            stars,
            transforms: {
                source: {
                    heavenlyStem: fourPillars?.year?.slice(0, 1) ?? "",
                    mode,
                },
                map: transformMap,
            },
            links,
        };
    } catch {
        return {
            id: `ziwei:${input.profileId}:${Date.now()}`,
            status: "engine_error",
            profileId: input.profileId,
            ruleVersion: input.ruleVersion,
            timezone: input.timezone,
            standardTimeUsed: true,
            trueSolarTimeEnabled: false,
            mode,
            generatedAt: new Date().toISOString(),
            engine: { name: "iztro" },
            subject: {
                name: input.profileId,
                gender: input.gender,
                birthDate: input.birthDate,
                birthTimeLabel: input.birthTimeLabel,
            },
            meta: {},
            palaces: [],
            stars: [],
            transforms: {
                source: { heavenlyStem: "", mode },
                map: { 祿: "", 權: "", 科: "", 忌: "" },
            },
            links: { nodes: [], edges: [] },
        };
    }
}
