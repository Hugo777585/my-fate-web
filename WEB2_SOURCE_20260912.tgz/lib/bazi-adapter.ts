import type { ProfileDetail, ProfileSummary } from "@/lib/profiles";

import {
    BAZI_RULE_VERSION,
    BAZI_TIMEZONE,
    type BaziChart,
    type BaziChartAdapter,
    type BaziChartStatus,
    type BaziMissingFieldKey,
    type BaziReadingContextSnapshot,
    type BaziReadingRecord,
    type BaziTimeMode,
    type BaziWorkspaceData,
    type BaziWorkspaceProfileOption,
    type BuildBaziChartInput,
} from "@/lib/bazi-fixture";
import {
    buildAnnualsFromInput,
    buildDayMasterSummaryFromFourPillars,
    buildElementBalanceFromFourPillars,
    buildFourPillarsFromInput,
    buildLuckCycleFromInput,
} from "@/lib/bazi-lunar";

type AdapterProfile = Pick<
    ProfileSummary,
    "id" | "name" | "tag" | "gender" | "birthDate" | "birthTime" | "birthPlace"
>;

type BuildWorkspaceInput = {
    profile?: AdapterProfile | null;
    profiles?: AdapterProfile[];
    mode?: BaziTimeMode;
    chartStatus?: BaziChartStatus;
};

type BuildReadingBundleInput = {
    profileId?: string;
    mode?: BaziTimeMode;
    annualYear?: number;
};

const emptyFieldValue = "未填";

export function normalizeBaziProfileOption(profile: AdapterProfile): BaziWorkspaceProfileOption {
    return {
        id: profile.id,
        name: profile.name,
        tag: profile.tag,
        gender: profile.gender,
        birthDate: profile.birthDate,
        birthTime: profile.birthTime,
        birthPlace: profile.birthPlace,
    };
}

export function getMissingBaziProfileFields(profile?: AdapterProfile | null): BaziMissingFieldKey[] {
    if (!profile) {
        return ["gender", "birthDate", "birthTimeLabel", "birthPlace"];
    }

    const missingFields: BaziMissingFieldKey[] = [];

    if (!profile.gender || profile.gender === emptyFieldValue) {
        missingFields.push("gender");
    }

    if (!profile.birthDate || profile.birthDate === emptyFieldValue) {
        missingFields.push("birthDate");
    }

    if (!profile.birthTime || profile.birthTime === emptyFieldValue) {
        missingFields.push("birthTimeLabel");
    }

    if (!profile.birthPlace || profile.birthPlace === emptyFieldValue) {
        missingFields.push("birthPlace");
    }

    return missingFields;
}

export function buildBaziChartInputFromProfile(profile: AdapterProfile): BuildBaziChartInput | null {
    const missingFields = getMissingBaziProfileFields(profile);

    if (missingFields.length > 0) {
        return null;
    }

    return {
        profileId: profile.id,
        gender: profile.gender,
        birthDate: profile.birthDate,
        birthTimeLabel: profile.birthTime,
        birthPlace: profile.birthPlace,
        timezone: BAZI_TIMEZONE,
        ruleVersion: BAZI_RULE_VERSION,
    };
}

export function getChartStatusForProfile(profile?: AdapterProfile | null): BaziChartStatus {
    if (!profile) {
        return "missing_required_fields";
    }

    return getMissingBaziProfileFields(profile).length > 0 ? "missing_required_fields" : "ready";
}

export class LunarBaziChartAdapter implements BaziChartAdapter {
    async buildChart(input: BuildBaziChartInput): Promise<BaziChart> {
        const fourPillars = buildFourPillarsFromInput(input);
        const elementBalance = buildElementBalanceFromFourPillars(fourPillars);
        const dayMasterSummary = buildDayMasterSummaryFromFourPillars(
            fourPillars,
            elementBalance,
        );
        const luckCycle = buildLuckCycleFromInput(input);
        const annuals = buildAnnualsFromInput(input, luckCycle, null);

        return {
            id: `${input.profileId}-bazi`,
            profileId: input.profileId,
            chartVersion: `bazi-${input.ruleVersion}`,
            ruleVersion: input.ruleVersion,
            timezone: input.timezone,
            standardTimeUsed: true,
            trueSolarTimeEnabled: false,
            calculatedAt: new Date().toISOString(),
            status: "ready",
            missingFields: [],
            fourPillars,
            dayMasterSummary,
            elementBalance,
            luckCycle,
            annuals,
        };
    }
}

export function createLunarBaziChartAdapter() {
    return new LunarBaziChartAdapter();
}

export async function buildBaziChartFromProfile(
    profile?: AdapterProfile | null,
    adapter: BaziChartAdapter = createLunarBaziChartAdapter(),
): Promise<BaziChart> {
    const input = profile ? buildBaziChartInputFromProfile(profile) : null;

    if (!input) {
        return {
            id: `${profile?.id ?? "unselected"}-bazi`,
            profileId: profile?.id ?? "unselected",
            chartVersion: `bazi-${BAZI_RULE_VERSION}`,
            ruleVersion: BAZI_RULE_VERSION,
            timezone: BAZI_TIMEZONE,
            standardTimeUsed: true,
            trueSolarTimeEnabled: false,
            calculatedAt: new Date().toISOString(),
            status: "missing_required_fields",
            missingFields: getMissingBaziProfileFields(profile),
        };
    }

    return adapter.buildChart(input);
}

export async function buildBaziWorkspaceFromProfile({
    profile,
    profiles = [],
    mode = "natal",
    chartStatus,
}: BuildWorkspaceInput = {}): Promise<BaziWorkspaceData> {
    const derivedChartStatus = chartStatus ?? getChartStatusForProfile(profile);
    const availableProfiles = profiles.map(normalizeBaziProfileOption);
    const chart = profile
        ? await buildBaziChartFromProfile(profile)
        : null;

    return {
        profileId: profile?.id,
        mode,
        chart: chart && derivedChartStatus !== chart.status
            ? { ...chart, status: derivedChartStatus }
            : chart,
        availableProfiles,
    };
}

export function buildBaziReadingBundle({
    chart,
    profileId,
    mode = "annual",
    annualYear,
}: BuildReadingBundleInput & { chart: BaziChart }): {
    context: BaziReadingContextSnapshot;
    record: BaziReadingRecord;
} {
    const summary = chart.dayMasterSummary;
    const yearLabel = annualYear ? `${annualYear} 年` : "本命";
    const createdAt = new Date().toISOString();
    const snapshotId = `${chart.id}-${mode}-${annualYear ?? "natal"}`;

    return {
        context: {
            id: snapshotId,
            userId: "current-user",
            profileId: profileId ?? chart.profileId,
            chartId: chart.id,
            chartVersion: chart.chartVersion,
            ruleVersion: chart.ruleVersion,
            system: "bazi",
            mode,
            selectedAnnualYear: annualYear,
            questionTopic: "timing",
            finalQuestion: `${yearLabel}的命盤結構中，最值得優先留意的節奏與選擇是什麼？`,
            promptVersion: "web2-chart-summary-v1",
            createdAt,
        },
        record: {
            id: `${snapshotId}-summary`,
            profileId: profileId ?? chart.profileId,
            contextSnapshotId: snapshotId,
            status: "available",
            title: `${yearLabel}命盤重點整理`,
            summary: summary?.summary ?? "命盤已完成，請從四柱、五行與大運流年交叉閱讀。",
            content: summary
                ? `${summary.title}，日主${summary.strengthLabel}。格局參考：${summary.pattern}。喜用方向：${summary.usefulGods.join("、") || "需綜合判斷"}。這一區是依排盤結果整理的客觀摘要，不等同付費深度解讀。`
                : "命盤資料已完成；深度解讀需進一步結合問題、大運與流年。",
            tokenCost: 0,
            createdAt,
            updatedAt: createdAt,
        },
    };
}

export function toAdapterProfile(profile: ProfileDetail | ProfileSummary): AdapterProfile {
    return {
        id: profile.id,
        name: profile.name,
        tag: profile.tag,
        gender: profile.gender,
        birthDate: profile.birthDate,
        birthTime: profile.birthTime,
        birthPlace: profile.birthPlace,
    };
}
