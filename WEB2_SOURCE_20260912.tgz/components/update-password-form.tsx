"use client";

import { useActionState } from "react";

import { updatePasswordAction, type AuthActionState } from "@/app/auth/actions";

const initialState: AuthActionState = {};

export function UpdatePasswordForm() {
    const [state, formAction, pending] = useActionState(updatePasswordAction, initialState);

    return (
        <article className="mx-auto max-w-2xl rounded-[28px] border border-amber-300/15 bg-[#140d0b] p-8">
            <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">Set New Password</p>
            <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">設定新密碼</h2>
            <p className="mt-4 text-sm leading-7 text-stone-300">
                請設定至少 6 碼的新密碼。更新完成後會保持登入，直接回到會員工作台。
            </p>

            <form action={formAction} className="mt-8 space-y-4">
                <input
                    name="password"
                    type="password"
                    autoComplete="new-password"
                    className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                    placeholder="新密碼（至少 6 碼）"
                />
                {state.fieldErrors?.password ? (
                    <p className="text-sm text-rose-300">{state.fieldErrors.password}</p>
                ) : null}

                <input
                    name="confirmPassword"
                    type="password"
                    autoComplete="new-password"
                    className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                    placeholder="再次輸入新密碼"
                />
                {state.fieldErrors?.confirmPassword ? (
                    <p className="text-sm text-rose-300">{state.fieldErrors.confirmPassword}</p>
                ) : null}

                {state.error ? (
                    <div className="rounded-2xl border border-rose-300/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
                        {state.error}
                    </div>
                ) : null}

                <button
                    type="submit"
                    disabled={pending}
                    className="w-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {pending ? "更新中..." : "更新密碼"}
                </button>
            </form>
        </article>
    );
}
