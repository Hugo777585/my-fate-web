"use client";

import { useFormStatus } from "react-dom";

type ProfileDeleteButtonProps = {
    action: (formData: FormData) => void | Promise<void>;
};

function DeleteSubmit() {
    const { pending } = useFormStatus();

    return (
        <button
            type="submit"
            disabled={pending}
            className="rounded-full border border-rose-300/20 px-5 py-3 text-sm text-rose-200 hover:bg-rose-500/10 disabled:cursor-not-allowed disabled:opacity-60"
        >
            {pending ? "刪除中..." : "刪除資料"}
        </button>
    );
}

export function ProfileDeleteButton({ action }: ProfileDeleteButtonProps) {
    return (
        <form
            action={action}
            onSubmit={(event) => {
                if (!window.confirm("確定要刪除這筆親友資料嗎？")) {
                    event.preventDefault();
                }
            }}
        >
            <DeleteSubmit />
        </form>
    );
}
