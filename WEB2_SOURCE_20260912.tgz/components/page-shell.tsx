import type { ReactNode } from "react";

type PageShellProps = {
    eyebrow: string;
    title: string;
    description: string;
    children: ReactNode;
    actions?: ReactNode;
};

export function PageShell({
    eyebrow,
    title,
    description,
    children,
    actions,
}: PageShellProps) {
    return (
        <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-8 px-6 py-10 lg:py-14">
            <section className="overflow-hidden rounded-[32px] border border-white/10 bg-[radial-gradient(circle_at_top,#6b3d14_0%,#1a100d_42%,#090707_100%)] p-8 shadow-[0_0_120px_rgba(251,191,36,0.08)] lg:p-10">
                <div className="max-w-3xl">
                    <p className="text-xs uppercase tracking-[0.42em] text-amber-200/55">{eyebrow}</p>
                    <h1 className="mt-4 text-4xl leading-tight font-medium tracking-[0.08em] text-stone-50 lg:text-6xl">
                        {title}
                    </h1>
                    <p className="mt-5 max-w-2xl text-sm leading-7 text-stone-300 lg:text-base">
                        {description}
                    </p>
                    {actions ? <div className="mt-8 flex flex-wrap gap-3">{actions}</div> : null}
                </div>
            </section>

            {children}
        </main>
    );
}
