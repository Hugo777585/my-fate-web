"use client";

import Link from "next/link";
import { useActionState } from "react";

import { forgotPasswordAction, type AuthActionState } from "@/app/auth/actions";

const initialState: AuthActionState = {};

export function ForgotPasswordForm() {
    const [state, formAction, pending] = useActionState(forgotPasswordAction, initialState);

    return (
        <article className="mx-auto max-w-2xl rounded-[28px] border border-amber-300/15 bg-[#140d0b] p-8">
            <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">Password Recovery</p>
            <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">忘記密碼</h2>
            <p className="mt-4 text-sm leading-7 text-stone-300">
                輸入註冊時使用的 Email，我們會寄出重設密碼連結。為保護會員隱私，無論 Email 是否存在，畫面都會顯示相同的寄送結果。
            </p>

            <form action={formAction} className="mt-8 space-y-4">
                <input
                    name="email"
                    type="email"
                    autoComplete="email"
                    className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                    placeholder="註冊 Email"
                />
                {state.fieldErrors?.email ? (
                    <p className="text-sm text-rose-300">{state.fieldErrors.email}</p>
                ) : null}

                {state.error ? (
                    <div className="rounded-2xl border border-rose-300/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
                        {state.error}
                    </div>
                ) : null}
                {state.success ? (
                    <div className="rounded-2xl border border-emerald-300/20 bg-emerald-500/10 px-4 py-3 text-sm leading-6 text-emerald-200">
                        {state.success}
                    </div>
                ) : null}

                <button
                    type="submit"
                    disabled={pending}
                    className="w-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {pending ? "寄送中..." : "寄出重設密碼信"}
                </button>
            </form>

            <div className="mt-6 text-center">
                <Link href="/auth" className="text-sm text-amber-200/80 hover:text-amber-100">
                    ← 回登入頁
                </Link>
            </div>
        </article>
    );
}
