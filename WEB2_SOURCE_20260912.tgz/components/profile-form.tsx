"use client";

import { useActionState, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

import type { ProfileActionState } from "@/app/profiles/actions";
import type { ProfileDetail, ProfileType } from "@/lib/profiles";

type ProfileFormProps = {
    action: (
        state: ProfileActionState,
        formData: FormData,
    ) => Promise<ProfileActionState>;
    initialProfile?: ProfileDetail;
    submitLabel: string;
};

const initialState: ProfileActionState = {};
const genderOptions = ["男", "女"] as const;
const birthTimeOptions = [
    "子時 23:00-01:00",
    "丑時 01:00-03:00",
    "寅時 03:00-05:00",
    "卯時 05:00-07:00",
    "辰時 07:00-09:00",
    "巳時 09:00-11:00",
    "午時 11:00-13:00",
    "未時 13:00-15:00",
    "申時 15:00-17:00",
    "酉時 17:00-19:00",
    "戌時 19:00-21:00",
    "亥時 21:00-23:00",
] as const;
const birthPlaceOptions = [
    "台北",
    "新北",
    "基隆",
    "桃園",
    "新竹",
    "苗栗",
    "台中",
    "彰化",
    "南投",
    "雲林",
    "嘉義",
    "台南",
    "高雄",
    "屏東",
    "宜蘭",
    "花蓮",
    "台東",
    "澎湖",
    "金門",
    "馬祖",
] as const;
const currentYear = new Date().getFullYear();
const yearOptions = Array.from({ length: currentYear - 1939 }, (_, index) => String(currentYear - index));
const monthOptions = Array.from({ length: 12 }, (_, index) => String(index + 1).padStart(2, "0"));

function parseBirthDate(value?: string) {
    const normalized = getDefaultValue(value);

    if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
        return {
            year: "",
            month: "",
            day: "",
        };
    }

    const [year, month, day] = normalized.split("-");
    return { year, month, day };
}

function SubmitButton({ label }: { label: string }) {
    const { pending } = useFormStatus();

    return (
        <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-60"
        >
            {pending ? "送出中..." : label}
        </button>
    );
}

function getDefaultType(profileType?: ProfileType) {
    return profileType ?? "family";
}

function getDefaultValue(value?: string) {
    return !value || value === "未填" || value === "尚未填寫備註。" ? "" : value;
}

export function ProfileForm({
    action,
    initialProfile,
    submitLabel,
}: ProfileFormProps) {
    const [state, formAction] = useActionState(action, initialState);
    const defaultBirthDate = parseBirthDate(initialProfile?.birthDate);
    const [birthYear, setBirthYear] = useState(defaultBirthDate.year);
    const [birthMonth, setBirthMonth] = useState(defaultBirthDate.month);
    const [birthDay, setBirthDay] = useState(defaultBirthDate.day);
    const dayOptions = useMemo(() => {
        if (!birthYear || !birthMonth) {
            return [];
        }

        const daysInMonth = new Date(Number(birthYear), Number(birthMonth), 0).getDate();
        return Array.from({ length: daysInMonth }, (_, index) => String(index + 1).padStart(2, "0"));
    }, [birthMonth, birthYear]);
    const birthDateValue = birthYear && birthMonth && birthDay
        ? `${birthYear}-${birthMonth}-${birthDay}`
        : "";

    return (
        <form action={formAction} className="grid gap-4 lg:grid-cols-2">
            <input
                name="name"
                defaultValue={initialProfile?.name ?? ""}
                className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
                placeholder="姓名 / 暱稱"
            />
            <select
                name="profileType"
                defaultValue={getDefaultType(initialProfile?.profileType)}
                className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
            >
                <option value="self">本人</option>
                <option value="family">親友</option>
                <option value="client">客戶</option>
            </select>
            <select
                name="gender"
                defaultValue={getDefaultValue(initialProfile?.gender)}
                className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
            >
                <option value="">選擇性別</option>
                {genderOptions.map((gender) => (
                    <option key={gender} value={gender}>
                        {gender}
                    </option>
                ))}
            </select>
            <input type="hidden" name="birthDate" value={birthDateValue} readOnly />
            <div className="grid gap-3 sm:grid-cols-3">
                <select
                    value={birthYear}
                    onChange={(event) => {
                        setBirthYear(event.target.value);
                        if (birthDay) {
                            setBirthDay("");
                        }
                    }}
                    className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
                >
                    <option value="">出生年</option>
                    {yearOptions.map((year) => (
                        <option key={year} value={year}>
                            {year}
                        </option>
                    ))}
                </select>
                <select
                    value={birthMonth}
                    onChange={(event) => {
                        setBirthMonth(event.target.value);
                        if (birthDay) {
                            setBirthDay("");
                        }
                    }}
                    className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
                >
                    <option value="">出生月</option>
                    {monthOptions.map((month) => (
                        <option key={month} value={month}>
                            {month}
                        </option>
                    ))}
                </select>
                <select
                    value={birthDay}
                    onChange={(event) => setBirthDay(event.target.value)}
                    className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
                >
                    <option value="">出生日</option>
                    {dayOptions.map((day) => (
                        <option key={day} value={day}>
                            {day}
                        </option>
                    ))}
                </select>
            </div>
            <select
                name="birthTimeLabel"
                defaultValue={getDefaultValue(initialProfile?.birthTime)}
                className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
            >
                <option value="">選擇時辰</option>
                {birthTimeOptions.map((time) => (
                    <option key={time} value={time}>
                        {time}
                    </option>
                ))}
            </select>
            <select
                name="birthPlace"
                defaultValue={getDefaultValue(initialProfile?.birthPlace)}
                className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35"
            >
                <option value="">選擇出生地</option>
                {birthPlaceOptions.map((place) => (
                    <option key={place} value={place}>
                        {place}
                    </option>
                ))}
            </select>
            <textarea
                name="notes"
                defaultValue={getDefaultValue(initialProfile?.notes)}
                className="min-h-36 rounded-[24px] border border-white/10 bg-[#120d0b] px-4 py-3 text-sm outline-none focus:border-amber-300/35 lg:col-span-2"
                placeholder="備註"
            />
            {state.error ? (
                <p className="text-sm text-rose-300 lg:col-span-2">{state.error}</p>
            ) : null}
            <div className="flex flex-wrap gap-3 lg:col-span-2">
                <SubmitButton label={submitLabel} />
            </div>
        </form>
    );
}
