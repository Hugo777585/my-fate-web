"use client";

import { useActionState } from "react";

import { createConsultationRequestAction, type ConsultationActionState } from "@/app/services/actions";
import type { ProfileSummary } from "@/lib/profiles";

type Props = {
    profiles: ProfileSummary[];
    defaultPlan?: "personal_299" | "compatibility_1200";
};

const initialState: ConsultationActionState = {};

export function ConsultationRequestForm({ profiles, defaultPlan = "personal_299" }: Props) {
    const [state, action, pending] = useActionState(createConsultationRequestAction, initialState);

    return (
        <form action={action} className="grid gap-4 rounded-[30px] border border-white/10 bg-white/[0.03] p-6 lg:grid-cols-2 lg:p-8">
            <label className="grid gap-2 text-sm text-stone-300">
                服務方案
                <select name="serviceCode" defaultValue={defaultPlan} className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                    <option value="personal_299">個人深度解讀 · NT$299</option>
                    <option value="compatibility_1200">雙人深度合盤 · NT$1,200</option>
                </select>
            </label>
            <label className="grid gap-2 text-sm text-stone-300">
                主要命主
                <select name="profileId" className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                    <option value="">請選擇</option>
                    {profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.name} · {profile.tag}</option>)}
                </select>
            </label>
            <label className="grid gap-2 text-sm text-stone-300 lg:col-span-2">
                第二位命主（雙人合盤才需要）
                <select name="secondProfileId" className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35">
                    <option value="">不選擇</option>
                    {profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.name} · {profile.tag}</option>)}
                </select>
            </label>
            <label className="grid gap-2 text-sm text-stone-300 lg:col-span-2">
                聯絡方式
                <input name="contactNote" maxLength={300} className="rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35" placeholder="例如：LINE ID、手機或方便聯絡的 Email" />
            </label>
            <label className="grid gap-2 text-sm text-stone-300 lg:col-span-2">
                你現在最想處理的問題
                <textarea name="question" maxLength={2000} className="min-h-40 rounded-[22px] border border-white/10 bg-[#120d0b] px-4 py-3 text-stone-100 outline-none focus:border-amber-300/35" placeholder="例如：我們最近反覆因同一件事爭執，想知道關係中的核心問題與接下來半年需要注意什麼。" />
            </label>
            {state.error ? <p className="text-sm text-rose-300 lg:col-span-2">{state.error}</p> : null}
            {state.success ? <p className="rounded-2xl border border-emerald-300/15 bg-emerald-500/[0.05] px-4 py-3 text-sm text-emerald-200 lg:col-span-2">{state.success}</p> : null}
            <div className="lg:col-span-2">
                <button disabled={pending} className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-6 py-3 text-sm font-medium text-stone-950 disabled:opacity-60">
                    {pending ? "送出中..." : "送出給 HUGO"}
                </button>
            </div>
        </form>
    );
}
