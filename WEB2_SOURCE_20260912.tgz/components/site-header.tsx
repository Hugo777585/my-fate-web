import Link from "next/link";
import { MoonStar } from "lucide-react";

import { logoutAction } from "@/app/auth/actions";
import { getCurrentRole, getCurrentUser } from "@/lib/auth";
import { mainNav } from "@/lib/site-data";

export async function SiteHeader() {
    const user = await getCurrentUser();
    const role = user ? await getCurrentRole() : "member";
    const visibleNav = mainNav.filter((item) => item.href !== "/workspace" || role === "owner" || role === "admin");

    return (
        <header className="sticky top-0 z-40 border-b border-white/10 bg-[rgba(13,8,7,0.78)] backdrop-blur-2xl">
            <div className="mx-auto flex max-w-7xl items-center justify-between gap-5 px-4 py-3 sm:px-6 lg:py-4">
                <Link href="/" className="flex min-w-0 items-center gap-3 text-stone-100">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-amber-300/35 bg-amber-200/10 shadow-[0_0_30px_rgba(245,158,11,0.12)]">
                        <MoonStar className="h-4 w-4 text-amber-200" />
                    </span>
                    <span className="min-w-0">
                        <span className="hidden text-[10px] uppercase tracking-[0.34em] text-amber-100/45 sm:block">
                            HUGO FATE INTELLIGENCE
                        </span>
                        <span className="block truncate text-base font-medium tracking-[0.12em] text-amber-50 sm:text-lg">
                            天命智庫
                        </span>
                    </span>
                </Link>

                <nav className="hidden items-center gap-1 xl:flex">
                    {visibleNav.map((item) => (
                        <Link
                            key={item.href}
                            href={item.href}
                            className="rounded-full border border-transparent px-3 py-2 text-[13px] text-stone-300 transition hover:border-amber-300/25 hover:bg-amber-200/[0.06] hover:text-amber-50"
                        >
                            {item.label}
                        </Link>
                    ))}
                </nav>

                <div className="flex shrink-0 items-center gap-2 sm:gap-3">
                    {user ? (
                        <>
                            <Link
                                href="/dashboard"
                                className="rounded-full border border-amber-200/25 px-3 py-2 text-xs text-amber-50 transition hover:bg-amber-200/10 sm:px-4 sm:text-sm"
                            >
                                會員區
                            </Link>
                            <form action={logoutAction} className="hidden sm:block">
                                <button
                                    type="submit"
                                    className="rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-4 py-2 text-sm font-medium text-stone-950 shadow-[0_0_30px_rgba(251,191,36,0.18)] transition hover:brightness-105"
                                >
                                    登出
                                </button>
                            </form>
                        </>
                    ) : (
                        <>
                            <Link
                                href="/auth"
                                className="rounded-full border border-amber-200/25 px-3 py-2 text-xs text-amber-50 transition hover:bg-amber-200/10 sm:px-4 sm:text-sm"
                            >
                                登入
                            </Link>
                            <Link
                                href="/auth"
                                className="hidden rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-4 py-2 text-sm font-medium text-stone-950 shadow-[0_0_30px_rgba(251,191,36,0.18)] transition hover:brightness-105 sm:inline-flex"
                            >
                                免費排盤
                            </Link>
                        </>
                    )}
                </div>
            </div>
        </header>
    );
}
