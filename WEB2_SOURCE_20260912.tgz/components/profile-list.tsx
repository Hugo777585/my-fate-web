import Link from "next/link";

type ProfileItem = {
    id: string;
    type: string;
    name: string;
    tag: string;
    gender: string;
    birthDate: string;
    birthTime: string;
    birthPlace: string;
    notes: string;
};

type ProfileListProps = {
    items: readonly ProfileItem[];
};

export function ProfileList({ items }: ProfileListProps) {
    if (!items.length) {
        return (
            <div className="rounded-[28px] border border-dashed border-amber-300/20 bg-[rgba(248,239,221,0.03)] p-8 text-sm leading-7 text-stone-300">
                目前還沒有任何親友資料。先新增第一筆檔案，後面八字、紫微、合盤與 AI 都會共用這裡的資料。
            </div>
        );
    }

    return (
        <div className="grid gap-4 lg:grid-cols-3">
            {items.map((profile) => (
                <Link
                    key={profile.id}
                    href={`/profiles/${profile.id}`}
                    className="rounded-[28px] border border-stone-800 bg-[rgba(248,239,221,0.04)] p-6 transition hover:-translate-y-1 hover:border-amber-300/30 hover:bg-[rgba(248,239,221,0.08)]"
                >
                    <div className="flex items-center justify-between gap-3">
                        <div>
                            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/55">
                                {profile.type}
                            </p>
                            <h3 className="mt-2 text-2xl tracking-[0.06em] text-stone-50">{profile.name}</h3>
                        </div>
                        <span className="rounded-full border border-amber-300/20 px-3 py-1 text-xs text-amber-100">
                            {profile.tag}
                        </span>
                    </div>
                    <dl className="mt-6 space-y-3 text-sm text-stone-300">
                        <div className="flex justify-between gap-4">
                            <dt>性別</dt>
                            <dd>{profile.gender}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt>生日</dt>
                            <dd>{profile.birthDate}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt>時辰</dt>
                            <dd>{profile.birthTime}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt>出生地</dt>
                            <dd>{profile.birthPlace}</dd>
                        </div>
                    </dl>
                    <p className="mt-5 text-sm leading-7 text-stone-400">{profile.notes}</p>
                </Link>
            ))}
        </div>
    );
}
