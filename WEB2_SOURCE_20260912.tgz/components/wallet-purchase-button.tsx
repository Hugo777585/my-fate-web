"use client";

export function WalletPurchaseButton({ packageCode, enabled }: { packageCode: string; enabled: boolean }) {
    return (
        <form method="post" action="/api/ecpay/create">
            <input type="hidden" name="packageCode" value={packageCode} />
            <button
                type="submit"
                disabled={!enabled}
                className="w-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-4 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-45"
            >
                {!enabled ? "金流設定完成後開放" : "前往綠界付款"}
            </button>
        </form>
    );
}
