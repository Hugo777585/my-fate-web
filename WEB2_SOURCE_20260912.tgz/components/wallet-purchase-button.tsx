"use client";

import { useState } from "react";

export function WalletPurchaseButton({ packageCode, enabled }: { packageCode: string; enabled: boolean }) {
    const [pending, setPending] = useState(false);
    const [error, setError] = useState("");

    async function handlePurchase() {
        if (!enabled || pending) return;
        setPending(true);
        setError("");

        try {
            const response = await fetch("/api/ecpay/create", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ packageCode }),
            });
            const payload = await response.json();
            if (!response.ok) {
                throw new Error(payload.error || "建立付款訂單失敗。 ");
            }

            const form = document.createElement("form");
            form.method = "POST";
            form.action = payload.action;
            Object.entries(payload.fields as Record<string, string>).forEach(([name, value]) => {
                const input = document.createElement("input");
                input.type = "hidden";
                input.name = name;
                input.value = value;
                form.appendChild(input);
            });
            document.body.appendChild(form);
            form.submit();
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : "建立付款訂單失敗。 ");
            setPending(false);
        }
    }

    return (
        <div>
            <button
                type="button"
                disabled={!enabled || pending}
                onClick={handlePurchase}
                className="w-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-4 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-45"
            >
                {!enabled ? "金流設定完成後開放" : pending ? "建立訂單中..." : "前往綠界付款"}
            </button>
            {error ? <p className="mt-2 text-xs leading-5 text-rose-300">{error}</p> : null}
        </div>
    );
}
