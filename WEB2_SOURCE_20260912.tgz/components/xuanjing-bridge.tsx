import { ArrowUpRight, Compass, Sparkles } from "lucide-react";

const XUANJING_URL = "https://xuanjing-web2.dream53721.chatgpt.site";

export function XuanjingBridge() {
    return (
        <section className="overflow-hidden rounded-[32px] border border-violet-300/14 bg-[radial-gradient(circle_at_top_right,rgba(124,58,237,0.14),transparent_34%),linear-gradient(135deg,rgba(20,14,31,0.96),rgba(10,8,13,0.99))] p-7 shadow-[0_0_90px_rgba(124,58,237,0.06)] lg:p-9">
            <div className="grid gap-7 lg:grid-cols-[1fr_auto] lg:items-center">
                <div className="max-w-4xl">
                    <div className="flex items-center gap-3">
                        <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-violet-200/15 bg-violet-200/[0.06]">
                            <Compass className="h-5 w-5 text-violet-100" />
                        </span>
                        <p className="text-xs uppercase tracking-[0.34em] text-violet-200/55">XUANJING 3.0</p>
                    </div>
                    <h2 className="mt-5 text-3xl leading-tight tracking-[0.05em] text-stone-50 lg:text-4xl">
                        另一種看見自己的方式｜玄境 3.0
                    </h2>
                    <p className="mt-5 text-sm leading-8 text-stone-300">
                        2.0 專注於八字、紫微斗數與雙人合盤的深度閱讀；如果你想延伸探索更多命理系統、流年變化、關係互動與個人趨勢，可以進一步體驗「天命智庫－玄境 3.0」。
                    </p>
                    <p className="mt-3 text-sm leading-8 text-stone-400">
                        玄境 3.0 保留命理核心，同時加入更多元的系統與互動體驗。命理不是替你決定未來，而是把複雜訊息整理成更容易理解的人生導航。
                    </p>
                </div>
                <a
                    href={XUANJING_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet-200 via-fuchsia-100 to-amber-100 px-6 py-3.5 text-sm font-medium text-stone-950 shadow-[0_0_40px_rgba(167,139,250,0.15)] hover:brightness-105"
                >
                    <Sparkles className="h-4 w-4" />
                    探索玄境 3.0
                    <ArrowUpRight className="h-4 w-4" />
                </a>
            </div>
        </section>
    );
}
