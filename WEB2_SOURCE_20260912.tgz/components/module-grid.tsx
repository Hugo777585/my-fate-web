import type { Route } from "next";
import Link from "next/link";
import type { LucideIcon } from "lucide-react";

type ModuleItem = {
    title: string;
    description: string;
    href: Route;
    icon: LucideIcon;
};

type ModuleGridProps = {
    items: readonly ModuleItem[];
};

export function ModuleGrid({ items }: ModuleGridProps) {
    return (
        <div className="grid gap-4 lg:grid-cols-3">
            {items.map((item) => {
                const Icon = item.icon;

                return (
                    <Link
                        key={item.href}
                        href={item.href}
                        className="group rounded-[28px] border border-white/10 bg-white/[0.03] p-6 transition hover:-translate-y-1 hover:border-amber-300/30 hover:bg-amber-50/[0.06]"
                    >
                        <div className="flex items-center justify-between">
                            <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-200/20 bg-amber-200/10">
                                <Icon className="h-5 w-5 text-amber-100" />
                            </span>
                            <span className="text-xs uppercase tracking-[0.32em] text-amber-200/55 transition group-hover:text-amber-100">
                                Open
                            </span>
                        </div>
                        <h2 className="mt-6 text-xl font-medium tracking-[0.08em] text-stone-100">
                            {item.title}
                        </h2>
                        <p className="mt-3 text-sm leading-7 text-stone-300">{item.description}</p>
                    </Link>
                );
            })}
        </div>
    );
}
