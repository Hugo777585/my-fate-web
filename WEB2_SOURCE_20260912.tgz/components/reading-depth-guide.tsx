import Link from "next/link";
import { ArrowRight, BookOpenText, CheckCircle2, LockKeyhole } from "lucide-react";

type ReadingStage = {
    label: string;
    title: string;
    description: string;
    bullets: readonly string[];
    price?: string;
    tone?: "free" | "paid";
};

type ReadingDepthGuideProps = {
    eyebrow: string;
    title: string;
    description: string;
    stages: readonly ReadingStage[];
    serviceHref: string;
    serviceLabel: string;
};

export function ReadingDepthGuide({
    eyebrow,
    title,
    description,
    stages,
    serviceHref,
    serviceLabel,
}: ReadingDepthGuideProps) {
    return (
        <section className="rounded-[32px] border border-amber-300/14 bg-[linear-gradient(180deg,rgba(32,20,14,0.88)_0%,rgba(12,9,8,0.98)_100%)] p-6 shadow-[0_0_90px_rgba(217,119,6,0.07)] lg:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div className="max-w-3xl">
                    <p className="text-xs uppercase tracking-[0.34em] text-amber-200/55">{eyebrow}</p>
                    <h2 className="mt-3 text-3xl leading-tight tracking-[0.05em] text-stone-50 lg:text-[2.15rem]">{title}</h2>
                    <p className="mt-4 text-sm leading-8 text-stone-300">{description}</p>
                </div>
                <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs text-stone-400">
                    <BookOpenText className="h-4 w-4 text-amber-200" />
                    往下閱讀，內容會逐步加深
                </div>
            </div>

            <div className="mt-7 grid gap-4 lg:grid-cols-3">
                {stages.map((stage, index) => {
                    const paid = stage.tone === "paid" || Boolean(stage.price);
                    return (
                        <article
                            key={stage.label}
                            className={`relative overflow-hidden rounded-[26px] border p-6 ${
                                paid
                                    ? "border-amber-300/28 bg-[linear-gradient(145deg,rgba(120,74,22,0.18),rgba(28,18,13,0.92))] shadow-[0_0_45px_rgba(217,119,6,0.08)]"
                                    : "border-white/9 bg-white/[0.025]"
                            }`}
                        >
                            <div className="flex items-center justify-between gap-3">
                                <p className="text-xs uppercase tracking-[0.28em] text-amber-200/55">{stage.label}</p>
                                <span className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-black/10 text-xs text-stone-400">
                                    {String(index + 1).padStart(2, "0")}
                                </span>
                            </div>
                            <h3 className="mt-4 text-2xl tracking-[0.05em] text-stone-50">{stage.title}</h3>
                            <p className="mt-3 text-sm leading-7 text-stone-300">{stage.description}</p>
                            <div className="mt-5 space-y-3">
                                {stage.bullets.map((item) => (
                                    <div key={item} className="flex items-start gap-3 text-sm leading-6 text-stone-300">
                                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-amber-200" />
                                        <span>{item}</span>
                                    </div>
                                ))}
                            </div>
                            {stage.price ? (
                                <div className="mt-6 flex items-center justify-between gap-4 border-t border-amber-200/12 pt-5">
                                    <div>
                                        <p className="text-xs tracking-[0.18em] text-amber-100/55">一次解鎖</p>
                                        <p className="mt-1 text-3xl font-medium text-amber-50">{stage.price}</p>
                                    </div>
                                    <LockKeyhole className="h-5 w-5 text-amber-200" />
                                </div>
                            ) : null}
                        </article>
                    );
                })}
            </div>

            <div className="mt-6 flex flex-col gap-3 rounded-[22px] border border-white/8 bg-black/10 p-5 sm:flex-row sm:items-center sm:justify-between">
                <p className="max-w-3xl text-sm leading-7 text-stone-400">
                    免費內容先讓你看懂命盤與核心重點；只有當你想把問題拉到感情、事業、財運、時間節點或關係決策時，再進入深度解讀。
                </p>
                <Link
                    href={serviceHref}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full border border-amber-200/24 px-5 py-3 text-sm text-amber-50 hover:bg-amber-50/[0.06]"
                >
                    {serviceLabel} <ArrowRight className="h-4 w-4" />
                </Link>
            </div>
        </section>
    );
}
