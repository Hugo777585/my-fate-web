"use client";

import Link from "next/link";
import { useActionState } from "react";

import {
    loginAction,
    signupAction,
    type AuthActionState,
} from "@/app/auth/actions";

const initialState: AuthActionState = {};

function AuthFeedback({ state }: { state: AuthActionState }) {
    if (state.error) {
        return (
            <div className="rounded-2xl border border-rose-300/20 bg-rose-500/10 px-4 py-3">
                <p className="text-sm text-rose-200">{state.error}</p>
            </div>
        );
    }

    if (state.success) {
        return (
            <div className="rounded-2xl border border-emerald-300/20 bg-emerald-500/10 px-4 py-3">
                <p className="text-sm text-emerald-200">{state.success}</p>
            </div>
        );
    }

    return null;
}

export function AuthForms() {
    const [loginState, loginFormAction, loginPending] = useActionState(loginAction, initialState);
    const [signupState, signupFormAction, signupPending] = useActionState(signupAction, initialState);

    return (
        <section className="grid gap-6 lg:grid-cols-2">
            <article className="rounded-[28px] border border-white/10 bg-white/[0.03] p-8">
                <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">登入</p>
                <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">回到你的命盤工作台</h2>
                <form action={loginFormAction} className="mt-8 space-y-4">
                    <input
                        name="email"
                        type="email"
                        className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                        placeholder="Email"
                        autoComplete="email"
                    />
                    {loginState.fieldErrors?.email ? (
                        <p className="-mt-1 text-sm text-rose-300">{loginState.fieldErrors.email}</p>
                    ) : null}
                    <input
                        name="password"
                        className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                        placeholder="密碼"
                        type="password"
                        autoComplete="current-password"
                    />
                    {loginState.fieldErrors?.password ? (
                        <p className="-mt-1 text-sm text-rose-300">{loginState.fieldErrors.password}</p>
                    ) : null}
                    <div className="flex items-center justify-between gap-3 text-xs text-stone-400">
                        <span>登入後會自動保持會員狀態，除非你主動登出。</span>
                        <Link href="/auth/forgot-password" className="shrink-0 text-amber-200/80 hover:text-amber-100">
                            忘記密碼？
                        </Link>
                    </div>
                    <AuthFeedback state={loginState} />
                    <button
                        type="submit"
                        disabled={loginPending}
                        className="w-full rounded-full bg-gradient-to-r from-amber-200 to-orange-300 px-5 py-3 text-sm font-medium text-stone-950 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        {loginPending ? "登入中..." : "登入會員區"}
                    </button>
                </form>
            </article>

            <article className="rounded-[28px] border border-amber-300/15 bg-[#140d0b] p-8">
                <p className="text-xs uppercase tracking-[0.38em] text-amber-200/55">註冊</p>
                <h2 className="mt-4 text-3xl tracking-[0.06em] text-stone-50">建立親友資料庫的起點</h2>
                <p className="mt-4 text-sm leading-7 text-stone-300">
                    建立會員後即可保存自己、親友與客戶資料，之後排盤不必重複輸入。正式會員需完成 Email 驗證，驗證後再登入即可長期保留會員狀態。
                </p>
                <form action={signupFormAction} className="mt-8 space-y-4">
                    <input
                        name="email"
                        type="email"
                        className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                        placeholder="Email"
                        autoComplete="email"
                    />
                    {signupState.fieldErrors?.email ? (
                        <p className="-mt-1 text-sm text-rose-300">{signupState.fieldErrors.email}</p>
                    ) : null}
                    <input
                        name="password"
                        className="w-full rounded-2xl border border-white/10 bg-[#120d0b] px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
                        placeholder="密碼（至少 6 碼）"
                        type="password"
                        autoComplete="new-password"
                    />
                    {signupState.fieldErrors?.password ? (
                        <p className="-mt-1 text-sm text-rose-300">{signupState.fieldErrors.password}</p>
                    ) : null}
                    <AuthFeedback state={signupState} />
                    <button
                        type="submit"
                        disabled={signupPending}
                        className="w-full rounded-full border border-white/12 px-5 py-3 text-sm text-stone-100 hover:border-amber-300/35 hover:bg-amber-50/[0.06] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        {signupPending ? "註冊中..." : "建立會員帳號"}
                    </button>
                </form>
            </article>
        </section>
    );
}
