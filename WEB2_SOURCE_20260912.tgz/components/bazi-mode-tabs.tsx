"use client";

import type { Route } from "next";
import { useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { flushSync } from "react-dom";

type WorkspaceMode = "natal" | "timing" | "reading";

type ModeTab = {
    key: WorkspaceMode;
    title: string;
    description: string;
};

type BaziModeTabsProps = {
    tabs: readonly ModeTab[];
    activeMode: WorkspaceMode;
    selectedProfileId?: string;
};

const TRANSITION_STORAGE_KEY = "bazi-mode-transition";
const COVER_DURATION_MS = 360;
const REVEAL_DURATION_MS = 520;

const goldFallParticles = [
    { left: "3%", delay: "0ms", duration: "920ms", size: 18, drift: "-20px", blur: "0px" },
    { left: "8%", delay: "50ms", duration: "880ms", size: 10, drift: "16px", blur: "0px" },
    { left: "13%", delay: "110ms", duration: "980ms", size: 14, drift: "-12px", blur: "0px" },
    { left: "19%", delay: "30ms", duration: "1040ms", size: 12, drift: "20px", blur: "0px" },
    { left: "25%", delay: "140ms", duration: "960ms", size: 9, drift: "-14px", blur: "1px" },
    { left: "31%", delay: "70ms", duration: "1080ms", size: 20, drift: "18px", blur: "0px" },
    { left: "37%", delay: "170ms", duration: "900ms", size: 11, drift: "-18px", blur: "0px" },
    { left: "43%", delay: "100ms", duration: "980ms", size: 16, drift: "10px", blur: "0px" },
    { left: "49%", delay: "20ms", duration: "920ms", size: 12, drift: "-16px", blur: "1px" },
    { left: "55%", delay: "130ms", duration: "1060ms", size: 15, drift: "22px", blur: "0px" },
    { left: "61%", delay: "190ms", duration: "940ms", size: 10, drift: "-10px", blur: "0px" },
    { left: "67%", delay: "80ms", duration: "1100ms", size: 18, drift: "18px", blur: "0px" },
    { left: "73%", delay: "40ms", duration: "930ms", size: 13, drift: "-16px", blur: "1px" },
    { left: "79%", delay: "160ms", duration: "1000ms", size: 9, drift: "20px", blur: "0px" },
    { left: "84%", delay: "220ms", duration: "1080ms", size: 17, drift: "-9px", blur: "0px" },
    { left: "89%", delay: "90ms", duration: "910ms", size: 12, drift: "15px", blur: "0px" },
    { left: "93%", delay: "180ms", duration: "1020ms", size: 8, drift: "-12px", blur: "1px" },
    { left: "97%", delay: "240ms", duration: "1100ms", size: 11, drift: "12px", blur: "0px" },
] as const;

function buildHref(profileId: string | undefined, mode: WorkspaceMode) {
    const params = new URLSearchParams();

    if (profileId) {
        params.set("profile", profileId);
    }

    params.set("mode", mode);

    return `/bazi?${params.toString()}` as Route;
}

export function BaziModeTabs({ tabs, activeMode, selectedProfileId }: BaziModeTabsProps) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();
    const [isAnimating, setIsAnimating] = useState(false);
    const [animationSeed, setAnimationSeed] = useState(0);
    const [pendingMode, setPendingMode] = useState<WorkspaceMode | null>(null);
    const [transitionPhase, setTransitionPhase] = useState<"covering" | "revealing">("covering");
    const navigateTimeoutRef = useRef<number | null>(null);
    const hideTimeoutRef = useRef<number | null>(null);
    const currentHref = useMemo(() => `${pathname}?${searchParams.toString()}`, [pathname, searchParams]);

    useEffect(() => {
        return () => {
            if (navigateTimeoutRef.current) {
                window.clearTimeout(navigateTimeoutRef.current);
            }

            if (hideTimeoutRef.current) {
                window.clearTimeout(hideTimeoutRef.current);
            }
        };
    }, []);

    useEffect(() => {
        const rawTransition = window.sessionStorage.getItem(TRANSITION_STORAGE_KEY);

        if (!rawTransition) {
            return;
        }

        window.sessionStorage.removeItem(TRANSITION_STORAGE_KEY);

        try {
            const parsed = JSON.parse(rawTransition) as { mode?: WorkspaceMode };

            if (!parsed.mode) {
                return;
            }

            const revealMode = parsed.mode;
            const revealStartTimeout = window.setTimeout(() => {
                setAnimationSeed((value) => value + 1);
                setPendingMode(revealMode);
                setTransitionPhase("revealing");
                setIsAnimating(true);

                if (hideTimeoutRef.current) {
                    window.clearTimeout(hideTimeoutRef.current);
                }

                hideTimeoutRef.current = window.setTimeout(() => {
                    setIsAnimating(false);
                    setPendingMode(null);
                }, REVEAL_DURATION_MS);
            }, 0);

            return () => {
                window.clearTimeout(revealStartTimeout);
            };
        } catch {
            window.sessionStorage.removeItem(TRANSITION_STORAGE_KEY);
        }
    }, [currentHref]);

    function triggerTransition(targetMode: WorkspaceMode) {
        const targetHref = buildHref(selectedProfileId, targetMode);

        if (navigateTimeoutRef.current) {
            window.clearTimeout(navigateTimeoutRef.current);
        }

        if (hideTimeoutRef.current) {
            window.clearTimeout(hideTimeoutRef.current);
        }

        flushSync(() => {
            setAnimationSeed((value) => value + 1);
            setIsAnimating(true);
            setPendingMode(targetMode);
            setTransitionPhase("covering");
        });

        if (targetMode === activeMode) {
            navigateTimeoutRef.current = window.setTimeout(() => {
                setTransitionPhase("revealing");
            }, COVER_DURATION_MS);

            hideTimeoutRef.current = window.setTimeout(() => {
                setIsAnimating(false);
                setPendingMode(null);
            }, COVER_DURATION_MS + REVEAL_DURATION_MS);
            return;
        }

        window.sessionStorage.setItem(
            TRANSITION_STORAGE_KEY,
            JSON.stringify({
                mode: targetMode,
            }),
        );

        navigateTimeoutRef.current = window.setTimeout(() => {
            router.push(targetHref, { scroll: false });
        }, COVER_DURATION_MS);
    }

    return (
        <>
            <div className="mt-4 grid gap-3 lg:grid-cols-3">
                {tabs.map((tab) => (
                    <button
                        key={tab.key}
                        type="button"
                        onClick={() => triggerTransition(tab.key)}
                        className={`rounded-[24px] border p-4 text-left transition-all duration-200 hover:-translate-y-0.5 lg:min-h-[164px] ${
                            tab.key === activeMode
                                ? tab.key === "reading"
                                    ? "border-cyan-300/30 bg-[linear-gradient(180deg,rgba(34,211,238,0.16)_0%,rgba(8,19,24,0.98)_100%)] shadow-[0_0_46px_rgba(34,211,238,0.14)]"
                                    : "border-amber-300/30 bg-[linear-gradient(180deg,rgba(251,191,36,0.14)_0%,rgba(18,13,11,0.96)_100%)] shadow-[0_0_46px_rgba(251,191,36,0.1)]"
                                : tab.key === "reading"
                                  ? "border-cyan-300/12 bg-[linear-gradient(180deg,rgba(34,211,238,0.05)_0%,rgba(8,19,24,0.86)_100%)] opacity-80 hover:border-cyan-300/24 hover:bg-[linear-gradient(180deg,rgba(34,211,238,0.09)_0%,rgba(8,19,24,0.9)_100%)] hover:shadow-[0_0_26px_rgba(34,211,238,0.08)] hover:opacity-100"
                                  : "border-amber-300/10 bg-[linear-gradient(180deg,rgba(251,191,36,0.04)_0%,rgba(18,13,11,0.86)_100%)] opacity-80 hover:border-amber-300/22 hover:bg-[linear-gradient(180deg,rgba(251,191,36,0.08)_0%,rgba(18,13,11,0.9)_100%)] hover:shadow-[0_0_26px_rgba(251,191,36,0.08)] hover:opacity-100"
                        }`}
                    >
                        <p className={`text-xs uppercase tracking-[0.24em] ${tab.key === activeMode ? (tab.key === "reading" ? "text-cyan-100/90" : "text-amber-100/85") : tab.key === "reading" ? "text-cyan-200/68" : "text-amber-200/58"}`}>
                            工作模式
                        </p>
                        <h3 className={`mt-3 text-xl tracking-[0.05em] ${tab.key === activeMode ? (tab.key === "reading" ? "text-cyan-50" : "text-stone-50") : tab.key === "reading" ? "text-cyan-50/92" : "text-stone-100"}`}>
                            {tab.title}
                        </h3>
                        <p className={`mt-3 text-sm leading-7 ${tab.key === activeMode ? "text-stone-200" : "text-stone-300"}`}>{tab.description}</p>
                        <p className={`mt-3 text-xs tracking-[0.18em] ${tab.key === activeMode ? (tab.key === "reading" ? "text-cyan-100/85" : "text-amber-100/80") : "text-stone-400"}`}>
                            {tab.key === activeMode ? "目前焦點" : "切換模式"}
                        </p>
                    </button>
                ))}
            </div>

            {isAnimating ? (
                <div key={`bazi-overlay-${animationSeed}`} className="pointer-events-none fixed inset-0 z-[120] overflow-hidden">
                    <div className={`bazi-screen-backdrop ${transitionPhase === "revealing" ? "bazi-screen-backdrop--revealing" : ""}`} />
                    <div className={`bazi-screen-veil ${pendingMode === "reading" ? "bazi-screen-veil--cyan" : ""} ${transitionPhase === "revealing" ? "bazi-screen-veil--revealing" : ""}`} />
                    <div className={`bazi-screen-haze ${pendingMode === "reading" ? "bazi-screen-haze--cyan" : ""} ${transitionPhase === "revealing" ? "bazi-screen-haze--revealing" : ""}`} />
                    <div className={`bazi-screen-line ${transitionPhase === "revealing" ? "bazi-screen-line--revealing" : ""}`} />
                    {goldFallParticles.map((particle, index) => (
                        <span
                            key={`${animationSeed}-${particle.left}-${particle.delay}`}
                            className={`bazi-screen-particle ${index % 3 === 0 ? "bazi-screen-particle--large" : ""}`}
                            style={
                                {
                                    left: particle.left,
                                    width: `${particle.size}px`,
                                    height: `${particle.size}px`,
                                    animationDelay: particle.delay,
                                    animationDuration: particle.duration,
                                    filter: `blur(${particle.blur})`,
                                    "--fall-drift": particle.drift,
                                } as React.CSSProperties
                            }
                        />
                    ))}
                    {goldFallParticles.filter((_, index) => index % 2 === 0).map((particle) => (
                        <span
                            key={`streak-${animationSeed}-${particle.left}-${particle.delay}`}
                            className={`bazi-screen-streak ${pendingMode === "reading" ? "bazi-screen-streak--cyan" : ""}`}
                            style={
                                {
                                    left: particle.left,
                                    animationDelay: particle.delay,
                                    animationDuration: particle.duration,
                                    "--fall-drift": particle.drift,
                                } as React.CSSProperties
                            }
                        />
                    ))}
                    <div className="absolute inset-x-0 top-[16vh] flex justify-center">
                        <div className={`rounded-full border border-amber-300/25 bg-[rgba(18,13,11,0.72)] px-5 py-3 text-xs tracking-[0.28em] text-amber-50 shadow-[0_0_30px_rgba(251,191,36,0.16)] backdrop-blur-md transition-all duration-300 ${transitionPhase === "revealing" ? "opacity-0 -translate-y-3" : "opacity-100 translate-y-0"}`}>
                            {pendingMode === "natal" ? "本命盤切換中" : pendingMode === "timing" ? "大運流年切換中" : "深度解讀切換中"}
                        </div>
                    </div>
                </div>
            ) : null}

            <style>{`
                .bazi-screen-backdrop {
                    position: absolute;
                    inset: 0;
                    background: rgba(6, 4, 3, 0.78);
                    opacity: 1;
                    transition: opacity 380ms ease;
                }

                .bazi-screen-backdrop--revealing {
                    opacity: 0;
                }

                .bazi-screen-veil {
                    position: absolute;
                    inset: 0;
                    background:
                        radial-gradient(circle at 50% 8%, rgba(251, 191, 36, 0.72) 0%, rgba(251, 191, 36, 0.34) 18%, rgba(251, 191, 36, 0.08) 38%, rgba(251, 191, 36, 0) 72%),
                        linear-gradient(180deg, rgba(251, 191, 36, 0.42) 0%, rgba(123, 73, 16, 0.2) 30%, rgba(9, 6, 5, 0.18) 100%);
                    opacity: 0.96;
                    transition: opacity 420ms ease;
                }

                .bazi-screen-veil--cyan {
                    background:
                        radial-gradient(circle at 50% 8%, rgba(125, 211, 252, 0.52) 0%, rgba(251, 191, 36, 0.28) 18%, rgba(34, 211, 238, 0.08) 38%, rgba(34, 211, 238, 0) 72%),
                        linear-gradient(180deg, rgba(22, 78, 99, 0.42) 0%, rgba(90, 61, 18, 0.18) 30%, rgba(8, 11, 14, 0.18) 100%);
                }

                .bazi-screen-veil--revealing {
                    opacity: 0;
                }

                .bazi-screen-haze {
                    position: absolute;
                    inset: 0;
                    background:
                        radial-gradient(circle at 50% 0%, rgba(251, 191, 36, 0.46) 0%, rgba(251, 191, 36, 0.16) 24%, rgba(251, 191, 36, 0) 72%),
                        linear-gradient(180deg, rgba(251, 191, 36, 0.24) 0%, rgba(251, 191, 36, 0.08) 20%, rgba(251, 191, 36, 0) 66%);
                    animation: bazi-screen-fade 720ms ease-out both;
                }

                .bazi-screen-haze--cyan {
                    background:
                        radial-gradient(circle at 50% 0%, rgba(103, 232, 249, 0.34) 0%, rgba(34, 211, 238, 0.1) 24%, rgba(34, 211, 238, 0) 72%),
                        linear-gradient(180deg, rgba(251, 191, 36, 0.18) 0%, rgba(34, 211, 238, 0.05) 20%, rgba(34, 211, 238, 0) 66%);
                }

                .bazi-screen-haze--revealing {
                    animation: none;
                    opacity: 0;
                    transition: opacity 360ms ease;
                }

                .bazi-screen-line {
                    position: absolute;
                    left: 4%;
                    right: 4%;
                    top: 0;
                    height: 2px;
                    background: linear-gradient(
                        90deg,
                        rgba(251, 191, 36, 0) 0%,
                        rgba(251, 191, 36, 0.8) 18%,
                        rgba(255, 236, 179, 0.95) 50%,
                        rgba(251, 191, 36, 0.8) 82%,
                        rgba(251, 191, 36, 0) 100%
                    );
                    box-shadow:
                        0 0 24px rgba(251, 191, 36, 0.26),
                        0 0 52px rgba(253, 224, 71, 0.16);
                    opacity: 0.95;
                    transform: translateY(10px);
                    animation: bazi-screen-fade 720ms ease-out both;
                }

                .bazi-screen-line--revealing {
                    animation: none;
                    opacity: 0;
                    transition: opacity 360ms ease;
                }

                .bazi-screen-particle {
                    position: absolute;
                    top: 0;
                    border-radius: 9999px;
                    background:
                        radial-gradient(circle at 35% 35%, rgba(255, 250, 220, 0.98) 0%, rgba(255, 225, 150, 0.92) 30%, rgba(251, 191, 36, 0.8) 58%, rgba(184, 115, 51, 0.22) 100%);
                    box-shadow:
                        0 0 18px rgba(251, 191, 36, 0.46),
                        0 0 42px rgba(251, 191, 36, 0.24);
                    opacity: 0;
                    transform: translate3d(0, -48px, 0) scale(0.82);
                    animation-name: bazi-screen-fall, bazi-screen-shimmer;
                    animation-timing-function: cubic-bezier(0.2, 0.72, 0.22, 0.98), ease-in-out;
                    animation-fill-mode: both;
                }

                .bazi-screen-particle--large {
                    box-shadow:
                        0 0 24px rgba(253, 224, 71, 0.5),
                        0 0 58px rgba(251, 191, 36, 0.26);
                }

                .bazi-screen-streak {
                    position: absolute;
                    top: -6px;
                    width: 2px;
                    height: 110px;
                    border-radius: 9999px;
                    background: linear-gradient(
                        180deg,
                        rgba(255, 248, 220, 0.98) 0%,
                        rgba(253, 224, 71, 0.82) 22%,
                        rgba(251, 191, 36, 0.34) 72%,
                        rgba(251, 191, 36, 0) 100%
                    );
                    box-shadow:
                        0 0 22px rgba(253, 224, 71, 0.24),
                        0 0 38px rgba(251, 191, 36, 0.12);
                    opacity: 0;
                    transform: translate3d(0, -42px, 0) rotate(9deg);
                    animation: bazi-screen-streak 620ms cubic-bezier(0.16, 0.72, 0.22, 0.98) both;
                }

                .bazi-screen-streak--cyan {
                    background: linear-gradient(
                        180deg,
                        rgba(236, 254, 255, 0.95) 0%,
                        rgba(125, 211, 252, 0.8) 22%,
                        rgba(251, 191, 36, 0.28) 72%,
                        rgba(251, 191, 36, 0) 100%
                    );
                }

                @keyframes bazi-screen-fade {
                    0% {
                        opacity: 0;
                    }

                    24% {
                        opacity: 1;
                    }

                    100% {
                        opacity: 0.15;
                    }
                }

                @keyframes bazi-screen-fall {
                    0% {
                        opacity: 0;
                        transform: translate3d(0, -52px, 0) scale(0.72) rotate(0deg);
                    }

                    12% {
                        opacity: 0.95;
                    }

                    54% {
                        opacity: 0.88;
                    }

                    100% {
                        opacity: 0;
                        transform: translate3d(var(--fall-drift, 0), 82vh, 0) scale(0.98) rotate(18deg);
                    }
                }

                @keyframes bazi-screen-shimmer {
                    0%,
                    100% {
                        filter: brightness(0.94);
                    }

                    50% {
                        filter: brightness(1.22);
                    }
                }

                @keyframes bazi-screen-streak {
                    0% {
                        opacity: 0;
                        transform: translate3d(0, -44px, 0) scaleY(0.72) rotate(7deg);
                    }

                    18% {
                        opacity: 0.88;
                    }

                    100% {
                        opacity: 0;
                        transform: translate3d(var(--fall-drift, 0), 70vh, 0) scaleY(1.18) rotate(13deg);
                    }
                }

                @media (prefers-reduced-motion: reduce) {
                    .bazi-screen-haze,
                    .bazi-screen-line,
                    .bazi-screen-particle,
                    .bazi-screen-streak {
                        animation: none !important;
                    }

                    .bazi-screen-particle,
                    .bazi-screen-streak {
                        display: none;
                    }
                }
            `}</style>
        </>
    );
}
