import Link from "next/link";
import { Home, Sparkles, HeartHandshake, BookUser, CircleUserRound } from "lucide-react";

const mobileNav = [
    { href: "/", label: "首頁", icon: Home },
    { href: "/bazi", label: "命盤", icon: Sparkles },
    { href: "/compatibility", label: "合盤", icon: HeartHandshake },
    { href: "/profiles", label: "資料", icon: BookUser },
    { href: "/dashboard", label: "我的", icon: CircleUserRound },
] as const;

export function MobileBottomNav() {
    return (
        <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-amber-200/10 bg-[rgba(9,7,6,0.94)] px-2 pb-[max(0.45rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-2xl lg:hidden">
            <div className="mx-auto grid max-w-xl grid-cols-5 gap-1">
                {mobileNav.map((item) => {
                    const Icon = item.icon;
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className="group flex min-h-14 flex-col items-center justify-center gap-1 rounded-2xl text-[11px] tracking-[0.08em] text-stone-400 transition hover:bg-amber-50/[0.05] hover:text-amber-100"
                        >
                            <Icon className="h-[18px] w-[18px] transition group-hover:scale-110" />
                            <span>{item.label}</span>
                        </Link>
                    );
                })}
            </div>
        </nav>
    );
}
