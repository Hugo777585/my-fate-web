declare module "lunar-javascript" {
    export type LunarEightCharSect = 1 | 2;

    export type LunarTenGod = string;

    export type LunarEightChar = {
        setSect: (sect: LunarEightCharSect) => void;
        getSect: () => LunarEightCharSect;
        getYear: () => string;
        getMonth: () => string;
        getDay: () => string;
        getTime: () => string;
        getDayGan: () => string;
        getYearGan: () => string;
        getYun: (gender: string) => Yun;
        getYearShiShenGan: () => LunarTenGod;
        getMonthShiShenGan: () => LunarTenGod;
        getDayShiShenGan: () => LunarTenGod;
        getTimeShiShenGan: () => LunarTenGod;
        getYearHideGan: () => string[];
        getMonthHideGan: () => string[];
        getDayHideGan: () => string[];
        getTimeHideGan: () => string[];
        getYearShiShenZhi: () => LunarTenGod[];
        getMonthShiShenZhi: () => LunarTenGod[];
        getDayShiShenZhi: () => LunarTenGod[];
        getTimeShiShenZhi: () => LunarTenGod[];
        getYearDiShi: () => string;
        getMonthDiShi: () => string;
        getDayDiShi: () => string;
        getTimeDiShi: () => string;
        getYearNaYin: () => string;
        getMonthNaYin: () => string;
        getDayNaYin: () => string;
        getTimeNaYin: () => string;
        getYearXunKong: () => string;
        getMonthXunKong: () => string;
        getDayXunKong: () => string;
        getTimeXunKong: () => string;
    };

    export type Lunar = {
        getEightChar: () => LunarEightChar;
    };

    export type Solar = {
        getLunar: () => Lunar;
    };

    export type DaYun = {
        getStartYear: () => number;
        getEndYear: () => number;
        getStartAge: () => number;
        getEndAge: () => number;
        getIndex: () => number;
        getGanZhi: () => string;
        getXunKong: () => string;
    };

    export type Yun = {
        isForward: () => boolean;
        getStartYear: () => number;
        getStartMonth: () => number;
        getStartDay: () => number;
        getStartHour: () => number;
        getDaYun: (size: number) => Record<number, DaYun>;
    };

    export type LunarYear = {
        getGanZhi: () => string;
    };

    export const Solar: {
        fromYmdHms: (year: number, month: number, day: number, hour: number, minute: number, second: number) => Solar;
    };

    export const LunarYear: {
        fromYear: (year: number) => LunarYear;
    };
}
