-- 天命智庫 WEB2｜大階段 2 資料庫變更參考
-- 2026-09-11 已套用至 Supabase 專案。
-- 此檔供離線備份與未來新環境重建參考；正式專案 migration history 以 Supabase 為準。

-- 1) user_roles：會員只能讀自己的角色，用來判斷 owner/admin 工作台權限。
-- 2) consultation_requests：NT$299 / NT$1,200 深度服務送件。
-- 3) clients：owner/admin 可讀服務案件所關聯的命主資料；一般會員仍只能讀自己的。
-- 4) consultation_requests：會員只看自己案件，owner/admin 可看全部並更新狀態。
-- 5) 外鍵與列表索引已建立。

-- 最終新增資料表：
create table if not exists public.consultation_requests (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    profile_id uuid not null references public.clients(id) on delete restrict,
    second_profile_id uuid references public.clients(id) on delete restrict,
    service_code text not null check (service_code in ('personal_299', 'compatibility_1200')),
    amount_twd integer not null check (amount_twd in (299, 1200)),
    question text not null default '',
    contact_note text not null default '',
    status text not null default 'submitted' check (status in ('submitted', 'in_review', 'contacted', 'completed', 'cancelled')),
    created_at timestamptz not null default timezone('utc'::text, now()),
    updated_at timestamptz not null default timezone('utc'::text, now()),
    constraint consultation_request_service_amount_check check (
        (service_code = 'personal_299' and amount_twd = 299 and second_profile_id is null)
        or
        (service_code = 'compatibility_1200' and amount_twd = 1200 and second_profile_id is not null and second_profile_id <> profile_id)
    )
);

alter table public.consultation_requests enable row level security;
create index if not exists consultation_requests_user_created_idx on public.consultation_requests(user_id, created_at desc);
create index if not exists consultation_requests_status_created_idx on public.consultation_requests(status, created_at desc);
create index if not exists consultation_requests_profile_id_idx on public.consultation_requests(profile_id);
create index if not exists consultation_requests_second_profile_id_idx on public.consultation_requests(second_profile_id);

-- 正式 migration history（已套用）：
-- web2_consultation_requests
-- web2_owner_customer_access
-- web2_consultation_policy_indexes
-- 另有一組 web2_payment_order_rpc / web2_remove_payment_order_rpc，前者在安全檢查後立即撤回，最終不存在該 RPC。
