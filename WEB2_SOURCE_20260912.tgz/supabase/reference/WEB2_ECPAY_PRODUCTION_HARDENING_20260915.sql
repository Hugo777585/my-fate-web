-- Defense-in-depth for WEB2 ECPay production callback.
-- Apply only after reviewing current production function.
create or replace function public.apply_paid_order(
    p_merchant_trade_no text,
    p_total_amount integer,
    p_ecpay_trade_no text,
    p_payment_method text,
    p_payment_date text,
    p_rtn_code text,
    p_rtn_msg text,
    p_callback_payload jsonb
)
returns table(order_id uuid, credited_points integer, duplicate boolean)
language plpgsql
security definer
set search_path = public
as $$
declare
    v_order public.payment_orders%rowtype;
    v_wallet public.wallet_accounts%rowtype;
    v_environment text;
begin
    if auth.role() <> 'service_role' then
        raise exception 'service_role_required' using errcode = 'P0001';
    end if;

    if p_merchant_trade_no !~ '^TM2[A-Za-z0-9]{1,17}$' then
        raise exception 'invalid_web2_order' using errcode = 'P0001';
    end if;

    if coalesce(p_callback_payload->>'CustomField3','') <> 'TM2'
       or coalesce(p_callback_payload->>'CustomField2','') <> 'production'
       or coalesce(p_callback_payload->>'SimulatePaid','') <> '0' then
        raise exception 'payment_not_confirmed_real_production' using errcode = 'P0001';
    end if;

    select * into v_order
    from public.payment_orders
    where merchant_trade_no = p_merchant_trade_no
    for update;

    if not found then
        raise exception 'order_not_found' using errcode = 'P0001';
    end if;

    if v_order.payment_environment <> 'production' then
        raise exception 'order_environment_mismatch' using errcode = 'P0001';
    end if;

    if v_order.amount <> p_total_amount then
        raise exception 'order_amount_mismatch' using errcode = 'P0001';
    end if;

    v_environment := nullif(coalesce(p_callback_payload, '{}'::jsonb)->>'CustomField2', '');
    if v_environment is distinct from v_order.payment_environment then
        raise exception 'order_environment_mismatch' using errcode = 'P0001';
    end if;

    if v_order.status = 'paid' then
        return query select v_order.id, v_order.total_points, true;
        return;
    end if;

    if v_order.status = 'refunded' then
        return query select v_order.id, 0, true;
        return;
    end if;

    if v_order.status = 'cancelled' then
        raise exception 'order_cancelled' using errcode = 'P0001';
    end if;

    if p_rtn_code <> '1' then
        raise exception 'payment_not_paid' using errcode = 'P0001';
    end if;

    insert into public.wallet_accounts (user_id)
    values (v_order.user_id)
    on conflict (user_id) do nothing;

    select * into v_wallet
    from public.wallet_accounts
    where user_id = v_order.user_id
    for update;

    update public.wallet_accounts
    set balance = balance + v_order.base_points,
        lifetime_purchased = lifetime_purchased + v_order.base_points
    where user_id = v_order.user_id
    returning * into v_wallet;

    insert into public.wallet_transactions (
        user_id, entry_type, delta, balance_after, reference_type,
        reference_id, reason, metadata
    ) values (
        v_order.user_id, 'purchase_base', v_order.base_points, v_wallet.balance,
        'payment_order', v_order.id, '綠界購點入帳',
        jsonb_build_object('package_code', v_order.package_code, 'payment_environment', 'production')
    );

    if v_order.bonus_points > 0 then
        update public.wallet_accounts
        set balance = balance + v_order.bonus_points,
            lifetime_bonus = lifetime_bonus + v_order.bonus_points
        where user_id = v_order.user_id
        returning * into v_wallet;

        insert into public.wallet_transactions (
            user_id, entry_type, delta, balance_after, reference_type,
            reference_id, reason, metadata
        ) values (
            v_order.user_id, 'purchase_bonus', v_order.bonus_points, v_wallet.balance,
            'payment_order', v_order.id, '購點活動贈點',
            jsonb_build_object('package_code', v_order.package_code, 'payment_environment', 'production')
        );
    end if;

    update public.payment_orders
    set status = 'paid',
        ecpay_trade_no = nullif(p_ecpay_trade_no, ''),
        payment_method = nullif(p_payment_method, ''),
        payment_date = nullif(p_payment_date, ''),
        rtn_code = p_rtn_code,
        rtn_msg = left(coalesce(p_rtn_msg, ''), 240),
        callback_payload = coalesce(p_callback_payload, '{}'::jsonb),
        paid_at = timezone('utc'::text, now())
    where id = v_order.id;

    insert into public.admin_notifications (
        event_type, order_id, user_id, title, body
    ) values (
        'payment_credited', v_order.id, v_order.user_id,
        '付款成功、點數已入帳',
        jsonb_build_object(
            'amount', v_order.amount,
            'base_points', v_order.base_points,
            'bonus_points', v_order.bonus_points,
            'credited_points', v_order.total_points,
            'merchant_trade_no', v_order.merchant_trade_no,
            'payment_environment', 'production'
        )
    ) on conflict on constraint admin_notifications_event_type_order_id_key do nothing;

    return query select v_order.id, v_order.total_points, false;
end;
$$;
