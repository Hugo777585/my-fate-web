alter table public.clients
    add column if not exists owner_id uuid references auth.users (id) on delete cascade,
    add column if not exists profile_type text,
    add column if not exists birth_time_label text,
    add column if not exists birth_place text,
    add column if not exists notes text,
    add column if not exists updated_at timestamp with time zone not null default timezone('utc'::text, now());

update public.clients
set
    profile_type = coalesce(profile_type, 'family'),
    birth_place = coalesce(birth_place, ''),
    notes = coalesce(notes, ''),
    birth_time_label = coalesce(birth_time_label, '')
where
    profile_type is null
    or birth_place is null
    or notes is null
    or birth_time_label is null;

alter table public.clients
    alter column owner_id set not null,
    alter column profile_type set not null,
    alter column profile_type set default 'family',
    alter column birth_place set not null,
    alter column birth_place set default '',
    alter column notes set not null,
    alter column notes set default '',
    alter column birth_time_label set not null,
    alter column birth_time_label set default '';

alter table public.clients
    drop constraint if exists clients_profile_type_check;

alter table public.clients
    add constraint clients_profile_type_check check (profile_type in ('self', 'family', 'client'));

create index if not exists clients_owner_id_created_at_idx on public.clients (owner_id, created_at desc);

create or replace function public.set_clients_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.updated_at = timezone('utc'::text, now());
    return new;
end;
$$;

drop trigger if exists set_clients_updated_at on public.clients;

create trigger set_clients_updated_at
before update on public.clients
for each row
execute function public.set_clients_updated_at();

alter table public.clients enable row level security;

drop policy if exists "clients_select_own" on public.clients;
drop policy if exists "clients_insert_own" on public.clients;
drop policy if exists "clients_update_own" on public.clients;
drop policy if exists "clients_delete_own" on public.clients;

create policy "clients_select_own"
on public.clients
for select
to authenticated
using (auth.uid() = owner_id);

create policy "clients_insert_own"
on public.clients
for insert
to authenticated
with check (auth.uid() = owner_id);

create policy "clients_update_own"
on public.clients
for update
to authenticated
using (auth.uid() = owner_id)
with check (auth.uid() = owner_id);

create policy "clients_delete_own"
on public.clients
for delete
to authenticated
using (auth.uid() = owner_id);
